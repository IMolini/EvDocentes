from app import app
from flask import Flask, render_template, request, flash, redirect, url_for, session
from flaskext.mysql import MySQL
from experta import *
import bcrypt


app.secret_key = "appLogin"

mysql = MySQL()
app.config['MYSQL_DATABASE_HOST'] = '127.0.0.1'
app.config['MYSQL_DATABASE_USER'] = 'root'
app.config['MYSQL_DATABASE_PASSWORD'] = 'root'
app.config['MYSQL_DATABASE_DB'] = 'aplicacion'


mysql.init_app(app)

semilla = bcrypt.gensalt()

@app.route("/")
def main():
    if 'nombre' in session:
        return render_template('usuario/index-login.html')
    else:
        return render_template('public/index.html')


@app.route("/registro", methods = ["GET", "POST"])
def registro():
    if request.method == "GET":
        if 'nombre' in session:
            return render_template('usuario/index-login.html')
        else:
            return render_template('public/registrar.html')
    else:
        nombre = request.form['nmNombreRegistro']
        email = request.form['nmCorreoRegistro']
        password = request.form['nmPasswordRegistro']
        password_encode = password.encode("utf-8")
        password_encriptado = bcrypt.hashpw(password_encode, semilla)
        if nombre == "":
            flash("El nombre no puede estar vacío")
            return redirect(url_for('registro'))
        if email == "":
            flash("El email no puede estar vacío")
            return redirect(url_for('registro'))
        if password == "":
            flash("El password no puede estar vacío")
            return redirect(url_for('registro'))
        
        cur = mysql.get_db().cursor()

        sQuery = 'SELECT nombre, email, password FROM usuarios where email = %s'

        cur.execute(sQuery, [email])

        usuario = cur.fetchone()

        if usuario == None:
        
            cur.execute('INSERT INTO usuarios (nombre, email, password) VALUES ( %s, %s, %s)', (nombre, email, password_encriptado))

            mysql.get_db().commit()
        
        else:

            flash("Ya existe un usuario registrado con el email indicado")
            return redirect(url_for('registro'))


        session['nombre'] = nombre
        session['email'] = email

        return redirect(url_for('main'))

@app.route("/ingresar", methods = ["GET", "POST"])
def ingresar():
    if request.method == "GET":
        if 'nombre' in session:
            return render_template("usuario/index-login.html")
        else:
            return render_template("public/ingresar.html")
    else:
        email = request.form['nmCorreoLogin']
        password = request.form['nmPasswordLogin']
        password_encode = password.encode("utf-8")
        
        if email == "":
            flash("El email no puede estar vacío")
            return render_template('public/ingresar.html')
        if password == "":
            flash("La contraseña no puede estar vacía")
            return render_template('public/ingresar.html')
        
        cur = mysql.get_db().cursor()

        sQuery = "SELECT nombre, email, password FROM usuarios WHERE email = %s"

        cur.execute(sQuery, [email])

        usuario = cur.fetchone()
        
        cur.close()

        if (usuario != None):
            password_encriptado_encode = usuario[2].encode()
            if (bcrypt.checkpw(password_encode, password_encriptado_encode)):

                session['nombre'] = usuario[0]
                session['email'] = usuario[1]
                    
                return redirect(url_for('main'))
                
            else:
                flash("La contraseña no es correcta")
                return render_template('public/ingresar.html')
        if (usuario == None):
            flash("Credenciales incorrectas")
            return render_template('public/ingresar.html')


@app.route("/salir")
def salir():
    session.clear()
    return redirect(url_for('main'))

@app.route("/about")
def about():
    if 'nombre' in session:
        return render_template('usuario/about.html')
    else:
        return render_template('public/about.html')

@app.route("/evaluacion")
def evaluacion_select():
    if 'nombre' in session:
        return render_template("usuario/evaluacion-select.html")
    else:
        return render_template('public/ingresar.html')
    



# Facts PCD/PUP----------------------------------------------------------------------------------------------------------------------------------------------
class Publicaciones(Fact):
    
    publicaciones = Field(int)
    tercil = Field(list) 
    factor = Field(list)
    numeroAutores = Field(list)
    continua = Field(list)
    pass

class Libros(Fact):
    libros = Field(int)
    isbn = Field(list)
    citas = Field(list)
    tercilCitas = Field(list)
    traducciones = Field(list)
    pass

class Proyectos(Fact):
    proyectos = Field(int)
    tipoParticipacion = Field(list)
    organismo = Field(list)
    gradoResponsabilidad = Field(list)
    evaluadorExterno = Field(list)
    pass 

class Patentes(Fact):
    patentes = Field(int)
    explotacion = Field(list)
    cesion = Field(list)
    licencia = Field(list)
    pass

class Tesis(Fact):
    tesis = Field(int)
    doctoradoEuro = Field(list)
    estado = Field(list)
    mCalidad = Field(list)
    pass

class Eventos(Fact):
    eventos = Field(int)
    procesoAdmision = Field(list)
    caracter = Field(list)
    participacion = Field(list)
    pass

class OtrosMeritosInv(Fact):
    otrosMeritosInv = Field(int)
    pass


class Experiencias(Fact):
    experiencias = Field(int)
    centroExp = Field(list)
    master = Field(list)
    doctorado = Field(list)
    horas = Field(list)
    pass

class Evaluaciones(Fact):
    evaluaciones = Field(int)
    notas = Field(list)
    pass

class EventosDocentes(Fact):
    eventosDocentes = Field(int)
    invitacion = Field(list)
    pass

class MaterialDocente(Fact):
    publicacionesDoc = Field(int)
    tipo = Field(list)
    original = Field(list)
    articulos = Field(list)
    pass

class Formacion(Fact):
    estudios = Field(int)
    calificacion = Field(list)
    doctoradoEuropeo = Field(list)
    mencionCalidad = Field(list)
    becas = Field(list)
    estanciasFuera = Field(list)
    pass

class ExperienciaProfesional(Fact):
    experienciasProfesionales = Field(int)
    institucionEmpresa = Field(list)
    duracion = Field(list)
    responsabilidad = Field(list)
    pass

class OtrosMeritos(Fact):
    otrosMeritosAcademicos = Field(list)
    otrosMeritosDocentes = Field(list)
    otrosMeritosInvestigacion = Field(list)
    otrosMeritosProfesionales = Field(list)
    pass

# Ciencias Experimentales PCD/PUP-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class EvaluacionPublicacionesCE(KnowledgeEngine):
    resultadoPublicaciones = 0
    @Rule(Publicaciones(publicaciones = P(lambda x: x == 0)))
    def no_publicaciones(self):
        resultado = 0
        self.resultadoPublicaciones = resultado
        print("resultado = " + str(resultado))

    @Rule(Publicaciones(publicaciones = P(lambda x: x >= 12)))
    def publicaciones_max(self):
        resultado = 0
        tercil = self.facts[2]['tercil']
        factor = self.facts[3]['factor']
        numeroAutores = self.facts[4]['numeroAutores']
        continua = self.facts[5]['continua']
        if len(tercil) >= 12:
            resultado = 35
        else:
            for i in tercil:
                if resultado < 11:
                    if (i == "T1"):
                        resultado += 1
                    elif (i == "T2"):
                        resultado += 0.75
                    elif (i == "T3"):
                        resultado += 0.5
                    else:
                        continue
            for i in factor:
                if resultado < 19:
                    if i == "Alto":
                        resultado += 1
                    elif i == "Medio":
                        resultado += 0.75
                    elif i == "Bajo":
                        resultado += 0.5
                    else:
                        continue  
            for i in numeroAutores:
                if resultado < 25:
                    if (i == "1"):
                        resultado += 0.5
                    elif ((i == "2") or (i == "3")):
                        resultado += 0.25
                    else:    
                        continue
        
            for i in continua:
                if resultado < 32:
                    if i == "Si":
                        resultado += 0.75
                    else:
                        continue
            resultado = round(resultado)
        
            if resultado > 32:
                resultado = 32


        resultado = round(resultado)
        self.resultadoPublicaciones = resultado
        print('resultadoPublicaciones = ' + str(resultado))
    
    @Rule(Publicaciones(publicaciones = P(lambda x: 0 < x < 12)))
    def publicaciones(self):
        resultado = 0
        publicaciones = self.facts[1]['publicaciones']
        tercil = self.facts[2]['tercil']
        factor = self.facts[3]['factor']
        numeroAutores = self.facts[4]['numeroAutores']
        continua = self.facts[5]['continua']
        
        for i in tercil:
            if resultado < 11:
                if (i == "T1"):
                    resultado += 1
                elif (i == "T2"):
                    resultado += 0.75
                elif (i == "T3"):
                    resultado += 0.5
                else:
                    continue

        for i in factor:
            if resultado < 19:
                if i == "Alto":
                    resultado += 1
                elif i == "Medio":
                    resultado += 0.75
                elif i == "Bajo":
                    resultado += 0.5
                else:
                    continue    
        

        for i in numeroAutores:
            if resultado < 25:
                if (i == "1"):
                    resultado += 0.5
                elif ((i == "2") or (i == "3")):
                    resultado += 0.25
                else:    
                    continue
        print(resultado)
        for i in continua:
            if resultado < 32:
                if i == "Si":
                    resultado += 0.75
                else:
                    continue
        resultado = round(resultado)
        
        if resultado > 32:
            resultado = 32

        self.resultadoPublicaciones = resultado
        print('resultadoPublicaciones = ' + str(resultado)) 

class EvaluacionLibrosCE(KnowledgeEngine):
    resultadoLibros = 0
    @Rule(Libros(libros = P(lambda x: x == 0)))
    def no_libros(self):
        resultado = 0
        self.resultadoLibros = resultado
        print("ResultadoLibros = 0")
    
    @Rule(Libros(libros = P(lambda x: x > 0)))
    def libros(self):
        libros = self.facts[1]['libros']
        isbn = self.facts[2]['isbn']
        citas = self.facts[3]['citas']
        tercilCitas = self.facts[4]['tercilCitas']
        traducciones = self.facts[5]['traducciones']
        resultado = 0
        
        for i in isbn:
            if i == "Si":
                resultado += 1
            elif i == "No":
                resultado += 0.5
        
        if resultado > 3:
            resultado = 3
        
        for i in citas:
            if (i == "Si"):
                resultado += 0.5
            else: 
                continue
        
        if resultado > 4:
            resultado = 4

        for i in tercilCitas:
            if ((i == "T1") or (i == "T2")):
                resultado += 1
            elif i == "T3":
                resultado += 0.25

        if resultado > 6:
            resultado = 6

        for i in traducciones:
            if i == "Si":
                resultado += 0.5
            else: 
                continue


        resultado = round(resultado)
        if resultado > 7:
            resultado = 7

        
        self.resultadoLibros = resultado
        print('resultadoLibros = ' + str(resultado))

class EvaluacionProyectosCE(KnowledgeEngine):
    resultadoProyectos = 0
    @Rule(Proyectos(proyectos = P(lambda x: x == 0)))
    def no_proyectos(self):
        resultado = 0
        self.resultadoProyectos = resultado
        print("resultado = " + str(resultado))
    
    @Rule(Proyectos(proyectos = P(lambda x: x > 0)))
    def proyectos(self):
        proyectos = self.facts[1]['proyectos']
        tipoParticipacion = self.facts[2]['tipoParticipacion']
        organismo = self.facts[3]['organismo']
        gradoResponsabilidad = self.facts[4]['gradoResponsabilidad']
        evaluadorExterno = self.facts[5]['evaluadorExterno']
        resultado = 0

        for i in organismo:
            if i == "Union Europea":
                resultado += 0.75
            elif i == "Nacional":
                resultado += 0.5
            elif i == "Comunidad Autonoma":
                resultado += 0.25
            else:
                continue

        if resultado > 3:
            resultado = 3
        
        for i in evaluadorExterno:
            if i == "Si":
                resultado += 0.5
            else:
                continue
        
        if resultado > 5:
            resultado = 5
        
        for i in tipoParticipacion:
            if ((i == "Jefe de proyecto") or (i == "Director")):
                resultado += 0.5
            elif (i == "Empleado"):
                resultado += 0.25
            else:
                continue

        if resultado > 6:
            resultado = 6

        for i in gradoResponsabilidad:
            if i == "Alta":
                resultado += 0.5
            elif i == "Media":
                resultado += 0.25
            else:
                continue
        
        resultado = round(resultado)
        if resultado > 7:
            resultado = 7

        self.resultadoProyectos = resultado
        print("resultado = " + str(resultado))

class EvaluacionPatentesCE(KnowledgeEngine):
    resultadoPatentes = 0
    @Rule(Patentes(patentes = P(lambda x: x == 0)))
    def no_patentes(self):
        resultado = 0
        self.resultadoPatentes = resultado
        print("resultadoPatentes = 0")
    
    @Rule(Patentes(patentes = P(lambda x: x > 0)))
    def patentes(self):
        patentes = self.facts[1]['patentes']
        explotacion = self.facts[2]['explotacion']
        cesion = self.facts[3]['cesion']
        licencia = self.facts[4]['licencia']
        resultado = 0
        
        for i in explotacion:
            if i == "Si":
                resultado += 1
            elif i == "No":
                resultado += 0.5

        if resultado > 2:
            resultado = 2

        for i in cesion:
            if i == "Si":
                resultado += 0.5
        
        if resultado > 3:
            resultado = 3

        for i in licencia:
            if i == "Si":
                resultado += 0.5

        resultado = round(resultado)

        if resultado > 4:
            resultado = 4
        
        self.resultadoPatentes = resultado
        print("resultadoPatentes = " + str(resultado))

class EvaluacionTesisCE(KnowledgeEngine):
    resultadoTesis = 0
    @Rule(Tesis(tesis = P(lambda x: x == 0)))
    def no_tesis(self):
        resultado = 0
        self.resultadoTesis = resultado
        print("resultado = 0")
    
    @Rule(Tesis(tesis = P(lambda x: x > 0)))
    def tesis(self):
        tesis = self.facts[1]['tesis']
        doctoradoEuro = self.facts[2]['doctoradoEuro']
        estado = self.facts[3]['estado']
        mCalidad = self.facts[4]['mCalidad']
        resultado = 0
        
        for i in doctoradoEuro:
            if i == "Si":
                resultado += 1
            elif i == "No":
                resultado += 0.25 
                
        if resultado > 2:
            resultado = 2

        for i in mCalidad:
            if i == "Si":
                resultado += 0.5
            else:
                continue
        
        if resultado > 3:
            resultado = 3

        for i in estado:
            if i ==  "Finalizada":
                resultado += 0.5
            elif i == "En desarrollo":
                resultado += 0.25
            else: 
                continue
        
        resultado = round(resultado)
        if resultado > 4:
            resultado = 4

        self.resultadoTesis = resultado
        print("resultadoTesis = " + str(resultado))

class EvaluacionEventosCE(KnowledgeEngine):
    resultadoEventos = 0
    @Rule(Eventos(eventos = P(lambda x: x == 0)))
    def no_eventos(self):
        resultado = 0
        self.resultadoEventos = resultado
        print("resultado = 0")
    
    @Rule(Eventos(eventos = P(lambda x: x > 0)))
    def eventos(self):
        eventos = self.facts[1]['eventos']
        procesoAdmision = self.facts[2]['procesoAdmision']
        caracter = self.facts[3]['caracter']
        participacion = self.facts[4]['participacion']
        resultado = 0
        
        for i in procesoAdmision:
            if i == "Si":
                resultado += 0.5
            elif i == "No":
                resultado += 0.25

        if resultado > 1:
            resultado = 1

        for i in participacion:
            if i == "Ponencia invitada":
                resultado += 0.5
            elif((i == "Ponencia") or (i == "Comunicacion oral") or (i == "Póster") or (i == "Participación en la organización") or (i == "Participación en el comité científico")):
                resultado += 0.25
            else:
                continue

        resultado = round(resultado)
        
        if resultado > 2:
            resultado = 2

        self.resultadoEventos = resultado
        print("resultado = " + str(resultado))

class EvaluacionOtrosMeritosInvCE(KnowledgeEngine):
    resultadoOtrosMeritosInvCE = 0
    @Rule(OtrosMeritosInv(otrosMeritosInv = P(lambda x: x == 0)))
    def no_otros_meritos_invCE(self):
        resultado = 0
        self.resultadoOtrosMeritosInvCE = resultado
        print("resultados otros meritos investigacion = "+ str(resultado))

    @Rule(OtrosMeritosInv(otrosMeritosInv = P(lambda x: x > 0)))
    def otros_meritos_invCE(self):
        resultado = 1
        self.resultadoOtrosMeritosInvCE = resultado
        print("resultados otros meritos investigacion = "+ str(resultado))
        


# Ciencias de la salud-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class EvaluacionPublicacionesCS(KnowledgeEngine):
    resultadoPublicacionesCS = 0
    @Rule(Publicaciones(publicaciones = P(lambda x: x == 0)))
    def no_publicaciones_CS(self):
        resultado = 0
        self.resultadoPublicacionesCS = resultado
        print("resultado = " + str(resultado))
    
    @Rule(Publicaciones(publicaciones = P(lambda x: x > 0)))
    def publicaciones_CS(self):
        publicaciones = self.facts[1]['publicaciones']
        tercil = self.facts[2]['tercil']
        resultado = 0

        for i in tercil:
            if i == "T1":
                resultado += 7
            elif i == "T2":
                resultado += 7
            elif i == "T3":
                resultado += 3
            else:
                continue
                
        
        if resultado > 35:
            resultado = 35
        
        self.resultadoPublicacionesCS = resultado
        print("resultado = " + str(resultado))

class EvaluacionLibrosCS(KnowledgeEngine):
    resultadoLibrosCS = 0
    @Rule(Libros(libros = P(lambda x: x == 0)))
    def no_librosCS(self):
        resultado = 0
        self.resultadoLibrosCS = resultado
        print("resultado = " + str(resultado))
    
    @Rule(Libros(libros = P(lambda x: x > 0)))
    def librosCS(self):
        libros = self.facts[1]['libros']
        isbn = self.facts[2]['isbn']
        citas = self.facts[3]['citas']
        tercilCitas = self.facts[4]['tercilCitas']
        traducciones = self.facts[5]['traducciones']
        resultado = 0


        for i in isbn:
            if i == "Si":
                resultado += 1
            elif i == "No":
                resultado += 0.5
        
        if resultado > 3:
            resultado = 3
    
        for i in citas:
            if i == "Si":
                resultado += 0.5
            else: 
                continue
        
        if resultado > 4:
            resultado = 4

        for i in tercilCitas:
            if ((i == "T1") or (i == "T2")):
                resultado += 1
            elif (i == "T3"):
                resultado += 0.25 
        
        if resultado > 6:
            resultado = 6
        
        for i in traducciones:
            if i == "Si":
                resultado += 0.5
            else: 
                continue
        
        resultado = round(resultado)
        if resultado > 7:
            resultado = 7
      
        self.resultadoLibrosCS = resultado
        print('resultado = ' + str(resultado))

class EvaluacionProyectosCS(KnowledgeEngine):
    resultadoProyectosCS = 0
    @Rule(Proyectos(proyectos = P(lambda x: x == 0)))
    def no_proyectosCS(self):
        resultado = 0
        self.resultadoProyectosCS = resultado
        print("resultado = " + str(resultado))
    
    @Rule(Proyectos(proyectos = P(lambda x: x > 0)))
    def proyectosCS(self):
        proyectos = self.facts[1]['proyectos']
        tipoParticipacion = self.facts[2]['tipoParticipacion']
        organismo = self.facts[3]['organismo']
        gradoResponsabilidad = self.facts[4]['gradoResponsabilidad']
        evaluadorExterno = self.facts[5]['evaluadorExterno']
        resultado = 0

        for i in organismo:
            if i == "Union Europea":
                resultado += 0.75
            elif i == "Nacional":
                resultado += 0.5
            elif i == "Comunidad Autonoma":
                resultado += 0.25
        
        if resultado > 3:
            resultado = 3

        for i in evaluadorExterno:
            if i == "Si":
                resultado += 0.5
            else:
                continue
        
        if resultado > 5:
            resultado = 5
        
        for i in tipoParticipacion:
            if ((i == "Jefe de proyecto") or (i == "Director")):
                resultado += 0.5
            elif (i == "Empleado"):
                resultado += 0.25
            else:
                continue
        
        if resultado > 6:
            resultado = 6

        for i in gradoResponsabilidad:
            if i == "Alta":
                resultado += 0.5
            elif i == "Media":
                resultado += 0.25
            else:
                continue
        
        resultado = round(resultado)
        if resultado > 7:
            resultado = 7

        self.resultadoProyectosCS = resultado
        print("resultado = " + str(resultado))
        
class EvaluacionPatentesCS(KnowledgeEngine):
    resultadoPatentesCS = 0
    @Rule(Patentes(patentes = P(lambda x: x == 0)))
    def no_patentesCS(self):
        resultado = 0
        self.resultadoPatentesCS = resultado
        print("resultado = 0")

    @Rule(Patentes(patentes = P(lambda x: x > 0)))
    def patentesCS(self):
        patentes = self.facts[1]['patentes']
        explotacion = self.facts[2]['explotacion']
        cesion = self.facts[3]['cesion']
        licencia = self.facts[4]['licencia']
        resultado = 0

        for i in explotacion:
            if i == "Si":
                resultado += 1
            elif i == "No":
                resultado += 0.5
        
        if resultado > 2:
            resultado = 2

        for i in cesion:
            if i == "Si":
                resultado += 0.5
        
        if resultado > 3:
            resultado = 3

        for i in licencia:
            if i == "Si":
                resultado += 0.5

        resultado = round(resultado)

        if resultado > 4:
            resultado = 4
        
        self.resultadoPatentesCS = resultado
        print("resultado = " + str(resultado))

class EvaluacionTesisCS(KnowledgeEngine):
    resultadoTesisCS = 0
    @Rule(Tesis(tesis = P(lambda x: x == 0)))
    def no_tesisCS(self):
        resultado = 0
        self.resultadoTesisCS = resultado
        print("resultado = 0")
    
    @Rule(Tesis(tesis = P(lambda x: x > 0)))
    def tesisCS(self):
        tesis = self.facts[1]['tesis']
        doctoradoEuro = self.facts[2]['doctoradoEuro']
        estado = self.facts[3]['estado']
        mCalidad = self.facts[4]['mCalidad']
        resultado = 0
        for i in doctoradoEuro:
            if i == "Si":
                resultado += 1
            elif i == "No":
                resultado += 0.25
        
        if resultado > 2:
            resultado = 2
        
        for i in mCalidad:
            if i == "Si":
                resultado += 0.5
            else:
                continue
        
        if resultado > 3:
            resultado = 3

        for i in estado:
            if i ==  "Finalizada":
                resultado += 0.5
            elif i == "En desarrollo":
                resultado += 0.25
            else: 
                continue

        resultado = round(resultado)
        if resultado > 4:
            resultado = 4

        self.resultadoTesisCS = resultado
        print("resultado = " + str(resultado))

class EvaluacionEventosCS(KnowledgeEngine):
    resultadoEventosCS = 0
    @Rule(Eventos(eventos = P(lambda x: x == 0)))
    def no_eventosCS(self):
        resultado = 0
        self.resultadoEventosCS = resultado
        print("resultado = 0")
    
    @Rule(Eventos(eventos = P(lambda x: x > 0)))
    def eventos(self):
        eventos = self.facts[1]['eventos']
        procesoAdmision = self.facts[2]['procesoAdmision']
        caracter = self.facts[3]['caracter']
        participacion = self.facts[4]['participacion']
        resultado = 0
        
        
        for i in procesoAdmision:
            if i == "Si":
                resultado += 0.5
            elif i == "No":
                resultado += 0.25
        
        if resultado > 1:
            resultado = 1
        
        for i in participacion:
            if i == "Ponencia invitada":
                resultado += 0.5
            elif((i == "Ponencia") or (i == "Comunicacion oral") or (i == "Póster") or (i == "Participación en la organización") or (i == "Participación en el comité científico")):
                resultado += 0.25
        
        resultado = round(resultado)
        if resultado > 2:
            resultado = 2

        self.resultadoEventosCS = resultado
        print("resultado = " + str(resultado))
 
class EvaluacionOtrosMeritosInvCS(KnowledgeEngine):
    resultadoOtrosMeritosInvCS = 0
    @Rule(OtrosMeritosInv(otrosMeritosInv = P(lambda x: x == 0)))
    def no_otros_meritos_invCS(self):
        resultado = 0
        self.resultadoOtrosMeritosInvCS = resultado
        print("resultados otros meritos investigacion = "+ str(resultado))

    @Rule(OtrosMeritosInv(otrosMeritosInv = P(lambda x: x > 0)))
    def otros_meritos_invCS(self):
        resultado = 1
        self.resultadoOtrosMeritosInvCS = resultado
        print("resultados otros meritos investigacion = "+ str(resultado))

# Enseñanzas Técnicas-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class EvaluacionPublicacionesET(KnowledgeEngine):
    resultadoPublicacionesET = 0
    
    @Rule(Publicaciones(publicaciones = P(lambda x: x == 0)))
    def no_publicaciones_ET(self):
        resultado = 0
        self.resultadoPublicacionesET = resultado
        print("resultado Publicaciones = " + str(resultado))
    
    @Rule(Publicaciones(publicaciones = P(lambda x: x >= 8)))
    def max_publicaciones_ET(self):
        resultado = 0
        tercil = self.facts[2]['tercil']
        factor = self.facts[3]['factor']
        numeroAutores = self.facts[4]['numeroAutores']
        continua = self.facts[5]['continua']
        
        if len(tercil) >= 8:
            resultado = 32
        else:
            
            for i in tercil:
                if (i == "T1"):
                    resultado += 1.5
                elif (i == "T2"):
                    resultado += 1
                elif (i == "T3"):
                    resultado += 0.5
                else:
                    continue

            if resultado > 10:
                resultado = 10
        
            for i in factor:
                if (i == "Alto"):
                    resultado += 1
                elif (i == "Medio"):
                    resultado += 0.5
                elif (i == "Bajo"):
                    resultado += 0.25
                else:
                    continue

            if resultado > 17:
                resultado = 17
        
            for i in numeroAutores:
                if (i == "1"):
                    resultado += 0.5
                else:
                    continue

            if resultado > 21:
                resultado = 21

            for i in continua:
                if (i == "Si"):
                    resultado += 1
                else:
                    continue
        
            resultado = round(resultado)
            if resultado > 28:
                resultado = 28
        self.resultadoPublicacionesET = resultado
        print("resultado Publicaciones = " + str(resultado))

    @Rule(Publicaciones(publicaciones = P(lambda x: 0 < x < 8)))
    def publicaciones_ET(self):
        resultado = 0
        publicaciones = self.facts[1]['publicaciones']
        tercil = self.facts[2]['tercil']
        factor = self.facts[3]['factor']
        numeroAutores = self.facts[4]['numeroAutores']
        continua = self.facts[5]['continua']

        for i in tercil:
            if (i == "T1"):
                resultado += 1.5
            elif (i == "T2"):
                resultado += 1
            elif (i == "T3"):
                resultado += 0.5
            else:
                continue

        if resultado > 10:
            resultado = 10
        
        for i in factor:
            if (i == "Alto"):
                resultado += 1
            elif (i == "Medio"):
                resultado += 0.5
            elif (i == "Bajo"):
                resultado += 0.25
            else:
                continue

        if resultado > 17:
            resultado = 17
        
        for i in numeroAutores:
            if (i == "1"):
                resultado += 0.5
            else:
                continue

        if resultado > 21:
            resultado = 21

        for i in continua:
            if (i == "Si"):
                resultado += 1
            else:
                continue
        
        resultado = round(resultado)
        if resultado > 28:
            resultado = 28
        self.resultadoPublicacionesET = resultado
        print("resultado Publicaciones = " + str(resultado))

class EvaluacionLibrosET(KnowledgeEngine):
    resultadoLibrosET = 0
    @Rule(Libros(libros = P(lambda x: x == 0)))
    def no_libros_ET(self):
        resultado = 0
        self.resultadoLibrosET = resultado
        print("resultado libros = " + str(resultado))
    
    @Rule(Libros(libros = P(lambda x: x > 0)))
    def librosET(self):
        resultado = 0
        libros = self.facts[1]['libros']
        isbn = self.facts[2]['isbn']
        citas = self.facts[3]['citas']
        traducciones = self.facts[4]['traducciones']

        for i in isbn:
            if i == "Si":
                resultado += 1
            elif i == "No":
                resultado += 0.5 #Puntuamos un libro sin isbn para que el libro no quede a 0
        
        if resultado > 2:
            resultado = 2

        for i in citas:
            if i  == "Si":
                resultado += 0.25
            else:
                continue
        
        if resultado > 2.5:
            resultado = 2.5

        for i in traducciones:
            if i == "Si":
                resultado += 0.25
            else:
                continue
            
        resultado = round(resultado)
        if resultado > 3:
            resultado = 3

        self.resultadoLibrosET = resultado
        print("resultado libros = " + str(resultado))    

class EvaluacionProyectosET(KnowledgeEngine):
    resultadoProyectosET = 0
    @Rule(Proyectos(proyectos = P(lambda x: x == 0)))
    def no_proyectos_ET(self):
        resultado = 0
        self.resultadoProyectosET = resultado
        print("resultado proyectos = " + str(resultado))

    @Rule(Proyectos(proyectos = P(lambda x: x > 0)))
    def proyectos_ET(self):
        resultado = 0
        proyectos = self.facts[1]['proyectos']
        tipoParticipacion = self.facts[2]['tipoParticipacion']
        organismo = self.facts[3]['organismo']
        gradoResponsabilidad = self.facts[4]['gradoResponsabilidad']
        evaluadorExterno = self.facts[5]['evaluadorExterno']

        for i in organismo:
            if (i == "Union Europea"):
                resultado += 1
            elif (i == "Nacional"):
                resultado += 0.5
            elif (i == "Comunidad Autonoma"):
                resultado += 0.25
            else:
                continue
        
        if resultado > 5:
            resultado = 5
        
        for i in evaluadorExterno:
            if (i == "Si"):
                resultado += 0.5
            else:
                continue
        
        if resultado > 8:
            resultado = 8
        
        for i in tipoParticipacion:
            if ((i == "Jefe de proyecto") or (i == "Director")):
                resultado += 0.5
            elif (i == "Empleado"):
                resultado += 0.25
            else:
                continue
        
        if resultado > 10:
            resultado = 10
        
        for i in gradoResponsabilidad:
            if i == "Alta":
                resultado += 0.5
            elif i == "Media":
                resultado += 0.25
            else:
                continue
        
        resultado = round(resultado)
        if resultado > 12:
            resultado = 12
        
        self.resultadoProyectosET = resultado
        print("resultado proyectos = " + str(resultado))

class EvaluacionPatentesET(KnowledgeEngine):
    resultadoPatentesET = 0
    @Rule(Patentes(patentes = P(lambda x: x == 0)))
    def no_patentesET(self):
        resultado = 0
        self.resultadoPatentesET = resultado
        print("resultado patentes = 0")

    @Rule(Patentes(patentes = P(lambda x: x > 0)))
    def patentesET(self):
        resultado = 0
        patentes = self.facts[1]['patentes']
        explotacion = self.facts[2]['explotacion']
        cesion = self.facts[3]['cesion']
        licencia = self.facts[4]['licencia']
        

        for i in explotacion:
            if i == "Si":
                resultado += 1
            elif i == "No":
                resultado += 0.5 #Puntuamos una patente para que no quede a 0

        if resultado > 3:
            resultado = 3

        for i in cesion:
            if i == "Si":
                resultado += 0.5
        
        if resultado > 4.5:
            resultado = 4.5
        
        for i in licencia:
            if i == "Si":
                resultado += 0.5
        
        resultado = round(resultado)

        if resultado > 6:
            resultado = 6
        
        self.resultadoPatentesET = resultado
        print("resultado patentes = " + str(resultado))

class EvaluacionTesisET(KnowledgeEngine):
    resultadoTesisET = 0
    @Rule(Tesis(tesis = P(lambda x: x == 0)))
    def no_tesisET(self):
        resultado = 0
        self.resultadoTesisET = resultado
        print("resultado tesis = 0")
    
    @Rule(Tesis(tesis = P(lambda x: x > 0)))
    def tesisET(self):
        tesis = self.facts[1]['tesis']
        doctoradoEuro = self.facts[2]['doctoradoEuro']
        estado = self.facts[3]['estado']
        mCalidad = self.facts[4]['mCalidad']
        resultado = 0
        for i in doctoradoEuro:
            if i == "Si":
                resultado += 1
            elif i == "No":
                resultado += 0.25

        if resultado > 2:
            resultado = 2

        for i in mCalidad:
            if i == "Si":
                resultado += 0.5
            else:
                continue
        
        if resultado > 3:
            resultado = 3

        for i in estado:
            if i ==  "Finalizada":
                resultado += 0.5
            elif i == "En desarrollo":
                resultado += 0.25
            else: 
                continue

        resultado = round(resultado)
        if resultado > 4:
            resultado = 4

        self.resultadoTesisET = resultado
        print("resultado tesis = " + str(resultado))

class EvaluacionEventosET(KnowledgeEngine):
    resultadoEventosET = 0
    @Rule(Eventos(eventos = P(lambda x: x == 0)))
    def no_eventosET(self):
        resultado = 0
        self.resultadoEventosET = resultado
        print("resultado = 0")
    
    @Rule(Eventos(eventos = P(lambda x: x > 0)))
    def eventos(self):
        eventos = self.facts[1]['eventos']
        procesoAdmision = self.facts[2]['procesoAdmision']
        caracter = self.facts[3]['caracter']
        participacion = self.facts[4]['participacion']
        resultado = 0
        
        
        for i in procesoAdmision:
            if i == "Si":
                resultado += 0.5
            elif i == "No":
                resultado += 0.25

        if resultado > 1:
            resultado = 1

        for i in participacion:
            if i == "Ponencia invitada":
                resultado += 0.5
            elif((i == "Ponencia") or (i == "Comunicacion oral") or (i == "Póster") or (i == "Participación en la organización") or (i == "Participación en el comité científico")):
                resultado += 0.25
        
        resultado = round(resultado)
        if resultado > 2:
            resultado = 2

        self.resultadoEventosET = resultado
        print("resultado eventos = " + str(resultado))

class EvaluacionOtrosMeritosInvET(KnowledgeEngine):
    resultadoOtrosMeritosInvET = 0
    @Rule(OtrosMeritosInv(otrosMeritosInv = P(lambda x: x == 0)))
    def no_otros_meritos_invET(self):
        resultado = 0
        self.resultadoOtrosMeritosInvET = resultado
        print("resultados otros meritos investigacion = "+ str(resultado))

    @Rule(OtrosMeritosInv(otrosMeritosInv = P(lambda x: x > 0)))
    def otros_meritos_invET(self):
        resultado = 1
        self.resultadoOtrosMeritosInvET = resultado
        print("resultados otros meritos investigacion = "+ str(resultado))

# Ciencias Sociales y Jurídicas----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class EvaluacionPublicacionesSJ(KnowledgeEngine):
    resultadoPublicacionesSJ = 0
    @Rule(Publicaciones(publicaciones = P(lambda x: x == 0)))
    def no_publicacionesSJ(self):
        resultado = 0
        self.resultadoPublicacionesSJ = resultado
        print("resultado = " + str(resultado))
    
    @Rule(Publicaciones(publicaciones = P(lambda x: 0 < x)))
    def publicacionesSJ(self):
        resultado = 0
        publicaciones = self.facts[1]['publicaciones']
        tercil = self.facts[2]['tercil']
        factor = self.facts[3]['factor']
        numeroAutores = self.facts[4]['numeroAutores']
        continua = self.facts[5]['continua']
        
        #cada publicacion son 3 ptos, 1 punto por cuartil 1 o 2
        for i in tercil:
            if (i == "T1"):
                resultado += 1
            elif (i == "T2"):
                resultado += 0.75
            elif (i == "T3"):
                resultado += 0.5
            else:
                continue
        if resultado > 11:
            resultado = 11

        for i in factor:
            if i == "Alto":
                resultado += 1
            elif i == "Medio":
                resultado += 0.75
            elif i == "Bajo":
                resultado += 0.5
            else:
                continue
        
        if resultado > 19:
            resultado = 19

        for i in numeroAutores:
            if (i == "1"):
                resultado += 0.5
            elif ((i == "2") or (i == "3")):
                resultado += 0.25
            else:    
                continue
        
        if resultado > 25:
            resultado = 25

        for i in continua:
            if i == "Si":
                resultado += 1
            else:
                continue
        
        resultado = round(resultado)
        
        if resultado > 30:
            resultado = 30

        self.resultadoPublicacionesSJ = resultado
        print('resultadoPublicaciones = ' + str(resultado))

class EvaluacionLibrosSJ(KnowledgeEngine):
    resultadoLibrosSJ = 0
    @Rule(Libros(libros = P(lambda x: x == 0)))
    def no_libros_SJ(self):
        resultado = 0
        self.resultadoLibrosSJ = resultado
        print("resultado libros = " + str(resultado))
    
    @Rule(Libros(libros = P(lambda x: x > 0)))
    def librosSJ(self):
        resultado = 0
        libros = self.facts[1]['libros']
        isbn = self.facts[2]['isbn']
        citas = self.facts[3]['citas']
        tercilCitas = self.facts[4]['tercilCitas']
        traducciones = self.facts[5]['traducciones']

        for i in isbn:
            if i == "Si":
                resultado += 1
            elif i == "No":
                resultado += 0.5 
        
        if resultado > 5:
            resultado = 5

        for i in citas:
            if i  == "Si":
                resultado += 0.75
            else:
                continue

        if resultado > 8:
            resultado = 8
        
        for i in tercilCitas:
            if i == "T1":
                resultado += 1
            elif i == "T2":
                resultado += 0.5
        
        if resultado > 10:
            resultado = 10
        
        for i in traducciones:
            if i == "Si":
                resultado += 0.5
            else:
                continue
            
        resultado = round(resultado)
        if resultado > 12:
            resultado = 12

        self.resultadoLibrosSJ = resultado
        print("resultado libros = " + str(resultado))

class EvaluacionProyectosSJ(KnowledgeEngine):
    resultadoProyectosSJ = 0
    @Rule(Proyectos(proyectos = P(lambda x: x == 0)))
    def no_proyectosSJ(self):
        resultado = 0
        self.resultadoProyectosSJ = resultado
        print("resultado = " + str(resultado))
    
    @Rule(Proyectos(proyectos = P(lambda x: x > 0)))
    def proyectosSJ(self):
        proyectos = self.facts[1]['proyectos']
        tipoParticipacion = self.facts[2]['tipoParticipacion']
        organismo = self.facts[3]['organismo']
        gradoResponsabilidad = self.facts[4]['gradoResponsabilidad']
        evaluadorExterno = self.facts[5]['evaluadorExterno']
        resultado = 0

        for i in organismo:
            if i == "Union Europea":
                resultado += 0.75
            elif i == "Nacional":
                resultado += 0.5
            elif i == "Comunidad Autonoma":
                resultado += 0.25

        if resultado > 2:
            resultado = 2

        for i in evaluadorExterno:
            if i == "Si":
                resultado += 0.5
            else:
                continue
        
        if resultado > 3:
            resultado = 3
        
        for i in tipoParticipacion:
            if ((i == "Jefe de proyecto") or (i == "Director")):
                resultado += 0.5
            elif (i == "Empleado"):
                resultado += 0.25
            else:
                continue
        
        if resultado > 4:
            resultado = 4

        for i in gradoResponsabilidad:
            if i == "Alta":
                resultado += 0.5
            elif i == "Media":
                resultado += 0.25
            else:
                continue
        
        resultado = round(resultado)
        if resultado > 5:
            resultado = 5

        self.resultadoProyectosSJ = resultado
        print("resultado Proyectos = " + str(resultado))

class EvaluacionPatentesSJ(KnowledgeEngine):
    resultadoPatentesSJ = 0
    @Rule(Patentes(patentes = P(lambda x: x == 0)))
    def no_patentesSJ(self):
        resultado = 0
        self.resultadoPatentesSJ = resultado
        print("resultado = 0")
    
    @Rule(Patentes(patentes = P(lambda x: x > 0)))
    def patentesSJ(self):
        resultado = 0
        patentes = self.facts[1]['patentes']
        explotacion = self.facts[2]['explotacion']
        cesion = self.facts[3]['cesion']
        licencia = self.facts[4]['licencia']

        for i in explotacion:
            if i == "Si":
                resultado += 1
            elif i == "No":
                resultado += 0.5
        
        resultado = round(resultado)
        if resultado > 2:
            resultado = 2

        self.resultadoPatentesSJ = resultado
        print("resultado Patentes = " + str(resultado))

class EvaluacionTesisSJ(KnowledgeEngine):
    resultadoTesisSJ = 0
    @Rule(Tesis(tesis = P(lambda x: x == 0)))
    def no_tesisSJ(self):
        resultado = 0
        self.resultadoTesisSJ = resultado
        print("resultado tesis = 0")
    
    @Rule(Tesis(tesis = P(lambda x: x > 0)))
    def tesisSJ(self):
        tesis = self.facts[1]['tesis']
        doctoradoEuro = self.facts[2]['doctoradoEuro']
        estado = self.facts[3]['estado']
        mCalidad = self.facts[4]['mCalidad']
        resultado = 0
        for i in doctoradoEuro:
            if i == "Si":
                resultado += 1
            elif i == "No":
                resultado += 0.25

        if resultado > 2:
            resultado = 2

        for i in mCalidad:
            if i == "Si":
                resultado += 0.5
            else:
                continue
        
        if resultado > 3:
            resultado = 3

        for i in estado:
            if i ==  "Finalizada":
                resultado += 0.5
            elif i == "En desarrollo":
                resultado += 0.25
            else: 
                continue

        resultado = round(resultado)
        if resultado > 4:
            resultado = 4

        self.resultadoTesisSJ = resultado
        print("resultado tesis = " + str(resultado))

class EvaluacionEventosSJ(KnowledgeEngine):
    resultadoEventosSJ = 0
    @Rule(Eventos(eventos = P(lambda x: x == 0)))
    def no_eventosSJ(self):
        resultado = 0
        self.resultadoEventosSJ = resultado
        print("resultado = 0")
    
    @Rule(Eventos(eventos = P(lambda x: x > 0)))
    def eventos(self):
        eventos = self.facts[1]['eventos']
        procesoAdmision = self.facts[2]['procesoAdmision']
        caracter = self.facts[3]['caracter']
        participacion = self.facts[4]['participacion']
        resultado = 0
        
        
        for i in procesoAdmision:
            if i == "Si":
                resultado += 1
            elif i == "No":
                resultado += 0.5

        if resultado > 2:
            resultado = 2

        for i in caracter:
            if i == "Internacional":
                resultado += 1
            elif i == "Nacional":
                resultado += 0.5
            else:
                continue
        if resultado > 4:
            resultado = 4
            
        for i in participacion:
            if i == "Ponencia invitada":
                resultado += 0.5
            elif((i == "Ponencia") or (i == "Comunicacion oral") or (i == "Póster") or (i == "Participación en la organización") or (i == "Participación en el comité científico")):
                resultado += 0.25
            else:
                continue
        
        resultado = round(resultado)
        if resultado > 5:
            resultado = 5

        self.resultadoEventosSJ = resultado
        print("resultado eventos = " + str(resultado))

class EvaluacionOtrosMeritosInvSJ(KnowledgeEngine):
    resultadoOtrosMeritosInvSJ = 0
    @Rule(OtrosMeritosInv(otrosMeritosInv = P(lambda x: x == 0)))
    def no_otros_meritos_invSJ(self):
        resultado = 0
        self.resultadoOtrosMeritosInvSJ = resultado
        print("resultados otros meritos investigacion = "+ str(resultado))

    @Rule(OtrosMeritosInv(otrosMeritosInv = P(lambda x: x > 0)))
    def otros_meritos_invSJ(self):
        resultado = 0
        otrosMeritosInv = self.facts[1]['otrosMeritosInv']
        if otrosMeritosInv == 1:
            resultado = 1
        if otrosMeritosInv == 2:
            resultado = 2
        self.resultadoOtrosMeritosInvSJ = resultado
        print("resultados otros meritos investigacion = "+ str(resultado))

# Humanidades ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class EvaluacionPublicacionesH(KnowledgeEngine):
    resultadoPublicacionesH = 0
    @Rule(Publicaciones(publicaciones = P(lambda x: x == 0)))
    def no_publicacionesH(self):
        resultado = 0
        self.resultadoPublicacionesH = resultado
        print("resultado = " + str(resultado))

    @Rule(Publicaciones(publicaciones = P(lambda x: x >= 10)))
    def max_publicacionesH(self):
        resultado = 0
        tercil = self.facts[2]['tercil']
        factor = self.facts[3]['factor']
        numeroAutores = self.facts[4]['numeroAutores']
        continua = self.facts[5]['continua']
        if len(tercil) >= 10:
            resultado = 26
        else:
            for i in tercil:
                if (i == "T1"):
                    resultado += 1
                elif (i == "T2"):
                    resultado += 0.75
                elif (i == "T3"):
                    resultado += 0.5
                else:
                    continue

            for i in factor:
                if i == "Alto":
                    resultado += 0.75
                elif i == "Medio":
                    resultado += 0.5
                elif i == "Bajo":
                    resultado += 0.25
                else:
                    continue
        

            for i in numeroAutores:
                if (i == "1"):
                    resultado += 0.5
                elif ((i == "2") or (i == "3")):
                    resultado += 0.25
                else:    
                    continue

            for i in continua:
                if i == "Si":
                    resultado += 0.5
                else:
                    continue
        
            resultado = round(resultado)
        
            if resultado > 26:
                resultado = 26
        
        self.resultadoPublicacionesH = resultado
        print("resultado = " + str(resultado))
    
    @Rule(Publicaciones(publicaciones = P(lambda x: 0 < x < 10)))
    def publicacionesH(self):
        resultado = 0
        publicaciones = self.facts[1]['publicaciones']
        tercil = self.facts[2]['tercil']
        factor = self.facts[3]['factor']
        numeroAutores = self.facts[4]['numeroAutores']
        continua = self.facts[5]['continua']
        
        for i in tercil:
            if (i == "T1"):
                resultado += 1
            elif (i == "T2"):
                resultado += 0.75
            elif (i == "T3"):
                resultado += 0.5
            else:
                continue

        for i in factor:
            if i == "Alto":
                resultado += 0.75
            elif i == "Medio":
                resultado += 0.5
            elif i == "Bajo":
                resultado += 0.25
            else:
                continue
        

        for i in numeroAutores:
            if (i == "1"):
                resultado += 0.5
            elif ((i == "2") or (i == "3")):
                resultado += 0.25
            else:    
                continue

        for i in continua:
            if i == "Si":
                resultado += 0.5
            else:
                continue
        
        resultado = round(resultado)
        
        if resultado > 26:
            resultado = 26

        self.resultadoPublicacionesH = resultado
        print('resultadoPublicaciones = ' + str(resultado))

class EvaluacionLibrosH(KnowledgeEngine):
    resultadoLibrosH = 0
    @Rule(Libros(libros = P(lambda x: x == 0)))
    def no_libros_H(self):
        resultado = 0
        self.resultadoLibrosH = resultado
        print("resultado libros = " + str(resultado))
    
    @Rule(Libros(libros = P(lambda x: x > 0)))
    def librosH(self):
        resultado = 0
        libros = self.facts[1]['libros']
        isbn = self.facts[2]['isbn']
        citas = self.facts[3]['citas']
        tercilCitas = self.facts[4]['tercilCitas']
        traducciones = self.facts[5]['traducciones']

        for i in isbn:
            if i == "Si":
                resultado += 1
            elif i == "No":
                resultado += 0.5 #Puntuamos un libro sin isbn para que el libro no quede a 0
        
        if resultado > 6:
            resultado = 6

        for i in citas:
            if i  == "Si":
                resultado += 0.5
            else:
                continue

        if resultado > 9:
            resultado = 9
        
        for i in tercilCitas:
            if i == "T1":
                resultado += 1
            elif i == "T2":
                resultado += 0.5
        
        if resultado > 14:
            resultado = 14
        
        for i in traducciones:
            if i == "Si":
                resultado += 0.5
            else:
                continue
            
        resultado = round(resultado)
        if resultado > 16:
            resultado = 16

        self.resultadoLibrosH = resultado
        print("resultado libros = " + str(resultado))

class EvaluacionProyectosH(KnowledgeEngine):
    resultadoProyectosH = 0
    @Rule(Proyectos(proyectos = P(lambda x: x == 0)))
    def no_proyectosH(self):
        resultado = 0
        self.resultadoProyectosH = resultado
        print("resultado = " + str(resultado))
    
    @Rule(Proyectos(proyectos = P(lambda x: x > 0)))
    def proyectosH(self):
        proyectos = self.facts[1]['proyectos']
        tipoParticipacion = self.facts[2]['tipoParticipacion']
        organismo = self.facts[3]['organismo']
        gradoResponsabilidad = self.facts[4]['gradoResponsabilidad']
        evaluadorExterno = self.facts[5]['evaluadorExterno']
        resultado = 0

        for i in organismo:
            if i == "Union Europea":
                resultado += 0.75
            elif i == "Nacional":
                resultado += 0.5
            elif i == "Comunidad Autonoma":
                resultado += 0.25

        if resultado > 2:
            resultado = 2

        for i in evaluadorExterno:
            if i == "Si":
                resultado += 0.5
            else:
                continue
        
        if resultado > 3:
            resultado = 3
        
        for i in tipoParticipacion:
            if ((i == "Jefe de proyecto") or (i == "Director")):
                resultado += 0.5
            elif (i == "Empleado"):
                resultado += 0.25
            else:
                continue
        
        if resultado > 4:
            resultado = 4

        for i in gradoResponsabilidad:
            if i == "Alta":
                resultado += 0.5
            elif i == "Media":
                resultado += 0.25
            else:
                continue
        
        resultado = round(resultado)
        if resultado > 5:
            resultado = 5

        self.resultadoProyectosH = resultado
        print("resultado Proyectos = " + str(resultado))

class EvaluacionPatentesH(KnowledgeEngine):
    resultadoPatentesH = 0
    @Rule(Patentes(patentes = P(lambda x: x == 0)))
    def no_patentesH(self):
        resultado = 0
        self.resultadoPatentesH = resultado
        print("resultado = 0")
    
    @Rule(Patentes(patentes = P(lambda x: x > 0)))
    def patentesH(self):
        resultado = 0
        patentes = self.facts[1]['patentes']
        explotacion = self.facts[2]['explotacion']
        cesion = self.facts[3]['cesion']
        licencia = self.facts[4]['licencia']

        for i in explotacion:
            if i == "Si":
                resultado += 1
            elif i == "No":
                resultado += 0.5
        
        resultado = round(resultado)
        if resultado > 2:
            resultado = 2

        self.resultadoPatentesH = resultado
        print("resultado Patentes = " + str(resultado))

class EvaluacionTesisH(KnowledgeEngine):
    resultadoTesisH = 0
    @Rule(Tesis(tesis = P(lambda x: x == 0)))
    def no_tesisH(self):
        resultado = 0
        self.resultadoTesisH = resultado
        print("resultado tesis = 0")
    
    @Rule(Tesis(tesis = P(lambda x: x > 0)))
    def tesisH(self):
        tesis = self.facts[1]['tesis']
        doctoradoEuro = self.facts[2]['doctoradoEuro']
        estado = self.facts[3]['estado']
        mCalidad = self.facts[4]['mCalidad']
        resultado = 0
        for i in doctoradoEuro:
            if i == "Si":
                resultado += 1
            elif i == "No":
                resultado += 0.25

        if resultado > 2:
            resultado = 2

        for i in mCalidad:
            if i == "Si":
                resultado += 0.5
            else:
                continue
        
        if resultado > 3:
            resultado = 3

        for i in estado:
            if i ==  "Finalizada":
                resultado += 0.5
            elif i == "En desarrollo":
                resultado += 0.25
            else: 
                continue

        resultado = round(resultado)
        if resultado > 4:
            resultado = 4

        self.resultadoTesisH = resultado
        print("resultado tesis = " + str(resultado))

class EvaluacionEventosH(KnowledgeEngine):
    resultadoEventosH = 0
    @Rule(Eventos(eventos = P(lambda x: x == 0)))
    def no_eventosH(self):
        resultado = 0
        self.resultadoEventosH = resultado
        print("resultado = 0")
    
    @Rule(Eventos(eventos = P(lambda x: x > 0)))
    def eventosH(self):
        eventos = self.facts[1]['eventos']
        procesoAdmision = self.facts[2]['procesoAdmision']
        caracter = self.facts[3]['caracter']
        participacion = self.facts[4]['participacion']
        resultado = 0
        
        
        for i in procesoAdmision:
            if i == "Si":
                resultado += 1
            elif i == "No":
                resultado += 0.5

        if resultado > 2:
            resultado = 2

        for i in caracter:
            if i == "Internacional":
                resultado += 1
            elif i == "Nacional":
                resultado += 0.5
            else:
                continue
        if resultado > 4:
            resultado = 4
            
        for i in participacion:
            if i == "Ponencia invitada":
                resultado += 0.5
            elif((i == "Ponencia") or (i == "Comunicacion oral") or (i == "Póster") or (i == "Participación en la organización") or (i == "Participación en el comité científico")):
                resultado += 0.25
            else:
                continue
        
        resultado = round(resultado)
        if resultado > 5:
            resultado = 5

        self.resultadoEventosH = resultado
        print("resultado eventos = " + str(resultado))

class EvaluacionOtrosMeritosInvH(KnowledgeEngine):
    resultadoOtrosMeritosInvH = 0
    @Rule(OtrosMeritosInv(otrosMeritosInv = P(lambda x: x == 0)))
    def no_otros_meritos_invH(self):
        resultado = 0
        self.resultadoOtrosMeritosInvH = resultado
        print("resultados otros meritos investigacion = "+ str(resultado))

    @Rule(OtrosMeritosInv(otrosMeritosInv = P(lambda x: x > 0)))
    def otros_meritos_invH(self):
        resultado = 0
        otrosMeritosInv = self.facts[1]['otrosMeritosInv']
        if otrosMeritosInv == 1:
            resultado = 1
        if otrosMeritosInv == 2:
            resultado = 2
        self.resultadoOtrosMeritosInvH = resultado
        print("resultados otros meritos investigacion = "+ str(resultado))

#EVALUACION COMUN PCD/PUP----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class EvaluacionExperiencias(KnowledgeEngine):
    resultadoExperiencias = 0
    @Rule(Experiencias(experiencias = P(lambda x: x == 0)))
    def sin_experiencia(self):
        resultado = 0
        self.resultadoExperiencias = resultado
        print("resultado = 0")
    
    @Rule(Experiencias(experiencias = P(lambda x: x > 0)))
    def experiencias(self):
        experiencias = self.facts[1]['experiencias']
        centroExp = self.facts[2]['centroExp']
        master = self.facts[3]['master']
        doctorado = self.facts[4]['doctorado']
        horas = self.facts[5]['horas']
        totalHoras = 0
        for i in horas:
            totalHoras += int(i)
        
        if (totalHoras >= 450):
            resultado = 17
        elif (300 < totalHoras < 450):
            resultado = 10
            for i in master:
                if i == "Si":
                    resultado += 0.75
            for i in doctorado:
                if i == "Si":
                    resultado += 1
            if resultado > 15:
                resultado = 15
        elif (150 <= totalHoras <= 300):
            resultado = 5
            for i in master:
                if i == "Si":
                    resultado += 0.75
            for i in doctorado:
                if i == "Si":
                    resultado += 1
            if resultado > 10:
                resultado = 10
        elif (0 <= totalHoras < 150):
            resultado = round(totalHoras/50) #puntuacion maxima que otorgan las horas 3 ptos
            for i in master:
                if i == "Si":
                    resultado += 0.75
            for i in doctorado:
                if i == "Si":
                    resultado += 1
            resultado = round(resultado)
            if resultado > 5:
                resultado = 5

        resultado = round(resultado)
        self.resultadoExperiencias = resultado
        print("resultado = " + str(resultado))

class EvaluacionEVCalidad(KnowledgeEngine):
    resultadoEVcalidad = 0
    @Rule(Evaluaciones(evaluaciones = P(lambda x: x == 0)))
    def sin_evaluaciones(self):
        resultado = 0
        self.resultadoEVCalidad = resultado
        print("resultado = 0")
    
    @Rule(Evaluaciones(evaluaciones = P(lambda x: x > 0)))
    def evaluaciones_calidad(self):
        evaluaciones = self.facts[1]['evaluaciones']
        notas = self.facts[2]['notas']
        suma = 0
        for i in notas:
            if len(i) > 2:
                continue
            else:
                suma += int(i)
        
        media = int(suma/evaluaciones)
        
        resultado = round(media * 0.3)

        self.resultadoEVCalidad = resultado
        print("resultado = " + str(resultado))

class EvaluacionEventosDocentes(KnowledgeEngine):
    resultadoEventosDocentes = 0
    @Rule(EventosDocentes(eventosDocentes = P(lambda x: x == 0)))
    def no_eventos_docentes(self):
        resultado = 0
        self.resultadoEventosDocentes = resultado
        print("resultado = 0")
    
    @Rule(EventosDocentes(eventosDocentes = P(lambda x: x > 0)))
    def eventos_docentes(self):
        eventosDocentes = self.facts[1]['eventosDocentes']
        invitacion = self.facts[2]['invitacion']
        resultado = 0

        for i in invitacion:
            if i == "No":
                resultado += 0.5
            elif i == "Si":
                resultado += 1
        
        resultado = round(resultado)

        if resultado > 3:
            resultado = 3
        self.resultadoEventosDocentes = resultado
        print("resultado = " + str(resultado))

class EvaluacionMaterialDocente(KnowledgeEngine):
    resultadoMaterialDocente = 0
    @Rule(MaterialDocente(materialDocente = P(lambda x: x == 0)))
    def no_materialDocente(self):
        resultado = 0
        self.resultadoMaterialDocente = resultado
        print("resultado Material Docente = 0")
    
    @Rule(MaterialDocente(materialDocente = P(lambda x: x > 0)))
    def materialDocente(self):
        materialDocente = self.facts[1]['materialDocente']
        tipo = self.facts[2]['tipo']
        original = self.facts[3]['original']
        articulosRelacionados = self.facts[4]['articulosRelacionados']
        resultado = 0
        
        
        for i in tipo:
            if i == "Publicacion":
                resultado += 1
            elif i == "Libro":
                resultado += 1 
            elif i == "Otro":
                resultado += 0.5
        
        for i in original:
            if i == "Si":
                resultado += 0.5
            else:
                continue
        
        for i in articulosRelacionados:
            if (int(i) == 1):
                resultado += 0.25
            elif ((int(i) == 2) or (int(i) == 3)):
                resultado += 0.5
            elif (int(i) >= 4):
                resultado += 1
            else:
                continue
        
        resultado = round(resultado)
        if resultado > 7:
            resultado = 7

        self.resultadoMaterialDocente = resultado
        print("resultado = " + str(resultado))

class EvaluacionFormacion(KnowledgeEngine):
    resultadoFormacion = 0
    @Rule()
    def formacion(self):
        estudios = self.facts[1]['estudios']
        calificacion = self.facts[2]['calificacion']
        doctoradoEuropeo = self.facts[3]['doctoradoEuropeo']
        mencionCalidad = self.facts[4]['mencionCalidad']
        becas = self.facts[5]['becas']
        estanciasFuera = self.facts[6]['estanciasFuera']
        resultado = 0

        if estudios == 1:
            resultado = int(calificacion[0]) * 0.3
            if doctoradoEuropeo[0] == "Si":
                resultado += 0.5
            if mencionCalidad[0] == "Si":
                resultado += 0.5
            if ((becas[0] == "Predoctoral") or (becas[0] == "Postdoctoral")):
                resultado += 0.25
            elif ((becas[0] == "Predoctoral y Postdoctoral")):
                resultado += 0.5
            if (estanciasFuera[0] == "Si"): 
                resultado += 0.5
        
        elif estudios > 1:
            suma = 0
            for i in calificacion:
                suma += int(i)
            media = round(suma/estudios)
            resultado = media * 0.3
            for i in doctoradoEuropeo:
                if i == "Si":
                    resultado += 0.75
            for i in mencionCalidad:
                if i == "Si":
                    resultado += 0.75
            for i in becas:
                if ((i == "Predoctoral") or (i == "Postdoctoral")):
                    resultado += 0.5
                elif(i == "Predoctoral y Postdoctoral"):
                    resultado += 0.75
            for i in estanciasFuera:
                if (i == "Si"):
                    resultado += 0.75
        else:
            resultado = 0
        
        resultado = round(resultado)
        if resultado > 6:
            resultado = 6
        self.resultadoFormacion = resultado
        print("resultado = " + str(resultado))

class EvaluacionExperienciaProfesional(KnowledgeEngine):
    resultadoExperienciaProfesional = 0
    @Rule(ExperienciaProfesional(experienciasProfesionales = P(lambda x: x == 0)))
    def sin_experiencia_profesional(self):
        resultado = 0
        self.resultadoExperienciaProfesional = resultado
        print("resultado = 0")
    
    @Rule(ExperienciaProfesional(experienciasProfesionales = P(lambda x: x > 0)))
    def experiencia_profesional(self):
        experienciasProfesionales = self.facts[1]['experienciasProfesionales']
        institucionEmpresa = self.facts[2]['institucionEmpresa']
        duracion = self.facts[3]['duracion']
        responsabilidad = self.facts[4]['responsabilidad']
        resultado = 0

        tiempo = 0
        for i in duracion:
            tiempo += int(i)
            
        if (1 <= tiempo <= 3):
            resultado += 0.5
        elif (tiempo > 3):
            resultado += 1
        
        for i in responsabilidad:
            if (i == "Empleado"):
                resultado += 0.5
            elif (i == "Direccion"):
                resultado += 1
            else:
                continue
        
        resultado = round(resultado)
        if resultado > 2:
            resultado = 2

        self.resultadoExperienciaProfesional = resultado
        print("resultado = " + str(resultado))

class EvaluacionOtrosMeritos(KnowledgeEngine):
    resultadoOtrosMeritos = 0
    @Rule()
    def evaluacion_otros_meritos(self):
        resultado = 0
        otrosMeritosAcademicos = self.facts[1]['otrosMeritosAcademicos']
        otrosMeritosDocentes = self.facts[2]['otrosMeritosDocentes']
        otrosMeritosInvestigacion = self.facts[3]['otrosMeritosInvestigacion']
        otrosMeritosProfesionales = self.facts[4]['otrosMeritosProfesionales']

        for i in otrosMeritosAcademicos:
            if i == "Si":
                resultado += 0.5
        for i in otrosMeritosDocentes:
            if i == "Si":
                resultado += 0.5
        for i in otrosMeritosInvestigacion:
            if i == "Si":
                resultado += 0.5
        for i in otrosMeritosProfesionales:
            if i == "Si":
                resultado += 0.5

        resultado = round(resultado)
        self.resultadoOtrosMeritos = resultado
        print("resultado otros meritos = " + str(resultado))


#--PCD------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@app.route("/evaluacion-pcd", methods = ["GET", "POST"])
def evaluacion_pcd():
    if 'nombre' in session:
        resultado = 0
        if request.method == "POST":
            req = request.form
            especialidad = req["especialidad"]
            
            dataPublicaciones = [req["publicacion1"],req["publicacion2"],req["publicacion3"],req["publicacion4"],req["publicacion5"],req["publicacion6"],req["publicacion7"],req["publicacion8"],req["publicacion9"],req["publicacion10"],req["publicacion11"],req["publicacion12"]]
            dataTercil = [req["tercil1"],req["tercil2"],req["tercil3"],req["tercil4"],req["tercil5"],req["tercil6"],req["tercil7"],req["tercil8"],req["tercil9"],req["tercil10"],req["tercil11"],req["tercil12"]]
            dataFactor = [req["factor1"],req["factor2"],req["factor3"],req["factor4"],req["factor5"],req["factor6"],req["factor7"],req["factor8"],req["factor9"],req["factor10"],req["factor11"],req["factor12"]]
            dataAutores = [req["numeroAutores1"],req["numeroAutores2"],req["numeroAutores3"],req["numeroAutores4"],req["numeroAutores5"],req["numeroAutores6"], req["numeroAutores7"],req["numeroAutores8"],req["numeroAutores9"],req["numeroAutores10"],req["numeroAutores11"],req["numeroAutores12"]]
            dataContinua = [req["continua1"],req["continua2"],req["continua3"],req["continua4"],req["continua5"],req["continua6"],req["continua7"],req["continua8"],req["continua9"],req["continua10"],req["continua11"],req["continua12"]]

            publicaciones = int(len([i for i in dataPublicaciones if i]))
            tercil = [i for i in dataTercil if i]
            factor = [i for i in dataFactor if i]
            numeroAutores = [i for i in dataAutores if i]
            continua = [i for i in dataContinua if i]
            
            dataLibros = [req["libro1"],req["libro2"],req["libro3"],req["libro4"],req["libro5"],req["libro6"],req["libro7"],req["libro8"],req["libro9"]]
            dataIsbn = [req["isbn1"],req["isbn2"],req["isbn3"],req["isbn4"],req["isbn5"],req["isbn6"],req["isbn7"],req["isbn8"],req["isbn9"]]
            dataCitas = [req["citas1"],req["citas2"],req["citas3"],req["citas4"],req["citas5"],req["citas6"],req["citas7"],req["citas8"],req["citas9"]]
            dataTercilCitas = [req["tercilCitas1"],req["tercilCitas2"],req["tercilCitas3"],req["tercilCitas4"],req["tercilCitas5"],req["tercilCitas6"],req["tercilCitas7"],req["tercilCitas8"],req["tercilCitas9"]]
            dataTraducciones = [req["traducciones1"],req["traducciones2"],req["traducciones3"],req["traducciones4"],req["traducciones5"],req["traducciones6"],req["traducciones7"],req["traducciones8"],req["traducciones9"]]
            
            libros = int(len([i for i in dataLibros if i]))
            isbn = [i for i in dataIsbn if i]
            citas = [i for i in dataCitas if i]
            tercilCitas = [i for i in dataTercilCitas if i]
            traducciones = [i for i in dataTraducciones if i]

            dataProyectos = [req["proyecto1"],req["proyecto2"],req["proyecto3"],req["proyecto4"],req["proyecto5"],req["proyecto6"],req["proyecto7"],req["proyecto8"],req["proyecto9"]]
            dataTipoParticipacion = [req["tipoParticipacion1"],req["tipoParticipacion2"],req["tipoParticipacion3"],req["tipoParticipacion4"],req["tipoParticipacion5"],req["tipoParticipacion6"],req["tipoParticipacion7"],req["tipoParticipacion8"],req["tipoParticipacion9"]]
            dataOrganismo = [req["organismo1"],req["organismo2"],req["organismo3"],req["organismo4"],req["organismo5"],req["organismo6"],req["organismo7"],req["organismo8"],req["organismo9"]]
            dataGradoResponsabilidad = [req["gradoResp1"],req["gradoResp2"],req["gradoResp3"],req["gradoResp4"],req["gradoResp5"],req["gradoResp6"],req["gradoResp7"],req["gradoResp8"],req["gradoResp9"]]
            dataEvaluadorExterno = [req["evExt1"],req["evExt2"],req["evExt3"],req["evExt4"],req["evExt5"],req["evExt6"],req["evExt7"],req["evExt8"],req["evExt9"]]

            proyectos = int(len([i for i in dataProyectos if i]))
            tipoParticipacion = [i for i in dataTipoParticipacion if i]
            organismo = [i for i in dataOrganismo if i]
            gradoResponsabilidad = [i for i in dataGradoResponsabilidad if i]
            evaluadorExterno = [i for i in dataEvaluadorExterno if i]


            dataPatentes = [req["patente1"], req["patente2"], req["patente3"], req["patente4"], req["patente5"], req["patente6"]]
            dataExplotacion = [req["explotacion1"], req["explotacion2"], req["explotacion3"], req["explotacion4"], req["explotacion5"], req["explotacion6"]]
            dataCesion = [req["cesion1"], req["cesion2"], req["cesion3"], req["cesion4"], req["cesion5"], req["cesion6"]]
            dataLicencia = [req["licencia1"], req["licencia2"], req["licencia3"], req["licencia4"], req["licencia5"], req["licencia6"]]

            patentes = int(len([i for i in dataPatentes if i]))
            explotacion = [i for i in dataExplotacion if i]
            cesion = [i for i in dataCesion if i]
            licencia = [i for i in dataLicencia if i]

            dataTesis = [req["tesis1"], req["tesis2"], req["tesis3"],req["tesis4"], req["tesis5"], req["tesis6"]]
            dataDocEuropeo = [req["docEur1"], req["docEur2"], req["docEur3"],req["docEur4"], req["docEur5"], req["docEur6"]]
            dataEstado = [req["estado1"], req["estado2"], req["estado3"],req["estado4"], req["estado5"], req["estado6"]]
            datamCalidad = [req["mCalidad1"], req["mCalidad2"], req["mCalidad3"],req["mCalidad4"], req["mCalidad5"], req["mCalidad6"]]

            tesis = int(len([i for i in dataTesis if i]))
            doctoradoEuro = [i for i in dataDocEuropeo if i]
            estado = [i for i in dataEstado if i]
            mCalidad = [i for i in datamCalidad if i]

            dataEventos = [req["evento1"], req["evento2"], req["evento3"],req["evento4"], req["evento5"], req["evento6"]]
            dataProcesoAdmision = [req["procesoAdmision1"], req["procesoAdmision2"], req["procesoAdmision3"],req["procesoAdmision4"], req["procesoAdmision5"], req["procesoAdmision6"]]
            dataCaracter = [req["caracter1"], req["caracter2"], req["caracter3"],req["caracter4"], req["caracter5"], req["caracter6"]]
            dataParticipacion = [req["participacion1"], req["participacion2"], req["participacion3"],req["participacion4"], req["participacion5"], req["participacion6"]]

            eventos = int(len([i for i in dataEventos if i]))
            procesoAdmision = [i for i in dataProcesoAdmision if i]
            caracter = [i for i in dataCaracter if i]
            participacion = [i for i in dataParticipacion if i]

            dataExperienciasDocentes = [req["experiencia1"], req["experiencia2"], req["experiencia3"], req["experiencia4"]]
            dataCentroExp = [req["centroExp1"], req["centroExp2"], req["centroExp3"], req["centroExp4"]]
            dataHoras = [req["horas1"], req["horas2"], req["horas3"], req["horas4"]]
            dataMaster = [req["master1"], req["master2"], req["master3"], req["master4"]]
            dataDoctorado = [req["doctorado1"], req["doctorado2"], req["doctorado3"], req["doctorado4"]]


            experiencias = int(len([i for i in dataExperienciasDocentes if i]))
            centroExp = [i for i in dataCentroExp if i]
            master = [i for i in dataMaster if i]
            doctorado = [i for i in dataDoctorado if i]
            horas = [i for i in dataHoras if i]

            dataEvaluaciones = [req["evaluacion1"], req["evaluacion2"], req["evaluacion3"], req["evaluacion4"]]
            dataNotas = [req["nota1"], req["nota2"], req["nota3"], req["nota4"]]

            evaluaciones = int(len([i for i in dataEvaluaciones if i]))
            notas = [i for i in dataNotas if i]

            dataEventosDocentes = [req["eventoDocente1"], req["eventoDocente2"], req["eventoDocente3"], req["eventoDocente4"]]
            dataInvitacion = [req["invitacion1"], req["invitacion2"], req["invitacion3"], req["invitacion4"]]

            eventosDocentes = int(len([i for i in dataEventosDocentes if i]))
            invitacion = [i for i in dataInvitacion if i]

            dataOtrosMeritosInv = [req["otroMeritoInv1"], req["otroMeritoInv2"]]
            otrosMeritosInv = int(len([i for i in dataOtrosMeritosInv if i]))

            dataMaterialesDocentes = [req["matDoc1"],req["matDoc2"],req["matDoc3"],req["matDoc4"],req["matDoc5"],req["matDoc6"]]
            dataTipo = [req["tipo1"],req["tipo2"],req["tipo3"],req["tipo4"],req["tipo5"],req["tipo6"]]
            dataOriginal = [req["original1"],req["original2"],req["original3"],req["original4"],req["original5"],req["original6"]]
            dataArticulosRelacionados = [req["articulos1"],req["articulos2"],req["articulos3"],req["articulos4"],req["articulos5"],req["articulos6"]]

            materialDocente = int(len([i for i in dataMaterialesDocentes if i]))
            tipo = [i for i in dataTipo if i]
            original = [i for i in dataOriginal if i]
            articulosRelacionados = [i for i in dataArticulosRelacionados if i]

            dataEstudios = [req["estudios1"],req["estudios2"],req["estudios3"],req["estudios4"],req["estudios5"],req["estudios6"]]
            dataCalificacion = [req["calif1"],req["calif2"],req["calif3"],req["calif4"],req["calif5"],req["calif6"]]
            dataDoctoradoEuropeo = [req["DoctoradoE1"],req["DoctoradoE2"],req["DoctoradoE3"],req["DoctoradoE4"],req["DoctoradoE5"],req["DoctoradoE6"]]
            dataMencionCalidad = [req["MencionC1"],req["MencionC2"],req["MencionC3"],req["MencionC4"],req["MencionC5"],req["MencionC6"]]
            dataBecas = [req["becas1"],req["becas2"],req["becas3"],req["becas4"],req["becas5"],req["becas6"]]
            dataEstanciasFuera = [req["estanciasF1"],req["estanciasF2"],req["estanciasF3"],req["estanciasF4"],req["estanciasF5"],req["estanciasF6"]]

            estudios = int(len([i for i in dataEstudios if i]))
            calificacion = [i for i in dataCalificacion if i]
            doctoradoEuropeo = [i for i in dataDoctoradoEuropeo if i]
            mencionCalidad = [i for i in dataMencionCalidad if i]
            becas = [i for i in dataBecas if i]
            estanciasFuera = [i for i in dataEstanciasFuera if i]

            dataExperienciasProfesionales = [req["expProf1"],req["expProf2"],req["expProf3"],req["expProf4"]]
            dataInstitucionEmpresa = [req["inst1"],req["inst2"],req["inst3"],req["inst4"]]
            dataDuracion = [req["duracion1"],req["duracion2"],req["duracion3"],req["duracion4"]]
            dataResponsabilidad = [req["resp1"],req["resp2"],req["resp3"],req["resp4"]]

            experienciasProfesionales = int(len([i for i in dataExperienciasProfesionales if i]))
            institucionEmpresa = [i for i in dataInstitucionEmpresa if i]
            duracion = [i for i in dataDuracion if i]
            responsabilidad = [i for i in dataResponsabilidad if i]
            
            dataOtrosMeritosAcademicos = [req["otrosMA"]]
            dataOtrosMeritosDocentes = [req["otrosMD"]]
            dataOtrosMeritosInvestigacion = [req["otrosMI"]]
            dataOtrosMeritosProfesionales = [req["otrosMP"]]

            otrosMeritosAcademicos = [i for i in dataOtrosMeritosAcademicos if i]
            otrosMeritosDocentes = [i for i in dataOtrosMeritosDocentes if i]
            otrosMeritosInvestigacion = [i for i in dataOtrosMeritosInvestigacion if i]
            otrosMeritosProfesionales = [i for i in dataOtrosMeritosProfesionales if i]

            if especialidad == "no especialidad seleccionada":
                flash("Recuerde seleccionar una especialidad para poder continuar")
                return redirect(request.url)

            if especialidad == "Ciencias Experimentales":
                enginePublicaciones = EvaluacionPublicacionesCE()
                enginePublicaciones.reset()
                enginePublicaciones.declare(Publicaciones(publicaciones = publicaciones),Publicaciones(tercil = tercil), Publicaciones(factor = factor), Publicaciones(numeroAutores = numeroAutores), Publicaciones(continua = continua))
                enginePublicaciones.run()
                
                engineLibros = EvaluacionLibrosCE()
                engineLibros.reset()
                engineLibros.declare(Libros(libros = libros), Libros(isbn = isbn), Libros(citas = citas), Libros(tercilCitas = tercilCitas), Libros(traducciones = traducciones))
                engineLibros.run()

                engineProyectos = EvaluacionProyectosCE()
                engineProyectos.reset()
                engineProyectos.declare(Proyectos(proyectos = proyectos), Proyectos(tipoParticipacion = tipoParticipacion), Proyectos(organismo = organismo), Proyectos(gradoResponsabilidad = gradoResponsabilidad), Proyectos(evaluadorExterno = evaluadorExterno))
                engineProyectos.run()

                enginePatentes = EvaluacionPatentesCE()
                enginePatentes.reset()
                enginePatentes.declare(Patentes(patentes = patentes), Patentes(explotacion = explotacion), Patentes(cesion = cesion), Patentes(licencia = licencia))
                enginePatentes.run()

                engineTesis = EvaluacionTesisCE()
                engineTesis.reset()
                engineTesis.declare(Tesis(tesis = tesis), Tesis(doctoradoEuro = doctoradoEuro), Tesis(estado = estado), Tesis(mCalidad = mCalidad))
                engineTesis.run()

                engineEventos = EvaluacionEventosCE()
                engineEventos.reset()
                engineEventos.declare(Eventos(eventos = eventos), Eventos(procesoAdmision = procesoAdmision), Eventos(caracter = caracter), Eventos(participacion = participacion))
                engineEventos.run()

                engineOtrosMeritosInvCE = EvaluacionOtrosMeritosInvCE()
                engineOtrosMeritosInvCE.reset()
                engineOtrosMeritosInvCE.declare(OtrosMeritosInv(otrosMeritosInv = otrosMeritosInv))
                engineOtrosMeritosInvCE.run()
                
                engineExperiencia = EvaluacionExperiencias()
                engineExperiencia.reset()
                engineExperiencia.declare(Experiencias(experiencias = experiencias), Experiencias(centroExp = centroExp), Experiencias(master = master), Experiencias(doctorado = doctorado), Experiencias(horas = horas))
                engineExperiencia.run()

                engineEVCalidad = EvaluacionEVCalidad()
                engineEVCalidad.reset()
                engineEVCalidad.declare(Evaluaciones(evaluaciones = evaluaciones), Evaluaciones(notas = notas))
                engineEVCalidad.run()

                engineEventosDocentes = EvaluacionEventosDocentes()
                engineEventosDocentes.reset()
                engineEventosDocentes.declare(EventosDocentes(eventosDocentes = eventosDocentes), EventosDocentes(invitacion = invitacion))
                engineEventosDocentes.run()

                engineMaterialDocente = EvaluacionMaterialDocente()
                engineMaterialDocente.reset()
                engineMaterialDocente.declare(MaterialDocente(materialDocente = materialDocente), MaterialDocente(tipo = tipo), MaterialDocente(original = original), MaterialDocente(articulosRelacionados = articulosRelacionados))
                engineMaterialDocente.run()

                engineFormacion = EvaluacionFormacion()
                engineFormacion.reset()
                engineFormacion.declare(Formacion(estudios = estudios), Formacion(calificacion = calificacion), Formacion(doctoradoEuropeo = doctoradoEuropeo), Formacion(mencionCalidad = mencionCalidad), Formacion(becas = becas), Formacion(estanciasFuera = estanciasFuera))
                engineFormacion.run()

                engineExperienciaProfesional = EvaluacionExperienciaProfesional()
                engineExperienciaProfesional.reset()
                engineExperienciaProfesional.declare(ExperienciaProfesional(experienciasProfesionales = experienciasProfesionales), ExperienciaProfesional(institucionEmpresa = institucionEmpresa), ExperienciaProfesional(duracion = duracion), ExperienciaProfesional(responsabilidad = responsabilidad))
                engineExperienciaProfesional.run()

                engineOtrosMeritos = EvaluacionOtrosMeritos()
                engineOtrosMeritos.reset()
                engineOtrosMeritos.declare(OtrosMeritos(otrosMeritosAcademicos = otrosMeritosAcademicos), OtrosMeritos(otrosMeritosDocentes = otrosMeritosDocentes), OtrosMeritos(otrosMeritosInvestigacion = otrosMeritosInvestigacion), OtrosMeritos(otrosMeritosProfesionales = otrosMeritosProfesionales))
                engineOtrosMeritos.run()

                resultadoParcial = enginePublicaciones.resultadoPublicaciones + engineLibros.resultadoLibros + engineProyectos.resultadoProyectos + enginePatentes.resultadoPatentes + engineTesis.resultadoTesis + engineEventos.resultadoEventos + engineOtrosMeritosInvCE.resultadoOtrosMeritosInvCE + engineExperiencia.resultadoExperiencias + engineEVCalidad.resultadoEVCalidad + engineEventosDocentes.resultadoEventosDocentes + engineMaterialDocente.resultadoMaterialDocente
                resultado = enginePublicaciones.resultadoPublicaciones + engineLibros.resultadoLibros + engineProyectos.resultadoProyectos + enginePatentes.resultadoPatentes + engineTesis.resultadoTesis + engineEventos.resultadoEventos + engineExperiencia.resultadoExperiencias + engineEVCalidad.resultadoEVCalidad + engineEventosDocentes.resultadoEventosDocentes + engineMaterialDocente.resultadoMaterialDocente + engineFormacion.resultadoFormacion + engineExperienciaProfesional.resultadoExperienciaProfesional + engineOtrosMeritos.resultadoOtrosMeritos



                cur = mysql.get_db().cursor()
        
                sQuery = "SELECT email, resultado, resultadoparcial, especialidad FROM resultadospcd WHERE email = %s"

                cur.execute(sQuery, [session.get('email')])

                resultadoG = cur.fetchall()
    
                cur.close()
                
                if len(resultadoG) < 3:

                    cur = mysql.get_db().cursor()
        
                    cur.execute('INSERT INTO resultadospcd (email, resultado, resultadoparcial, especialidad) VALUES ( %s, %s, %s, %s)', (session.get('email'), resultado, resultadoParcial, especialidad))

                    mysql.get_db().commit()
                
                else:

                    cur = mysql.get_db().cursor()

                    sQuery2 = "DELETE FROM resultadospcd WHERE email = %s LIMIT 1"
                    
                    cur.execute(sQuery2, [session.get('email')])

                    cur.execute('INSERT INTO resultadospcd (email, resultado, resultadoparcial, especialidad) VALUES ( %s, %s, %s, %s)', (session.get('email'), resultado, resultadoParcial, especialidad))

                    mysql.get_db().commit()


                return redirect(url_for('resultados_pcd', especialidad = especialidad, resultado = resultado, resultadoParcial = resultadoParcial))
            
            if especialidad == "Ciencias de la Salud":
                enginePublicacionesCS = EvaluacionPublicacionesCS()
                enginePublicacionesCS.reset()
                enginePublicacionesCS.declare(Publicaciones(publicaciones = publicaciones), Publicaciones(tercil = tercil))
                enginePublicacionesCS.run()

                engineLibrosCS = EvaluacionLibrosCS()
                engineLibrosCS.reset()
                engineLibrosCS.declare(Libros(libros = libros), Libros(isbn = isbn), Libros(citas = citas), Libros(tercilCitas = tercilCitas), Libros(traducciones = traducciones))
                engineLibrosCS.run()

                engineProyectosCS = EvaluacionProyectosCS()
                engineProyectosCS.reset()
                engineProyectosCS.declare(Proyectos(proyectos = proyectos), Proyectos(tipoParticipacion = tipoParticipacion), Proyectos(organismo = organismo), Proyectos(gradoResponsabilidad = gradoResponsabilidad), Proyectos(evaluadorExterno = evaluadorExterno))
                engineProyectosCS.run()

                enginePatentesCS = EvaluacionPatentesCS()
                enginePatentesCS.reset()
                enginePatentesCS.declare(Patentes(patentes = patentes), Patentes(explotacion = explotacion), Patentes(cesion = cesion), Patentes(licencia = licencia))
                enginePatentesCS.run()

                engineTesisCS = EvaluacionTesisCS()
                engineTesisCS.reset()
                engineTesisCS.declare(Tesis(tesis = tesis), Tesis(doctoradoEuro = doctoradoEuro), Tesis(estado = estado), Tesis(mCalidad = mCalidad))
                engineTesisCS.run()

                engineEventosCS = EvaluacionEventosCS()
                engineEventosCS.reset()
                engineEventosCS.declare(Eventos(eventos = eventos), Eventos(procesoAdmision = procesoAdmision), Eventos(caracter = caracter), Eventos(participacion = participacion))
                engineEventosCS.run()

                engineOtrosMeritosInvCS = EvaluacionOtrosMeritosInvCS()
                engineOtrosMeritosInvCS.reset()
                engineOtrosMeritosInvCS.declare(OtrosMeritosInv(otrosMeritosInv = otrosMeritosInv))
                engineOtrosMeritosInvCS.run()

                engineExperiencia = EvaluacionExperiencias()
                engineExperiencia.reset()
                engineExperiencia.declare(Experiencias(experiencias = experiencias), Experiencias(centroExp = centroExp), Experiencias(master = master), Experiencias(doctorado = doctorado), Experiencias(horas = horas))
                engineExperiencia.run()

                engineEVCalidad = EvaluacionEVCalidad()
                engineEVCalidad.reset()
                engineEVCalidad.declare(Evaluaciones(evaluaciones = evaluaciones), Evaluaciones(notas = notas))
                engineEVCalidad.run()

                engineEventosDocentes = EvaluacionEventosDocentes()
                engineEventosDocentes.reset()
                engineEventosDocentes.declare(EventosDocentes(eventosDocentes = eventosDocentes), EventosDocentes(invitacion = invitacion))
                engineEventosDocentes.run()

                engineMaterialDocente = EvaluacionMaterialDocente()
                engineMaterialDocente.reset()
                engineMaterialDocente.declare(MaterialDocente(materialDocente = materialDocente), MaterialDocente(tipo = tipo), MaterialDocente(original = original), MaterialDocente(articulosRelacionados = articulosRelacionados))
                engineMaterialDocente.run()

                engineFormacion = EvaluacionFormacion()
                engineFormacion.reset()
                engineFormacion.declare(Formacion(estudios = estudios), Formacion(calificacion = calificacion), Formacion(doctoradoEuropeo = doctoradoEuropeo), Formacion(mencionCalidad = mencionCalidad), Formacion(becas = becas), Formacion(estanciasFuera = estanciasFuera))
                engineFormacion.run()

                engineExperienciaProfesional = EvaluacionExperienciaProfesional()
                engineExperienciaProfesional.reset()
                engineExperienciaProfesional.declare(ExperienciaProfesional(experienciasProfesionales = experienciasProfesionales), ExperienciaProfesional(institucionEmpresa = institucionEmpresa), ExperienciaProfesional(duracion = duracion), ExperienciaProfesional(responsabilidad = responsabilidad))
                engineExperienciaProfesional.run()

                engineOtrosMeritos = EvaluacionOtrosMeritos()
                engineOtrosMeritos.reset()
                engineOtrosMeritos.declare(OtrosMeritos(otrosMeritosAcademicos = otrosMeritosAcademicos), OtrosMeritos(otrosMeritosDocentes = otrosMeritosDocentes), OtrosMeritos(otrosMeritosInvestigacion = otrosMeritosInvestigacion), OtrosMeritos(otrosMeritosProfesionales = otrosMeritosProfesionales))
                engineOtrosMeritos.run()

                resultadoParcial = enginePublicacionesCS.resultadoPublicacionesCS + engineLibrosCS.resultadoLibrosCS + engineProyectosCS.resultadoProyectosCS + enginePatentesCS.resultadoPatentesCS + engineTesisCS.resultadoTesisCS + engineEventosCS.resultadoEventosCS + engineOtrosMeritosInvCS.resultadoOtrosMeritosInvCS + engineExperiencia.resultadoExperiencias + engineEVCalidad.resultadoEVCalidad + engineEventosDocentes.resultadoEventosDocentes + engineMaterialDocente.resultadoMaterialDocente
                resultado = enginePublicacionesCS.resultadoPublicacionesCS + engineLibrosCS.resultadoLibrosCS + engineProyectosCS.resultadoProyectosCS + enginePatentesCS.resultadoPatentesCS + engineTesisCS.resultadoTesisCS + engineEventosCS.resultadoEventosCS + engineExperiencia.resultadoExperiencias + engineEVCalidad.resultadoEVCalidad + engineEventosDocentes.resultadoEventosDocentes + engineMaterialDocente.resultadoMaterialDocente + engineFormacion.resultadoFormacion + engineExperienciaProfesional.resultadoExperienciaProfesional + engineOtrosMeritos.resultadoOtrosMeritos
                
                cur = mysql.get_db().cursor()
        
                sQuery = "SELECT email, resultado, resultadoparcial, especialidad FROM resultadospcd WHERE email = %s"

                cur.execute(sQuery, [session.get('email')])

                resultadoG = cur.fetchall()
    
                cur.close()
                
                if len(resultadoG) < 3:

                    cur = mysql.get_db().cursor()
        
                    cur.execute('INSERT INTO resultadospcd (email, resultado, resultadoparcial, especialidad) VALUES ( %s, %s, %s, %s)', (session.get('email'), resultado, resultadoParcial, especialidad))

                    mysql.get_db().commit()
                
                else:

                    cur = mysql.get_db().cursor()

                    sQuery2 = "DELETE FROM resultadospcd WHERE email = %s LIMIT 1"
                    
                    cur.execute(sQuery2, [session.get('email')])

                    cur.execute('INSERT INTO resultadospcd (email, resultado, resultadoparcial, especialidad) VALUES ( %s, %s, %s, %s)', (session.get('email'), resultado, resultadoParcial, especialidad))

                    mysql.get_db().commit()


                return redirect(url_for('resultados_pcd', especialidad = especialidad, resultado = resultado, resultadoParcial = resultadoParcial))

            if especialidad == "Enseñanzas Técnicas":
                enginePublicacionesET = EvaluacionPublicacionesET()
                enginePublicacionesET.reset()
                enginePublicacionesET.declare(Publicaciones(publicaciones = publicaciones), Publicaciones(tercil = tercil), Publicaciones(factor = factor), Publicaciones(numeroAutores = numeroAutores), Publicaciones(continua = continua))
                enginePublicacionesET.run()

                engineLibrosET = EvaluacionLibrosET()
                engineLibrosET.reset()
                engineLibrosET.declare(Libros(libros = libros), Libros(isbn = isbn), Libros(citas = citas), Libros(traducciones = traducciones))
                engineLibrosET.run()
                    
                engineProyectosET = EvaluacionProyectosET()
                engineProyectosET.reset()
                engineProyectosET.declare(Proyectos(proyectos = proyectos), Proyectos(tipoParticipacion = tipoParticipacion), Proyectos(organismo = organismo), Proyectos(gradoResponsabilidad = gradoResponsabilidad), Proyectos(evaluadorExterno = evaluadorExterno))
                engineProyectosET.run()
                    
                enginePatentesET = EvaluacionPatentesET()
                enginePatentesET.reset()
                enginePatentesET.declare(Patentes(patentes = patentes), Patentes(explotacion = explotacion), Patentes(cesion = cesion), Patentes(licencia = licencia))
                enginePatentesET.run()

                engineTesisET = EvaluacionTesisET()
                engineTesisET.reset()
                engineTesisET.declare(Tesis(tesis = tesis), Tesis(doctoradoEuro = doctoradoEuro), Tesis(estado = estado), Tesis(mCalidad = mCalidad))
                engineTesisET.run()
                    
                engineEventosET = EvaluacionEventosET()
                engineEventosET.reset()
                engineEventosET.declare(Eventos(eventos = eventos), Eventos(procesoAdmision = procesoAdmision), Eventos(caracter = caracter), Eventos(participacion = participacion))
                engineEventosET.run()

                engineOtrosMeritosInvET = EvaluacionOtrosMeritosInvET()
                engineOtrosMeritosInvET.reset()
                engineOtrosMeritosInvET.declare(OtrosMeritosInv(otrosMeritosInv = otrosMeritosInv))
                engineOtrosMeritosInvET.run()

                engineExperiencia = EvaluacionExperiencias()
                engineExperiencia.reset()
                engineExperiencia.declare(Experiencias(experiencias = experiencias), Experiencias(centroExp = centroExp), Experiencias(master = master), Experiencias(doctorado = doctorado), Experiencias(horas = horas))
                engineExperiencia.run()

                engineEVCalidad = EvaluacionEVCalidad()
                engineEVCalidad.reset()
                engineEVCalidad.declare(Evaluaciones(evaluaciones = evaluaciones), Evaluaciones(notas = notas))
                engineEVCalidad.run()

                engineEventosDocentes = EvaluacionEventosDocentes()
                engineEventosDocentes.reset()
                engineEventosDocentes.declare(EventosDocentes(eventosDocentes = eventosDocentes), EventosDocentes(invitacion = invitacion))
                engineEventosDocentes.run()

                engineMaterialDocente = EvaluacionMaterialDocente()
                engineMaterialDocente.reset()
                engineMaterialDocente.declare(MaterialDocente(materialDocente = materialDocente), MaterialDocente(tipo = tipo), MaterialDocente(original = original), MaterialDocente(articulosRelacionados = articulosRelacionados))
                engineMaterialDocente.run()

                engineFormacion = EvaluacionFormacion()
                engineFormacion.reset()
                engineFormacion.declare(Formacion(estudios = estudios), Formacion(calificacion = calificacion), Formacion(doctoradoEuropeo = doctoradoEuropeo), Formacion(mencionCalidad = mencionCalidad), Formacion(becas = becas), Formacion(estanciasFuera = estanciasFuera))
                engineFormacion.run()

                engineExperienciaProfesional = EvaluacionExperienciaProfesional()
                engineExperienciaProfesional.reset()
                engineExperienciaProfesional.declare(ExperienciaProfesional(experienciasProfesionales = experienciasProfesionales), ExperienciaProfesional(institucionEmpresa = institucionEmpresa), ExperienciaProfesional(duracion = duracion), ExperienciaProfesional(responsabilidad = responsabilidad))
                engineExperienciaProfesional.run()

                engineOtrosMeritos = EvaluacionOtrosMeritos()
                engineOtrosMeritos.reset()
                engineOtrosMeritos.declare(OtrosMeritos(otrosMeritosAcademicos = otrosMeritosAcademicos), OtrosMeritos(otrosMeritosDocentes = otrosMeritosDocentes), OtrosMeritos(otrosMeritosInvestigacion = otrosMeritosInvestigacion), OtrosMeritos(otrosMeritosProfesionales = otrosMeritosProfesionales))
                engineOtrosMeritos.run()

                resultadoParcial = enginePublicacionesET.resultadoPublicacionesET + engineLibrosET.resultadoLibrosET + engineProyectosET.resultadoProyectosET + enginePatentesET.resultadoPatentesET + engineTesisET.resultadoTesisET + engineEventosET.resultadoEventosET + engineOtrosMeritosInvET.resultadoOtrosMeritosInvET + engineExperiencia.resultadoExperiencias + engineEVCalidad.resultadoEVCalidad + engineEventosDocentes.resultadoEventosDocentes + engineMaterialDocente.resultadoMaterialDocente
                resultado = enginePublicacionesET.resultadoPublicacionesET + engineLibrosET.resultadoLibrosET + engineProyectosET.resultadoProyectosET + enginePatentesET.resultadoPatentesET + engineTesisET.resultadoTesisET + engineEventosET.resultadoEventosET + engineExperiencia.resultadoExperiencias + engineEVCalidad.resultadoEVCalidad + engineEventosDocentes.resultadoEventosDocentes + engineMaterialDocente.resultadoMaterialDocente + engineFormacion.resultadoFormacion + engineExperienciaProfesional.resultadoExperienciaProfesional + engineOtrosMeritos.resultadoOtrosMeritos
                
                cur = mysql.get_db().cursor()
        
                sQuery = "SELECT email, resultado, resultadoparcial, especialidad FROM resultadospcd WHERE email = %s"

                cur.execute(sQuery, [session.get('email')])

                resultadoG = cur.fetchall()
    
                cur.close()
                
                if len(resultadoG) < 3:

                    cur = mysql.get_db().cursor()
        
                    cur.execute('INSERT INTO resultadospcd (email, resultado, resultadoparcial, especialidad) VALUES ( %s, %s, %s, %s)', (session.get('email'), resultado, resultadoParcial, especialidad))

                    mysql.get_db().commit()
                
                else:

                    cur = mysql.get_db().cursor()

                    sQuery2 = "DELETE FROM resultadospcd WHERE email = %s LIMIT 1"
                    
                    cur.execute(sQuery2, [session.get('email')])

                    cur.execute('INSERT INTO resultadospcd (email, resultado, resultadoparcial, especialidad) VALUES ( %s, %s, %s, %s)', (session.get('email'), resultado, resultadoParcial, especialidad))

                    mysql.get_db().commit()



                return redirect(url_for('resultados_pcd', especialidad = especialidad, resultado = resultado, resultadoParcial = resultadoParcial))
                
            if especialidad == "Ciencias Sociales y Jurídicas":
                enginePublicacionesSJ = EvaluacionPublicacionesSJ()
                enginePublicacionesSJ.reset()
                enginePublicacionesSJ.declare(Publicaciones(publicaciones = publicaciones),Publicaciones(tercil = tercil), Publicaciones(factor = factor), Publicaciones(numeroAutores = numeroAutores), Publicaciones(continua = continua))
                enginePublicacionesSJ.run()

                engineLibrosSJ = EvaluacionLibrosSJ()
                engineLibrosSJ.reset()
                engineLibrosSJ.declare(Libros(libros = libros), Libros(isbn = isbn), Libros(citas = citas), Libros(tercilCitas = tercilCitas), Libros(traducciones = traducciones))
                engineLibrosSJ.run()

                engineProyectosSJ = EvaluacionProyectosSJ()
                engineProyectosSJ.reset()
                engineProyectosSJ.declare(Proyectos(proyectos = proyectos), Proyectos(tipoParticipacion = tipoParticipacion), Proyectos(organismo = organismo), Proyectos(gradoResponsabilidad = gradoResponsabilidad), Proyectos(evaluadorExterno = evaluadorExterno))
                engineProyectosSJ.run()

                enginePatentesSJ = EvaluacionPatentesSJ()
                enginePatentesSJ.reset()
                enginePatentesSJ.declare(Patentes(patentes = patentes), Patentes(explotacion = explotacion), Patentes(cesion = cesion), Patentes(licencia = licencia))
                enginePatentesSJ.run()

                engineTesisSJ = EvaluacionTesisSJ()
                engineTesisSJ.reset()
                engineTesisSJ.declare(Tesis(tesis = tesis), Tesis(doctoradoEuro = doctoradoEuro), Tesis(estado = estado), Tesis(mCalidad = mCalidad))
                engineTesisSJ.run()
                    
                engineEventosSJ = EvaluacionEventosSJ()
                engineEventosSJ.reset()
                engineEventosSJ.declare(Eventos(eventos = eventos), Eventos(procesoAdmision = procesoAdmision), Eventos(caracter = caracter), Eventos(participacion = participacion))
                engineEventosSJ.run()

                engineOtrosMeritosInvSJ = EvaluacionOtrosMeritosInvSJ()
                engineOtrosMeritosInvSJ.reset()
                engineOtrosMeritosInvSJ.declare(OtrosMeritosInv(otrosMeritosInv = otrosMeritosInv))
                engineOtrosMeritosInvSJ.run()

                engineExperiencia = EvaluacionExperiencias()
                engineExperiencia.reset()
                engineExperiencia.declare(Experiencias(experiencias = experiencias), Experiencias(centroExp = centroExp), Experiencias(master = master), Experiencias(doctorado = doctorado), Experiencias(horas = horas))
                engineExperiencia.run()
                
                engineEVCalidad = EvaluacionEVCalidad()
                engineEVCalidad.reset()
                engineEVCalidad.declare(Evaluaciones(evaluaciones = evaluaciones), Evaluaciones(notas = notas))
                engineEVCalidad.run()

                engineEventosDocentes = EvaluacionEventosDocentes()
                engineEventosDocentes.reset()
                engineEventosDocentes.declare(EventosDocentes(eventosDocentes = eventosDocentes), EventosDocentes(invitacion = invitacion))
                engineEventosDocentes.run()

                engineMaterialDocente = EvaluacionMaterialDocente()
                engineMaterialDocente.reset()
                engineMaterialDocente.declare(MaterialDocente(materialDocente = materialDocente), MaterialDocente(tipo = tipo), MaterialDocente(original = original), MaterialDocente(articulosRelacionados = articulosRelacionados))
                engineMaterialDocente.run()

                engineFormacion = EvaluacionFormacion()
                engineFormacion.reset()
                engineFormacion.declare(Formacion(estudios = estudios), Formacion(calificacion = calificacion), Formacion(doctoradoEuropeo = doctoradoEuropeo), Formacion(mencionCalidad = mencionCalidad), Formacion(becas = becas), Formacion(estanciasFuera = estanciasFuera))
                engineFormacion.run()

                engineExperienciaProfesional = EvaluacionExperienciaProfesional()
                engineExperienciaProfesional.reset()
                engineExperienciaProfesional.declare(ExperienciaProfesional(experienciasProfesionales = experienciasProfesionales), ExperienciaProfesional(institucionEmpresa = institucionEmpresa), ExperienciaProfesional(duracion = duracion), ExperienciaProfesional(responsabilidad = responsabilidad))
                engineExperienciaProfesional.run()

                engineOtrosMeritos = EvaluacionOtrosMeritos()
                engineOtrosMeritos.reset()
                engineOtrosMeritos.declare(OtrosMeritos(otrosMeritosAcademicos = otrosMeritosAcademicos), OtrosMeritos(otrosMeritosDocentes = otrosMeritosDocentes), OtrosMeritos(otrosMeritosInvestigacion = otrosMeritosInvestigacion), OtrosMeritos(otrosMeritosProfesionales = otrosMeritosProfesionales))
                engineOtrosMeritos.run()

                resultadoParcial = enginePublicacionesSJ.resultadoPublicacionesSJ + engineLibrosSJ.resultadoLibrosSJ + engineProyectosSJ.resultadoProyectosSJ + enginePatentesSJ.resultadoPatentesSJ + engineTesisSJ.resultadoTesisSJ + engineEventosSJ.resultadoEventosSJ + engineOtrosMeritosInvSJ.resultadoOtrosMeritosInvSJ + engineExperiencia.resultadoExperiencias + engineEVCalidad.resultadoEVCalidad + engineEventosDocentes.resultadoEventosDocentes + engineMaterialDocente.resultadoMaterialDocente + engineFormacion.resultadoFormacion
                resultado = enginePublicacionesSJ.resultadoPublicacionesSJ + engineLibrosSJ.resultadoLibrosSJ + engineProyectosSJ.resultadoProyectosSJ + enginePatentesSJ.resultadoPatentesSJ + engineTesisSJ.resultadoTesisSJ + engineEventosSJ.resultadoEventosSJ + engineExperiencia.resultadoExperiencias + engineEVCalidad.resultadoEVCalidad + engineEventosDocentes.resultadoEventosDocentes + engineMaterialDocente.resultadoMaterialDocente + engineFormacion.resultadoFormacion + engineExperienciaProfesional.resultadoExperienciaProfesional + engineOtrosMeritos.resultadoOtrosMeritos
                
                cur = mysql.get_db().cursor()
        
                sQuery = "SELECT email, resultado, resultadoparcial, especialidad FROM resultadospcd WHERE email = %s"

                cur.execute(sQuery, [session.get('email')])

                resultadoG = cur.fetchall()
    
                cur.close()
                
                if len(resultadoG) < 3:

                    cur = mysql.get_db().cursor()
        
                    cur.execute('INSERT INTO resultadospcd (email, resultado, resultadoparcial, especialidad) VALUES ( %s, %s, %s, %s)', (session.get('email'), resultado, resultadoParcial, especialidad))

                    mysql.get_db().commit()
                
                else:

                    cur = mysql.get_db().cursor()

                    sQuery2 = "DELETE FROM resultadospcd WHERE email = %s LIMIT 1"
                    
                    cur.execute(sQuery2, [session.get('email')])

                    cur.execute('INSERT INTO resultadospcd (email, resultado, resultadoparcial, especialidad) VALUES ( %s, %s, %s, %s)', (session.get('email'), resultado, resultadoParcial, especialidad))

                    mysql.get_db().commit()


                return redirect(url_for('resultados_pcd', especialidad = especialidad, resultado = resultado, resultadoParcial = resultadoParcial))

            if especialidad == "Humanidades":
                enginePublicacionesH = EvaluacionPublicacionesH()
                enginePublicacionesH.reset()
                enginePublicacionesH.declare(Publicaciones(publicaciones = publicaciones),Publicaciones(tercil = tercil), Publicaciones(factor = factor), Publicaciones(numeroAutores = numeroAutores), Publicaciones(continua = continua))
                enginePublicacionesH.run()

                engineLibrosH = EvaluacionLibrosH()
                engineLibrosH.reset()
                engineLibrosH.declare(Libros(libros = libros), Libros(isbn = isbn), Libros(citas = citas), Libros(tercilCitas = tercilCitas), Libros(traducciones = traducciones))
                engineLibrosH.run()

                engineProyectosH = EvaluacionProyectosH()
                engineProyectosH.reset()
                engineProyectosH.declare(Proyectos(proyectos = proyectos), Proyectos(tipoParticipacion = tipoParticipacion), Proyectos(organismo = organismo), Proyectos(gradoResponsabilidad = gradoResponsabilidad), Proyectos(evaluadorExterno = evaluadorExterno))
                engineProyectosH.run()

                enginePatentesH = EvaluacionPatentesH()
                enginePatentesH.reset()
                enginePatentesH.declare(Patentes(patentes = patentes), Patentes(explotacion = explotacion), Patentes(cesion = cesion), Patentes(licencia = licencia))
                enginePatentesH.run()

                engineTesisH = EvaluacionTesisH()
                engineTesisH.reset()
                engineTesisH.declare(Tesis(tesis = tesis), Tesis(doctoradoEuro = doctoradoEuro), Tesis(estado = estado), Tesis(mCalidad = mCalidad))
                engineTesisH.run()
                    
                engineEventosH = EvaluacionEventosH()
                engineEventosH.reset()
                engineEventosH.declare(Eventos(eventos = eventos), Eventos(procesoAdmision = procesoAdmision), Eventos(caracter = caracter), Eventos(participacion = participacion))
                engineEventosH.run()

                engineOtrosMeritosInvH = EvaluacionOtrosMeritosInvH()
                engineOtrosMeritosInvH.reset()
                engineOtrosMeritosInvH.declare(OtrosMeritosInv(otrosMeritosInv = otrosMeritosInv))
                engineOtrosMeritosInvH.run()

                engineExperiencia = EvaluacionExperiencias()
                engineExperiencia.reset()
                engineExperiencia.declare(Experiencias(experiencias = experiencias), Experiencias(centroExp = centroExp), Experiencias(master = master), Experiencias(doctorado = doctorado), Experiencias(horas = horas))
                engineExperiencia.run()

                engineEVCalidad = EvaluacionEVCalidad()
                engineEVCalidad.reset()
                engineEVCalidad.declare(Evaluaciones(evaluaciones = evaluaciones), Evaluaciones(notas = notas))
                engineEVCalidad.run()

                engineEventosDocentes = EvaluacionEventosDocentes()
                engineEventosDocentes.reset()
                engineEventosDocentes.declare(EventosDocentes(eventosDocentes = eventosDocentes), EventosDocentes(invitacion = invitacion))
                engineEventosDocentes.run()

                engineMaterialDocente = EvaluacionMaterialDocente()
                engineMaterialDocente.reset()
                engineMaterialDocente.declare(MaterialDocente(materialDocente = materialDocente), MaterialDocente(tipo = tipo), MaterialDocente(original = original), MaterialDocente(articulosRelacionados = articulosRelacionados))
                engineMaterialDocente.run()

                engineFormacion = EvaluacionFormacion()
                engineFormacion.reset()
                engineFormacion.declare(Formacion(estudios = estudios), Formacion(calificacion = calificacion), Formacion(doctoradoEuropeo = doctoradoEuropeo), Formacion(mencionCalidad = mencionCalidad), Formacion(becas = becas), Formacion(estanciasFuera = estanciasFuera))
                engineFormacion.run()

                engineExperienciaProfesional = EvaluacionExperienciaProfesional()
                engineExperienciaProfesional.reset()
                engineExperienciaProfesional.declare(ExperienciaProfesional(experienciasProfesionales = experienciasProfesionales), ExperienciaProfesional(institucionEmpresa = institucionEmpresa), ExperienciaProfesional(duracion = duracion), ExperienciaProfesional(responsabilidad = responsabilidad))
                engineExperienciaProfesional.run()

                engineOtrosMeritos = EvaluacionOtrosMeritos()
                engineOtrosMeritos.reset()
                engineOtrosMeritos.declare(OtrosMeritos(otrosMeritosAcademicos = otrosMeritosAcademicos), OtrosMeritos(otrosMeritosDocentes = otrosMeritosDocentes), OtrosMeritos(otrosMeritosInvestigacion = otrosMeritosInvestigacion), OtrosMeritos(otrosMeritosProfesionales = otrosMeritosProfesionales))
                engineOtrosMeritos.run()

                resultadoParcial = enginePublicacionesH.resultadoPublicacionesH + engineLibrosH.resultadoLibrosH + engineProyectosH.resultadoProyectosH + enginePatentesH.resultadoPatentesH + engineTesisH.resultadoTesisH + engineEventosH.resultadoEventosH + engineOtrosMeritosInvH.resultadoOtrosMeritosInvH + engineExperiencia.resultadoExperiencias + engineEVCalidad.resultadoEVCalidad + engineEventosDocentes.resultadoEventosDocentes + engineMaterialDocente.resultadoMaterialDocente + engineFormacion.resultadoFormacion
                resultado = enginePublicacionesH.resultadoPublicacionesH + engineLibrosH.resultadoLibrosH + engineProyectosH.resultadoProyectosH + enginePatentesH.resultadoPatentesH + engineTesisH.resultadoTesisH + engineEventosH.resultadoEventosH + engineExperiencia.resultadoExperiencias + engineEVCalidad.resultadoEVCalidad + engineEventosDocentes.resultadoEventosDocentes + engineMaterialDocente.resultadoMaterialDocente + engineFormacion.resultadoFormacion + engineExperienciaProfesional.resultadoExperienciaProfesional + engineOtrosMeritos.resultadoOtrosMeritos
                
                cur = mysql.get_db().cursor()
        
                sQuery = "SELECT email, resultado, resultadoparcial, especialidad FROM resultadospcd WHERE email = %s"

                cur.execute(sQuery, [session.get('email')])

                resultadoG = cur.fetchall()
    
                cur.close()
                
                if len(resultadoG) < 3:

                    cur = mysql.get_db().cursor()
        
                    cur.execute('INSERT INTO resultadospcd (email, resultado, resultadoparcial, especialidad) VALUES ( %s, %s, %s, %s)', (session.get('email'), resultado, resultadoParcial, especialidad))

                    mysql.get_db().commit()
                
                else:

                    cur = mysql.get_db().cursor()

                    sQuery2 = "DELETE FROM resultadospcd WHERE email = %s LIMIT 1"
                    
                    cur.execute(sQuery2, [session.get('email')])

                    cur.execute('INSERT INTO resultadospcd (email, resultado, resultadoparcial, especialidad) VALUES ( %s, %s, %s, %s)', (session.get('email'), resultado, resultadoParcial, especialidad))

                    mysql.get_db().commit()



                return redirect(url_for('resultados_pcd', especialidad = especialidad, resultado = resultado, resultadoParcial = resultadoParcial))

            
        
        else:
            return render_template("usuario/form-pcd.html")

    else:
        return render_template('public/ingresar.html')

#--PUP------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@app.route("/evaluacion-pup", methods = ["GET", "POST"])
def evaluacion_pup():
    if 'nombre' in session:
        resultado = 0
        if request.method == "POST":
            req = request.form
            especialidad = req["especialidad"]
            
            dataPublicaciones = [req["publicacion1"],req["publicacion2"],req["publicacion3"],req["publicacion4"],req["publicacion5"],req["publicacion6"],req["publicacion7"],req["publicacion8"],req["publicacion9"],req["publicacion10"],req["publicacion11"],req["publicacion12"]]
            dataTercil = [req["tercil1"],req["tercil2"],req["tercil3"],req["tercil4"],req["tercil5"],req["tercil6"],req["tercil7"],req["tercil8"],req["tercil9"],req["tercil10"],req["tercil11"],req["tercil12"]]
            dataFactor = [req["factor1"],req["factor2"],req["factor3"],req["factor4"],req["factor5"],req["factor6"],req["factor7"],req["factor8"],req["factor9"],req["factor10"],req["factor11"],req["factor12"]]
            dataAutores = [req["numeroAutores1"],req["numeroAutores2"],req["numeroAutores3"],req["numeroAutores4"],req["numeroAutores5"],req["numeroAutores6"], req["numeroAutores7"],req["numeroAutores8"],req["numeroAutores9"],req["numeroAutores10"],req["numeroAutores11"],req["numeroAutores12"]]
            dataContinua = [req["continua1"],req["continua2"],req["continua3"],req["continua4"],req["continua5"],req["continua6"],req["continua7"],req["continua8"],req["continua9"],req["continua10"],req["continua11"],req["continua12"]]

            publicaciones = int(len([i for i in dataPublicaciones if i]))
            tercil = [i for i in dataTercil if i]
            factor = [i for i in dataFactor if i]
            numeroAutores = [i for i in dataAutores if i]
            continua = [i for i in dataContinua if i]
            
            dataLibros = [req["libro1"],req["libro2"],req["libro3"],req["libro4"],req["libro5"],req["libro6"],req["libro7"],req["libro8"],req["libro9"]]
            dataIsbn = [req["isbn1"],req["isbn2"],req["isbn3"],req["isbn4"],req["isbn5"],req["isbn6"],req["isbn7"],req["isbn8"],req["isbn9"]]
            dataCitas = [req["citas1"],req["citas2"],req["citas3"],req["citas4"],req["citas5"],req["citas6"],req["citas7"],req["citas8"],req["citas9"]]
            dataTercilCitas = [req["tercilCitas1"],req["tercilCitas2"],req["tercilCitas3"],req["tercilCitas4"],req["tercilCitas5"],req["tercilCitas6"],req["tercilCitas7"],req["tercilCitas8"],req["tercilCitas9"]]
            dataTraducciones = [req["traducciones1"],req["traducciones2"],req["traducciones3"],req["traducciones4"],req["traducciones5"],req["traducciones6"],req["traducciones7"],req["traducciones8"],req["traducciones9"]]
            
            libros = int(len([i for i in dataLibros if i]))
            isbn = [i for i in dataIsbn if i]
            citas = [i for i in dataCitas if i]
            tercilCitas = [i for i in dataTercilCitas if i]
            traducciones = [i for i in dataTraducciones if i]

            dataProyectos = [req["proyecto1"],req["proyecto2"],req["proyecto3"],req["proyecto4"],req["proyecto5"],req["proyecto6"],req["proyecto7"],req["proyecto8"],req["proyecto9"]]
            dataTipoParticipacion = [req["tipoParticipacion1"],req["tipoParticipacion2"],req["tipoParticipacion3"],req["tipoParticipacion4"],req["tipoParticipacion5"],req["tipoParticipacion6"],req["tipoParticipacion7"],req["tipoParticipacion8"],req["tipoParticipacion9"]]
            dataOrganismo = [req["organismo1"],req["organismo2"],req["organismo3"],req["organismo4"],req["organismo5"],req["organismo6"],req["organismo7"],req["organismo8"],req["organismo9"]]
            dataGradoResponsabilidad = [req["gradoResp1"],req["gradoResp2"],req["gradoResp3"],req["gradoResp4"],req["gradoResp5"],req["gradoResp6"],req["gradoResp7"],req["gradoResp8"],req["gradoResp9"]]
            dataEvaluadorExterno = [req["evExt1"],req["evExt2"],req["evExt3"],req["evExt4"],req["evExt5"],req["evExt6"],req["evExt7"],req["evExt8"],req["evExt9"]]

            proyectos = int(len([i for i in dataProyectos if i]))
            tipoParticipacion = [i for i in dataTipoParticipacion if i]
            organismo = [i for i in dataOrganismo if i]
            gradoResponsabilidad = [i for i in dataGradoResponsabilidad if i]
            evaluadorExterno = [i for i in dataEvaluadorExterno if i]


            dataPatentes = [req["patente1"], req["patente2"], req["patente3"], req["patente4"], req["patente5"], req["patente6"]]
            dataExplotacion = [req["explotacion1"], req["explotacion2"], req["explotacion3"], req["explotacion4"], req["explotacion5"], req["explotacion6"]]
            dataCesion = [req["cesion1"], req["cesion2"], req["cesion3"], req["cesion4"], req["cesion5"], req["cesion6"]]
            dataLicencia = [req["licencia1"], req["licencia2"], req["licencia3"], req["licencia4"], req["licencia5"], req["licencia6"]]

            patentes = int(len([i for i in dataPatentes if i]))
            explotacion = [i for i in dataExplotacion if i]
            cesion = [i for i in dataCesion if i]
            licencia = [i for i in dataLicencia if i]

            dataTesis = [req["tesis1"], req["tesis2"], req["tesis3"],req["tesis4"], req["tesis5"], req["tesis6"]]
            dataDocEuropeo = [req["docEur1"], req["docEur2"], req["docEur3"],req["docEur4"], req["docEur5"], req["docEur6"]]
            dataEstado = [req["estado1"], req["estado2"], req["estado3"],req["estado4"], req["estado5"], req["estado6"]]
            datamCalidad = [req["mCalidad1"], req["mCalidad2"], req["mCalidad3"],req["mCalidad4"], req["mCalidad5"], req["mCalidad6"]]

            tesis = int(len([i for i in dataTesis if i]))
            doctoradoEuro = [i for i in dataDocEuropeo if i]
            estado = [i for i in dataEstado if i]
            mCalidad = [i for i in datamCalidad if i]

            dataEventos = [req["evento1"], req["evento2"], req["evento3"],req["evento4"], req["evento5"], req["evento6"]]
            dataProcesoAdmision = [req["procesoAdmision1"], req["procesoAdmision2"], req["procesoAdmision3"],req["procesoAdmision4"], req["procesoAdmision5"], req["procesoAdmision6"]]
            dataCaracter = [req["caracter1"], req["caracter2"], req["caracter3"],req["caracter4"], req["caracter5"], req["caracter6"]]
            dataParticipacion = [req["participacion1"], req["participacion2"], req["participacion3"],req["participacion4"], req["participacion5"], req["participacion6"]]

            eventos = int(len([i for i in dataEventos if i]))
            procesoAdmision = [i for i in dataProcesoAdmision if i]
            caracter = [i for i in dataCaracter if i]
            participacion = [i for i in dataParticipacion if i]

            dataOtrosMeritosInv = [req["otroMeritoInv1"], req["otroMeritoInv2"]]
            otrosMeritosInv = int(len([i for i in dataOtrosMeritosInv if i]))

            dataExperienciasDocentes = [req["experiencia1"], req["experiencia2"], req["experiencia3"], req["experiencia4"]]
            dataCentroExp = [req["centroExp1"], req["centroExp2"], req["centroExp3"], req["centroExp4"]]
            dataHoras = [req["horas1"], req["horas2"], req["horas3"], req["horas4"]]
            dataMaster = [req["master1"], req["master2"], req["master3"], req["master4"]]
            dataDoctorado = [req["doctorado1"], req["doctorado2"], req["doctorado3"], req["doctorado4"]]


            experiencias = int(len([i for i in dataExperienciasDocentes if i]))
            centroExp = [i for i in dataCentroExp if i]
            master = [i for i in dataMaster if i]
            doctorado = [i for i in dataDoctorado if i]
            horas = [i for i in dataHoras if i]

            dataEvaluaciones = [req["evaluacion1"], req["evaluacion2"], req["evaluacion3"], req["evaluacion4"]]
            dataNotas = [req["nota1"], req["nota2"], req["nota3"], req["nota4"]]

            evaluaciones = int(len([i for i in dataEvaluaciones if i]))
            notas = [i for i in dataNotas if i]

            dataEventosDocentes = [req["eventoDocente1"], req["eventoDocente2"], req["eventoDocente3"], req["eventoDocente4"]]
            dataInvitacion = [req["invitacion1"], req["invitacion2"], req["invitacion3"], req["invitacion4"]]

            eventosDocentes = int(len([i for i in dataEventosDocentes if i]))
            invitacion = [i for i in dataInvitacion if i]

            dataMaterialesDocentes = [req["matDoc1"],req["matDoc2"],req["matDoc3"],req["matDoc4"],req["matDoc5"],req["matDoc6"]]
            dataTipo = [req["tipo1"],req["tipo2"],req["tipo3"],req["tipo4"],req["tipo5"],req["tipo6"]]
            dataOriginal = [req["original1"],req["original2"],req["original3"],req["original4"],req["original5"],req["original6"]]
            dataArticulosRelacionados = [req["articulos1"],req["articulos2"],req["articulos3"],req["articulos4"],req["articulos5"],req["articulos6"]]

            materialDocente = int(len([i for i in dataMaterialesDocentes if i]))
            tipo = [i for i in dataTipo if i]
            original = [i for i in dataOriginal if i]
            articulosRelacionados = [i for i in dataArticulosRelacionados if i]

            dataEstudios = [req["estudios1"],req["estudios2"],req["estudios3"],req["estudios4"],req["estudios5"],req["estudios6"]]
            dataCalificacion = [req["calif1"],req["calif2"],req["calif3"],req["calif4"],req["calif5"],req["calif6"]]
            dataDoctoradoEuropeo = [req["DoctoradoE1"],req["DoctoradoE2"],req["DoctoradoE3"],req["DoctoradoE4"],req["DoctoradoE5"],req["DoctoradoE6"]]
            dataMencionCalidad = [req["MencionC1"],req["MencionC2"],req["MencionC3"],req["MencionC4"],req["MencionC5"],req["MencionC6"]]
            dataBecas = [req["becas1"],req["becas2"],req["becas3"],req["becas4"],req["becas5"],req["becas6"]]
            dataEstanciasFuera = [req["estanciasF1"],req["estanciasF2"],req["estanciasF3"],req["estanciasF4"],req["estanciasF5"],req["estanciasF6"]]

            estudios = int(len([i for i in dataEstudios if i]))
            calificacion = [i for i in dataCalificacion if i]
            doctoradoEuropeo = [i for i in dataDoctoradoEuropeo if i]
            mencionCalidad = [i for i in dataMencionCalidad if i]
            becas = [i for i in dataBecas if i]
            estanciasFuera = [i for i in dataEstanciasFuera if i]

            dataExperienciasProfesionales = [req["expProf1"],req["expProf2"],req["expProf3"],req["expProf4"]]
            dataInstitucionEmpresa = [req["inst1"],req["inst2"],req["inst3"],req["inst4"]]
            dataDuracion = [req["duracion1"],req["duracion2"],req["duracion3"],req["duracion4"]]
            dataResponsabilidad = [req["resp1"],req["resp2"],req["resp3"],req["resp4"]]

            experienciasProfesionales = int(len([i for i in dataExperienciasProfesionales if i]))
            institucionEmpresa = [i for i in dataInstitucionEmpresa if i]
            duracion = [i for i in dataDuracion if i]
            responsabilidad = [i for i in dataResponsabilidad if i]

            dataOtrosMeritosAcademicos = [req["otrosMA"]]
            dataOtrosMeritosDocentes = [req["otrosMD"]]
            dataOtrosMeritosInvestigacion = [req["otrosMI"]]
            dataOtrosMeritosProfesionales = [req["otrosMP"]]

            otrosMeritosAcademicos = [i for i in dataOtrosMeritosAcademicos if i]
            otrosMeritosDocentes = [i for i in dataOtrosMeritosDocentes if i]
            otrosMeritosInvestigacion = [i for i in dataOtrosMeritosInvestigacion if i]
            otrosMeritosProfesionales = [i for i in dataOtrosMeritosProfesionales if i]
            
            if especialidad == "no especialidad seleccionada":
                flash("Recuerde seleccionar una especialidad para poder continuar")
                return redirect(request.url)

            if especialidad == "Ciencias Experimentales":
                enginePublicaciones = EvaluacionPublicacionesCE()
                enginePublicaciones.reset()
                enginePublicaciones.declare(Publicaciones(publicaciones = publicaciones),Publicaciones(tercil = tercil), Publicaciones(factor = factor), Publicaciones(numeroAutores = numeroAutores), Publicaciones(continua = continua))
                enginePublicaciones.run()
                
                engineLibros = EvaluacionLibrosCE()
                engineLibros.reset()
                engineLibros.declare(Libros(libros = libros), Libros(isbn = isbn), Libros(citas = citas), Libros(tercilCitas = tercilCitas), Libros(traducciones = traducciones))
                engineLibros.run()

                engineProyectos = EvaluacionProyectosCE()
                engineProyectos.reset()
                engineProyectos.declare(Proyectos(proyectos = proyectos), Proyectos(tipoParticipacion = tipoParticipacion), Proyectos(organismo = organismo), Proyectos(gradoResponsabilidad = gradoResponsabilidad), Proyectos(evaluadorExterno = evaluadorExterno))
                engineProyectos.run()

                enginePatentes = EvaluacionPatentesCE()
                enginePatentes.reset()
                enginePatentes.declare(Patentes(patentes = patentes), Patentes(explotacion = explotacion), Patentes(cesion = cesion), Patentes(licencia = licencia))
                enginePatentes.run()

                engineTesis = EvaluacionTesisCE()
                engineTesis.reset()
                engineTesis.declare(Tesis(tesis = tesis), Tesis(doctoradoEuro = doctoradoEuro), Tesis(estado = estado), Tesis(mCalidad = mCalidad))
                engineTesis.run()

                engineEventos = EvaluacionEventosCE()
                engineEventos.reset()
                engineEventos.declare(Eventos(eventos = eventos), Eventos(procesoAdmision = procesoAdmision), Eventos(caracter = caracter), Eventos(participacion = participacion))
                engineEventos.run()

                engineOtrosMeritosInvCE = EvaluacionOtrosMeritosInvCE()
                engineOtrosMeritosInvCE.reset()
                engineOtrosMeritosInvCE.declare(OtrosMeritosInv(otrosMeritosInv = otrosMeritosInv))
                engineOtrosMeritosInvCE.run()
                
                engineExperiencia = EvaluacionExperiencias()
                engineExperiencia.reset()
                engineExperiencia.declare(Experiencias(experiencias = experiencias), Experiencias(centroExp = centroExp), Experiencias(master = master), Experiencias(doctorado = doctorado), Experiencias(horas = horas))
                engineExperiencia.run()
                

                engineEVCalidad = EvaluacionEVCalidad()
                engineEVCalidad.reset()
                engineEVCalidad.declare(Evaluaciones(evaluaciones = evaluaciones), Evaluaciones(notas = notas))
                engineEVCalidad.run()

                engineEventosDocentes = EvaluacionEventosDocentes()
                engineEventosDocentes.reset()
                engineEventosDocentes.declare(EventosDocentes(eventosDocentes = eventosDocentes), EventosDocentes(invitacion = invitacion))
                engineEventosDocentes.run()

                engineMaterialDocente = EvaluacionMaterialDocente()
                engineMaterialDocente.reset()
                engineMaterialDocente.declare(MaterialDocente(materialDocente = materialDocente), MaterialDocente(tipo = tipo), MaterialDocente(original = original), MaterialDocente(articulosRelacionados = articulosRelacionados))
                engineMaterialDocente.run()

                engineFormacion = EvaluacionFormacion()
                engineFormacion.reset()
                engineFormacion.declare(Formacion(estudios = estudios), Formacion(calificacion = calificacion), Formacion(doctoradoEuropeo = doctoradoEuropeo), Formacion(mencionCalidad = mencionCalidad), Formacion(becas = becas), Formacion(estanciasFuera = estanciasFuera))
                engineFormacion.run()

                engineExperienciaProfesional = EvaluacionExperienciaProfesional()
                engineExperienciaProfesional.reset()
                engineExperienciaProfesional.declare(ExperienciaProfesional(experienciasProfesionales = experienciasProfesionales), ExperienciaProfesional(institucionEmpresa = institucionEmpresa), ExperienciaProfesional(duracion = duracion), ExperienciaProfesional(responsabilidad = responsabilidad))
                engineExperienciaProfesional.run()

                engineOtrosMeritos = EvaluacionOtrosMeritos()
                engineOtrosMeritos.reset()
                engineOtrosMeritos.declare(OtrosMeritos(otrosMeritosAcademicos = otrosMeritosAcademicos), OtrosMeritos(otrosMeritosDocentes = otrosMeritosDocentes), OtrosMeritos(otrosMeritosInvestigacion = otrosMeritosInvestigacion), OtrosMeritos(otrosMeritosProfesionales = otrosMeritosProfesionales))
                engineOtrosMeritos.run()


                resultadoParcial = enginePublicaciones.resultadoPublicaciones + engineLibros.resultadoLibros + engineProyectos.resultadoProyectos + enginePatentes.resultadoPatentes + engineTesis.resultadoTesis + engineEventos.resultadoEventos + engineOtrosMeritosInvCE.resultadoOtrosMeritosInvCE + engineExperiencia.resultadoExperiencias + engineEVCalidad.resultadoEVCalidad + engineEventosDocentes.resultadoEventosDocentes + engineMaterialDocente.resultadoMaterialDocente
                resultado = enginePublicaciones.resultadoPublicaciones + engineLibros.resultadoLibros + engineProyectos.resultadoProyectos + enginePatentes.resultadoPatentes + engineTesis.resultadoTesis + engineEventos.resultadoEventos + engineExperiencia.resultadoExperiencias + engineEVCalidad.resultadoEVCalidad + engineEventosDocentes.resultadoEventosDocentes + engineMaterialDocente.resultadoMaterialDocente + engineFormacion.resultadoFormacion + engineExperienciaProfesional.resultadoExperienciaProfesional + engineOtrosMeritos.resultadoOtrosMeritos



                cur = mysql.get_db().cursor()
        
                sQuery = "SELECT email, resultado, resultadoparcial, especialidad FROM resultadospup WHERE email = %s"

                cur.execute(sQuery, [session.get('email')])

                resultadoG = cur.fetchall()
    
                cur.close()
                
                if len(resultadoG) < 3:

                    cur = mysql.get_db().cursor()
        
                    cur.execute('INSERT INTO resultadospup (email, resultado, resultadoparcial, especialidad) VALUES ( %s, %s, %s, %s)', (session.get('email'), resultado, resultadoParcial, especialidad))

                    mysql.get_db().commit()
                
                else:

                    cur = mysql.get_db().cursor()

                    sQuery2 = "DELETE FROM resultadospup WHERE email = %s LIMIT 1"
                    
                    cur.execute(sQuery2, [session.get('email')])

                    cur.execute('INSERT INTO resultadospup (email, resultado, resultadoparcial, especialidad) VALUES ( %s, %s, %s, %s)', (session.get('email'), resultado, resultadoParcial, especialidad))

                    mysql.get_db().commit()


                return redirect(url_for('resultados_pup', especialidad = especialidad, resultado = resultado, resultadoParcial = resultadoParcial))
            
            if especialidad == "Ciencias de la Salud":
                enginePublicacionesCS = EvaluacionPublicacionesCS()
                enginePublicacionesCS.reset()
                enginePublicacionesCS.declare(Publicaciones(publicaciones = publicaciones), Publicaciones(tercil = tercil))
                enginePublicacionesCS.run()

                engineLibrosCS = EvaluacionLibrosCS()
                engineLibrosCS.reset()
                engineLibrosCS.declare(Libros(libros = libros), Libros(isbn = isbn), Libros(citas = citas), Libros(tercilCitas = tercilCitas), Libros(traducciones = traducciones))
                engineLibrosCS.run()

                engineProyectosCS = EvaluacionProyectosCS()
                engineProyectosCS.reset()
                engineProyectosCS.declare(Proyectos(proyectos = proyectos), Proyectos(tipoParticipacion = tipoParticipacion), Proyectos(organismo = organismo), Proyectos(gradoResponsabilidad = gradoResponsabilidad), Proyectos(evaluadorExterno = evaluadorExterno))
                engineProyectosCS.run()

                enginePatentesCS = EvaluacionPatentesCS()
                enginePatentesCS.reset()
                enginePatentesCS.declare(Patentes(patentes = patentes), Patentes(explotacion = explotacion), Patentes(cesion = cesion), Patentes(licencia = licencia))
                enginePatentesCS.run()

                engineTesisCS = EvaluacionTesisCS()
                engineTesisCS.reset()
                engineTesisCS.declare(Tesis(tesis = tesis), Tesis(doctoradoEuro = doctoradoEuro), Tesis(estado = estado), Tesis(mCalidad = mCalidad))
                engineTesisCS.run()

                engineEventosCS = EvaluacionEventosCS()
                engineEventosCS.reset()
                engineEventosCS.declare(Eventos(eventos = eventos), Eventos(procesoAdmision = procesoAdmision), Eventos(caracter = caracter), Eventos(participacion = participacion))
                engineEventosCS.run()

                engineOtrosMeritosInvCS = EvaluacionOtrosMeritosInvCS()
                engineOtrosMeritosInvCS.reset()
                engineOtrosMeritosInvCS.declare(OtrosMeritosInv(otrosMeritosInv = otrosMeritosInv))
                engineOtrosMeritosInvCS.run()

                engineExperiencia = EvaluacionExperiencias()
                engineExperiencia.reset()
                engineExperiencia.declare(Experiencias(experiencias = experiencias), Experiencias(centroExp = centroExp), Experiencias(master = master), Experiencias(doctorado = doctorado), Experiencias(horas = horas))
                engineExperiencia.run()

                engineEVCalidad = EvaluacionEVCalidad()
                engineEVCalidad.reset()
                engineEVCalidad.declare(Evaluaciones(evaluaciones = evaluaciones), Evaluaciones(notas = notas))
                engineEVCalidad.run()

                engineEventosDocentes = EvaluacionEventosDocentes()
                engineEventosDocentes.reset()
                engineEventosDocentes.declare(EventosDocentes(eventosDocentes = eventosDocentes), EventosDocentes(invitacion = invitacion))
                engineEventosDocentes.run()

                engineMaterialDocente = EvaluacionMaterialDocente()
                engineMaterialDocente.reset()
                engineMaterialDocente.declare(MaterialDocente(materialDocente = materialDocente), MaterialDocente(tipo = tipo), MaterialDocente(original = original), MaterialDocente(articulosRelacionados = articulosRelacionados))
                engineMaterialDocente.run()

                engineFormacion = EvaluacionFormacion()
                engineFormacion.reset()
                engineFormacion.declare(Formacion(estudios = estudios), Formacion(calificacion = calificacion), Formacion(doctoradoEuropeo = doctoradoEuropeo), Formacion(mencionCalidad = mencionCalidad), Formacion(becas = becas), Formacion(estanciasFuera = estanciasFuera))
                engineFormacion.run()

                engineExperienciaProfesional = EvaluacionExperienciaProfesional()
                engineExperienciaProfesional.reset()
                engineExperienciaProfesional.declare(ExperienciaProfesional(experienciasProfesionales = experienciasProfesionales), ExperienciaProfesional(institucionEmpresa = institucionEmpresa), ExperienciaProfesional(duracion = duracion), ExperienciaProfesional(responsabilidad = responsabilidad))
                engineExperienciaProfesional.run()

                engineOtrosMeritos = EvaluacionOtrosMeritos()
                engineOtrosMeritos.reset()
                engineOtrosMeritos.declare(OtrosMeritos(otrosMeritosAcademicos = otrosMeritosAcademicos), OtrosMeritos(otrosMeritosDocentes = otrosMeritosDocentes), OtrosMeritos(otrosMeritosInvestigacion = otrosMeritosInvestigacion), OtrosMeritos(otrosMeritosProfesionales = otrosMeritosProfesionales))
                engineOtrosMeritos.run()

                resultadoParcial = enginePublicacionesCS.resultadoPublicacionesCS + engineLibrosCS.resultadoLibrosCS + engineProyectosCS.resultadoProyectosCS + enginePatentesCS.resultadoPatentesCS + engineTesisCS.resultadoTesisCS + engineEventosCS.resultadoEventosCS + engineOtrosMeritosInvCS.resultadoOtrosMeritosInvCS + engineExperiencia.resultadoExperiencias + engineEVCalidad.resultadoEVCalidad + engineEventosDocentes.resultadoEventosDocentes + engineMaterialDocente.resultadoMaterialDocente
                resultado = enginePublicacionesCS.resultadoPublicacionesCS + engineLibrosCS.resultadoLibrosCS + engineProyectosCS.resultadoProyectosCS + enginePatentesCS.resultadoPatentesCS + engineTesisCS.resultadoTesisCS + engineEventosCS.resultadoEventosCS + engineExperiencia.resultadoExperiencias + engineEVCalidad.resultadoEVCalidad + engineEventosDocentes.resultadoEventosDocentes + engineMaterialDocente.resultadoMaterialDocente + engineFormacion.resultadoFormacion + engineExperienciaProfesional.resultadoExperienciaProfesional + engineOtrosMeritos.resultadoOtrosMeritos
                
                cur = mysql.get_db().cursor()
        
                sQuery = "SELECT email, resultado, resultadoparcial, especialidad FROM resultadospup WHERE email = %s"

                cur.execute(sQuery, [session.get('email')])

                resultadoG = cur.fetchall()
    
                cur.close()
                
                if len(resultadoG) < 3:

                    cur = mysql.get_db().cursor()
        
                    cur.execute('INSERT INTO resultadospup (email, resultado, resultadoparcial, especialidad) VALUES ( %s, %s, %s, %s)', (session.get('email'), resultado, resultadoParcial, especialidad))

                    mysql.get_db().commit()
                
                else:

                    cur = mysql.get_db().cursor()

                    sQuery2 = "DELETE FROM resultadospup WHERE email = %s LIMIT 1"
                    
                    cur.execute(sQuery2, [session.get('email')])

                    cur.execute('INSERT INTO resultadospup (email, resultado, resultadoparcial, especialidad) VALUES ( %s, %s, %s, %s)', (session.get('email'), resultado, resultadoParcial, especialidad))

                    mysql.get_db().commit()


                return redirect(url_for('resultados_pup', especialidad = especialidad, resultado = resultado, resultadoParcial = resultadoParcial))

            if especialidad == "Enseñanzas Técnicas":
                enginePublicacionesET = EvaluacionPublicacionesET()
                enginePublicacionesET.reset()
                enginePublicacionesET.declare(Publicaciones(publicaciones = publicaciones), Publicaciones(tercil = tercil), Publicaciones(factor = factor), Publicaciones(numeroAutores = numeroAutores), Publicaciones(continua = continua))
                enginePublicacionesET.run()

                engineLibrosET = EvaluacionLibrosET()
                engineLibrosET.reset()
                engineLibrosET.declare(Libros(libros = libros), Libros(isbn = isbn), Libros(citas = citas), Libros(traducciones = traducciones))
                engineLibrosET.run()
                    
                engineProyectosET = EvaluacionProyectosET()
                engineProyectosET.reset()
                engineProyectosET.declare(Proyectos(proyectos = proyectos), Proyectos(tipoParticipacion = tipoParticipacion), Proyectos(organismo = organismo), Proyectos(gradoResponsabilidad = gradoResponsabilidad), Proyectos(evaluadorExterno = evaluadorExterno))
                engineProyectosET.run()
                    
                enginePatentesET = EvaluacionPatentesET()
                enginePatentesET.reset()
                enginePatentesET.declare(Patentes(patentes = patentes), Patentes(explotacion = explotacion), Patentes(cesion = cesion), Patentes(licencia = licencia))
                enginePatentesET.run()

                engineTesisET = EvaluacionTesisET()
                engineTesisET.reset()
                engineTesisET.declare(Tesis(tesis = tesis), Tesis(doctoradoEuro = doctoradoEuro), Tesis(estado = estado), Tesis(mCalidad = mCalidad))
                engineTesisET.run()
                    
                engineEventosET = EvaluacionEventosET()
                engineEventosET.reset()
                engineEventosET.declare(Eventos(eventos = eventos), Eventos(procesoAdmision = procesoAdmision), Eventos(caracter = caracter), Eventos(participacion = participacion))
                engineEventosET.run()

                engineOtrosMeritosInvET = EvaluacionOtrosMeritosInvET()
                engineOtrosMeritosInvET.reset()
                engineOtrosMeritosInvET.declare(OtrosMeritosInv(otrosMeritosInv = otrosMeritosInv))
                engineOtrosMeritosInvET.run()

                engineExperiencia = EvaluacionExperiencias()
                engineExperiencia.reset()
                engineExperiencia.declare(Experiencias(experiencias = experiencias), Experiencias(centroExp = centroExp), Experiencias(master = master), Experiencias(doctorado = doctorado), Experiencias(horas = horas))
                engineExperiencia.run()

                engineEVCalidad = EvaluacionEVCalidad()
                engineEVCalidad.reset()
                engineEVCalidad.declare(Evaluaciones(evaluaciones = evaluaciones), Evaluaciones(notas = notas))
                engineEVCalidad.run()

                engineEventosDocentes = EvaluacionEventosDocentes()
                engineEventosDocentes.reset()
                engineEventosDocentes.declare(EventosDocentes(eventosDocentes = eventosDocentes), EventosDocentes(invitacion = invitacion))
                engineEventosDocentes.run()

                engineMaterialDocente = EvaluacionMaterialDocente()
                engineMaterialDocente.reset()
                engineMaterialDocente.declare(MaterialDocente(materialDocente = materialDocente), MaterialDocente(tipo = tipo), MaterialDocente(original = original), MaterialDocente(articulosRelacionados = articulosRelacionados))
                engineMaterialDocente.run()

                engineFormacion = EvaluacionFormacion()
                engineFormacion.reset()
                engineFormacion.declare(Formacion(estudios = estudios), Formacion(calificacion = calificacion), Formacion(doctoradoEuropeo = doctoradoEuropeo), Formacion(mencionCalidad = mencionCalidad), Formacion(becas = becas), Formacion(estanciasFuera = estanciasFuera))
                engineFormacion.run()

                engineExperienciaProfesional = EvaluacionExperienciaProfesional()
                engineExperienciaProfesional.reset()
                engineExperienciaProfesional.declare(ExperienciaProfesional(experienciasProfesionales = experienciasProfesionales), ExperienciaProfesional(institucionEmpresa = institucionEmpresa), ExperienciaProfesional(duracion = duracion), ExperienciaProfesional(responsabilidad = responsabilidad))
                engineExperienciaProfesional.run()

                engineOtrosMeritos = EvaluacionOtrosMeritos()
                engineOtrosMeritos.reset()
                engineOtrosMeritos.declare(OtrosMeritos(otrosMeritosAcademicos = otrosMeritosAcademicos), OtrosMeritos(otrosMeritosDocentes = otrosMeritosDocentes), OtrosMeritos(otrosMeritosInvestigacion = otrosMeritosInvestigacion), OtrosMeritos(otrosMeritosProfesionales = otrosMeritosProfesionales))
                engineOtrosMeritos.run()

                resultadoParcial = enginePublicacionesET.resultadoPublicacionesET + engineLibrosET.resultadoLibrosET + engineProyectosET.resultadoProyectosET + enginePatentesET.resultadoPatentesET + engineTesisET.resultadoTesisET + engineEventosET.resultadoEventosET + engineOtrosMeritosInvET.resultadoOtrosMeritosInvET + engineExperiencia.resultadoExperiencias + engineEVCalidad.resultadoEVCalidad + engineEventosDocentes.resultadoEventosDocentes + engineMaterialDocente.resultadoMaterialDocente
                resultado = enginePublicacionesET.resultadoPublicacionesET + engineLibrosET.resultadoLibrosET + engineProyectosET.resultadoProyectosET + enginePatentesET.resultadoPatentesET + engineTesisET.resultadoTesisET + engineEventosET.resultadoEventosET + engineExperiencia.resultadoExperiencias + engineEVCalidad.resultadoEVCalidad + engineEventosDocentes.resultadoEventosDocentes + engineMaterialDocente.resultadoMaterialDocente + engineFormacion.resultadoFormacion + engineExperienciaProfesional.resultadoExperienciaProfesional + engineOtrosMeritos.resultadoOtrosMeritos
                
                cur = mysql.get_db().cursor()
        
                sQuery = "SELECT email, resultado, resultadoparcial, especialidad FROM resultadospup WHERE email = %s"

                cur.execute(sQuery, [session.get('email')])

                resultadoG = cur.fetchall()
    
                cur.close()
                
                if len(resultadoG) < 3:

                    cur = mysql.get_db().cursor()
        
                    cur.execute('INSERT INTO resultadospup (email, resultado, resultadoparcial, especialidad) VALUES ( %s, %s, %s, %s)', (session.get('email'), resultado, resultadoParcial, especialidad))

                    mysql.get_db().commit()
                
                else:

                    cur = mysql.get_db().cursor()

                    sQuery2 = "DELETE FROM resultadospup WHERE email = %s LIMIT 1"
                    
                    cur.execute(sQuery2, [session.get('email')])

                    cur.execute('INSERT INTO resultadospup (email, resultado, resultadoparcial, especialidad) VALUES ( %s, %s, %s, %s)', (session.get('email'), resultado, resultadoParcial, especialidad))

                    mysql.get_db().commit()



                return redirect(url_for('resultados_pup', especialidad = especialidad, resultado = resultado, resultadoParcial = resultadoParcial))
                
            if especialidad == "Ciencias Sociales y Jurídicas":
                enginePublicacionesSJ = EvaluacionPublicacionesSJ()
                enginePublicacionesSJ.reset()
                enginePublicacionesSJ.declare(Publicaciones(publicaciones = publicaciones),Publicaciones(tercil = tercil), Publicaciones(factor = factor), Publicaciones(numeroAutores = numeroAutores), Publicaciones(continua = continua))
                enginePublicacionesSJ.run()

                engineLibrosSJ = EvaluacionLibrosSJ()
                engineLibrosSJ.reset()
                engineLibrosSJ.declare(Libros(libros = libros), Libros(isbn = isbn), Libros(citas = citas), Libros(tercilCitas = tercilCitas), Libros(traducciones = traducciones))
                engineLibrosSJ.run()

                engineProyectosSJ = EvaluacionProyectosSJ()
                engineProyectosSJ.reset()
                engineProyectosSJ.declare(Proyectos(proyectos = proyectos), Proyectos(tipoParticipacion = tipoParticipacion), Proyectos(organismo = organismo), Proyectos(gradoResponsabilidad = gradoResponsabilidad), Proyectos(evaluadorExterno = evaluadorExterno))
                engineProyectosSJ.run()

                enginePatentesSJ = EvaluacionPatentesSJ()
                enginePatentesSJ.reset()
                enginePatentesSJ.declare(Patentes(patentes = patentes), Patentes(explotacion = explotacion), Patentes(cesion = cesion), Patentes(licencia = licencia))
                enginePatentesSJ.run()

                engineTesisSJ = EvaluacionTesisSJ()
                engineTesisSJ.reset()
                engineTesisSJ.declare(Tesis(tesis = tesis), Tesis(doctoradoEuro = doctoradoEuro), Tesis(estado = estado), Tesis(mCalidad = mCalidad))
                engineTesisSJ.run()
                    
                engineEventosSJ = EvaluacionEventosSJ()
                engineEventosSJ.reset()
                engineEventosSJ.declare(Eventos(eventos = eventos), Eventos(procesoAdmision = procesoAdmision), Eventos(caracter = caracter), Eventos(participacion = participacion))
                engineEventosSJ.run()

                engineOtrosMeritosInvSJ = EvaluacionOtrosMeritosInvSJ()
                engineOtrosMeritosInvSJ.reset()
                engineOtrosMeritosInvSJ.declare(OtrosMeritosInv(otrosMeritosInv = otrosMeritosInv))
                engineOtrosMeritosInvSJ.run()

                engineExperiencia = EvaluacionExperiencias()
                engineExperiencia.reset()
                engineExperiencia.declare(Experiencias(experiencias = experiencias), Experiencias(centroExp = centroExp), Experiencias(master = master), Experiencias(doctorado = doctorado), Experiencias(horas = horas))
                engineExperiencia.run()
                
                engineEVCalidad = EvaluacionEVCalidad()
                engineEVCalidad.reset()
                engineEVCalidad.declare(Evaluaciones(evaluaciones = evaluaciones), Evaluaciones(notas = notas))
                engineEVCalidad.run()

                engineEventosDocentes = EvaluacionEventosDocentes()
                engineEventosDocentes.reset()
                engineEventosDocentes.declare(EventosDocentes(eventosDocentes = eventosDocentes), EventosDocentes(invitacion = invitacion))
                engineEventosDocentes.run()

                engineMaterialDocente = EvaluacionMaterialDocente()
                engineMaterialDocente.reset()
                engineMaterialDocente.declare(MaterialDocente(materialDocente = materialDocente), MaterialDocente(tipo = tipo), MaterialDocente(original = original), MaterialDocente(articulosRelacionados = articulosRelacionados))
                engineMaterialDocente.run()

                engineFormacion = EvaluacionFormacion()
                engineFormacion.reset()
                engineFormacion.declare(Formacion(estudios = estudios), Formacion(calificacion = calificacion), Formacion(doctoradoEuropeo = doctoradoEuropeo), Formacion(mencionCalidad = mencionCalidad), Formacion(becas = becas), Formacion(estanciasFuera = estanciasFuera))
                engineFormacion.run()

                engineExperienciaProfesional = EvaluacionExperienciaProfesional()
                engineExperienciaProfesional.reset()
                engineExperienciaProfesional.declare(ExperienciaProfesional(experienciasProfesionales = experienciasProfesionales), ExperienciaProfesional(institucionEmpresa = institucionEmpresa), ExperienciaProfesional(duracion = duracion), ExperienciaProfesional(responsabilidad = responsabilidad))
                engineExperienciaProfesional.run()

                engineOtrosMeritos = EvaluacionOtrosMeritos()
                engineOtrosMeritos.reset()
                engineOtrosMeritos.declare(OtrosMeritos(otrosMeritosAcademicos = otrosMeritosAcademicos), OtrosMeritos(otrosMeritosDocentes = otrosMeritosDocentes), OtrosMeritos(otrosMeritosInvestigacion = otrosMeritosInvestigacion), OtrosMeritos(otrosMeritosProfesionales = otrosMeritosProfesionales))
                engineOtrosMeritos.run()

                resultadoParcial = enginePublicacionesSJ.resultadoPublicacionesSJ + engineLibrosSJ.resultadoLibrosSJ + engineProyectosSJ.resultadoProyectosSJ + enginePatentesSJ.resultadoPatentesSJ + engineTesisSJ.resultadoTesisSJ + engineEventosSJ.resultadoEventosSJ + engineOtrosMeritosInvSJ.resultadoOtrosMeritosInvSJ + engineExperiencia.resultadoExperiencias + engineEVCalidad.resultadoEVCalidad + engineEventosDocentes.resultadoEventosDocentes + engineMaterialDocente.resultadoMaterialDocente + engineFormacion.resultadoFormacion
                resultado = enginePublicacionesSJ.resultadoPublicacionesSJ + engineLibrosSJ.resultadoLibrosSJ + engineProyectosSJ.resultadoProyectosSJ + enginePatentesSJ.resultadoPatentesSJ + engineTesisSJ.resultadoTesisSJ + engineEventosSJ.resultadoEventosSJ + engineExperiencia.resultadoExperiencias + engineEVCalidad.resultadoEVCalidad + engineEventosDocentes.resultadoEventosDocentes + engineMaterialDocente.resultadoMaterialDocente + engineFormacion.resultadoFormacion + engineExperienciaProfesional.resultadoExperienciaProfesional + engineOtrosMeritos.resultadoOtrosMeritos
                
                cur = mysql.get_db().cursor()
        
                sQuery = "SELECT email, resultado, resultadoparcial, especialidad FROM resultadospup WHERE email = %s"

                cur.execute(sQuery, [session.get('email')])

                resultadoG = cur.fetchall()
    
                cur.close()
                
                if len(resultadoG) < 3:

                    cur = mysql.get_db().cursor()
        
                    cur.execute('INSERT INTO resultadospup (email, resultado, resultadoparcial, especialidad) VALUES ( %s, %s, %s, %s)', (session.get('email'), resultado, resultadoParcial, especialidad))

                    mysql.get_db().commit()
                
                else:

                    cur = mysql.get_db().cursor()

                    sQuery2 = "DELETE FROM resultadospup WHERE email = %s LIMIT 1"
                    
                    cur.execute(sQuery2, [session.get('email')])

                    cur.execute('INSERT INTO resultadospup (email, resultado, resultadoparcial, especialidad) VALUES ( %s, %s, %s, %s)', (session.get('email'), resultado, resultadoParcial, especialidad))

                    mysql.get_db().commit()



                return redirect(url_for('resultados_pup', especialidad = especialidad, resultado = resultado, resultadoParcial = resultadoParcial))
                
            if especialidad == "Humanidades":
                enginePublicacionesH = EvaluacionPublicacionesH()
                enginePublicacionesH.reset()
                enginePublicacionesH.declare(Publicaciones(publicaciones = publicaciones),Publicaciones(tercil = tercil), Publicaciones(factor = factor), Publicaciones(numeroAutores = numeroAutores), Publicaciones(continua = continua))
                enginePublicacionesH.run()

                engineLibrosH = EvaluacionLibrosH()
                engineLibrosH.reset()
                engineLibrosH.declare(Libros(libros = libros), Libros(isbn = isbn), Libros(citas = citas), Libros(tercilCitas = tercilCitas), Libros(traducciones = traducciones))
                engineLibrosH.run()

                engineProyectosH = EvaluacionProyectosH()
                engineProyectosH.reset()
                engineProyectosH.declare(Proyectos(proyectos = proyectos), Proyectos(tipoParticipacion = tipoParticipacion), Proyectos(organismo = organismo), Proyectos(gradoResponsabilidad = gradoResponsabilidad), Proyectos(evaluadorExterno = evaluadorExterno))
                engineProyectosH.run()

                enginePatentesH = EvaluacionPatentesH()
                enginePatentesH.reset()
                enginePatentesH.declare(Patentes(patentes = patentes), Patentes(explotacion = explotacion), Patentes(cesion = cesion), Patentes(licencia = licencia))
                enginePatentesH.run()

                engineTesisH = EvaluacionTesisH()
                engineTesisH.reset()
                engineTesisH.declare(Tesis(tesis = tesis), Tesis(doctoradoEuro = doctoradoEuro), Tesis(estado = estado), Tesis(mCalidad = mCalidad))
                engineTesisH.run()
                    
                engineEventosH = EvaluacionEventosH()
                engineEventosH.reset()
                engineEventosH.declare(Eventos(eventos = eventos), Eventos(procesoAdmision = procesoAdmision), Eventos(caracter = caracter), Eventos(participacion = participacion))
                engineEventosH.run()

                engineOtrosMeritosInvH = EvaluacionOtrosMeritosInvH()
                engineOtrosMeritosInvH.reset()
                engineOtrosMeritosInvH.declare(OtrosMeritosInv(otrosMeritosInv = otrosMeritosInv))
                engineOtrosMeritosInvH.run()

                engineExperiencia = EvaluacionExperiencias()
                engineExperiencia.reset()
                engineExperiencia.declare(Experiencias(experiencias = experiencias), Experiencias(centroExp = centroExp), Experiencias(master = master), Experiencias(doctorado = doctorado), Experiencias(horas = horas))
                engineExperiencia.run()

                engineEVCalidad = EvaluacionEVCalidad()
                engineEVCalidad.reset()
                engineEVCalidad.declare(Evaluaciones(evaluaciones = evaluaciones), Evaluaciones(notas = notas))
                engineEVCalidad.run()

                engineEventosDocentes = EvaluacionEventosDocentes()
                engineEventosDocentes.reset()
                engineEventosDocentes.declare(EventosDocentes(eventosDocentes = eventosDocentes), EventosDocentes(invitacion = invitacion))
                engineEventosDocentes.run()

                engineMaterialDocente = EvaluacionMaterialDocente()
                engineMaterialDocente.reset()
                engineMaterialDocente.declare(MaterialDocente(materialDocente = materialDocente), MaterialDocente(tipo = tipo), MaterialDocente(original = original), MaterialDocente(articulosRelacionados = articulosRelacionados))
                engineMaterialDocente.run()

                engineFormacion = EvaluacionFormacion()
                engineFormacion.reset()
                engineFormacion.declare(Formacion(estudios = estudios), Formacion(calificacion = calificacion), Formacion(doctoradoEuropeo = doctoradoEuropeo), Formacion(mencionCalidad = mencionCalidad), Formacion(becas = becas), Formacion(estanciasFuera = estanciasFuera))
                engineFormacion.run()

                engineExperienciaProfesional = EvaluacionExperienciaProfesional()
                engineExperienciaProfesional.reset()
                engineExperienciaProfesional.declare(ExperienciaProfesional(experienciasProfesionales = experienciasProfesionales), ExperienciaProfesional(institucionEmpresa = institucionEmpresa), ExperienciaProfesional(duracion = duracion), ExperienciaProfesional(responsabilidad = responsabilidad))
                engineExperienciaProfesional.run()

                engineOtrosMeritos = EvaluacionOtrosMeritos()
                engineOtrosMeritos.reset()
                engineOtrosMeritos.declare(OtrosMeritos(otrosMeritosAcademicos = otrosMeritosAcademicos), OtrosMeritos(otrosMeritosDocentes = otrosMeritosDocentes), OtrosMeritos(otrosMeritosInvestigacion = otrosMeritosInvestigacion), OtrosMeritos(otrosMeritosProfesionales = otrosMeritosProfesionales))
                engineOtrosMeritos.run()

                resultadoParcial = enginePublicacionesH.resultadoPublicacionesH + engineLibrosH.resultadoLibrosH + engineProyectosH.resultadoProyectosH + enginePatentesH.resultadoPatentesH + engineTesisH.resultadoTesisH + engineEventosH.resultadoEventosH + engineOtrosMeritosInvH.resultadoOtrosMeritosInvH + engineExperiencia.resultadoExperiencias + engineEVCalidad.resultadoEVCalidad + engineEventosDocentes.resultadoEventosDocentes + engineMaterialDocente.resultadoMaterialDocente + engineFormacion.resultadoFormacion
                resultado = enginePublicacionesH.resultadoPublicacionesH + engineLibrosH.resultadoLibrosH + engineProyectosH.resultadoProyectosH + enginePatentesH.resultadoPatentesH + engineTesisH.resultadoTesisH + engineEventosH.resultadoEventosH + engineExperiencia.resultadoExperiencias + engineEVCalidad.resultadoEVCalidad + engineEventosDocentes.resultadoEventosDocentes + engineMaterialDocente.resultadoMaterialDocente + engineFormacion.resultadoFormacion + engineExperienciaProfesional.resultadoExperienciaProfesional + engineOtrosMeritos.resultadoOtrosMeritos
                
                cur = mysql.get_db().cursor()
        
                sQuery = "SELECT email, resultado, resultadoparcial, especialidad FROM resultadospup WHERE email = %s"

                cur.execute(sQuery, [session.get('email')])

                resultadoG = cur.fetchall()
    
                cur.close()
                
                if len(resultadoG) < 3:

                    cur = mysql.get_db().cursor()
        
                    cur.execute('INSERT INTO resultadospup (email, resultado, resultadoparcial, especialidad) VALUES ( %s, %s, %s, %s)', (session.get('email'), resultado, resultadoParcial, especialidad))

                    mysql.get_db().commit()
                
                else:

                    cur = mysql.get_db().cursor()

                    sQuery2 = "DELETE FROM resultadospup WHERE email = %s LIMIT 1"
                    
                    cur.execute(sQuery2, [session.get('email')])

                    cur.execute('INSERT INTO resultadospup (email, resultado, resultadoparcial, especialidad) VALUES ( %s, %s, %s, %s)', (session.get('email'), resultado, resultadoParcial, especialidad))

                    mysql.get_db().commit()



                return redirect(url_for('resultados_pup', especialidad = especialidad, resultado = resultado, resultadoParcial = resultadoParcial))
                
            
        
        else:
            return render_template("usuario/form-pup.html")

    else:
        return render_template('public/ingresar.html')

#---Facts PAD--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
class PublicacionesA(Fact):
    publicacionesA = Field(int)
    tercilA = Field(list) 
    factorA = Field(list)
    numeroAutoresA = Field(list)
    continuaA = Field(list)
    pass

class LibrosA(Fact):
    librosA = Field(int)
    isbnA = Field(list)
    editorialA = Field(list)
    citasA = Field(list)
    tercilCitasA = Field(list)
    traduccionesA = Field(list)
    pass

class ProyectosA(Fact):
    proyectosA = Field(int)
    tipoParticipacionA = Field(list)
    organismoA = Field(list)
    gradoResponsabilidadA = Field(list)
    evaluadorExternoA = Field(list)
    pass 

class EventosA(Fact):
    eventosA = Field(int)
    procesoAdmisionA = Field(list)
    caracterA = Field(list)
    participacionA = Field(list)
    pass

class OtrosMeritosInvPAD(Fact):
    otrosMeritosInvPAD = Field(int)
    pass

class FormacionPAD(Fact):
    estudiosPAD = Field(int)
    calificacionPAD = Field(list)
    doctoradoEuropeoPAD = Field(list)
    mencionCalidadPAD = Field(list)
    becasPAD = Field(list)
    pass

class EstanciasPAD(Fact):
    estanciasPAD = Field(int)
    tipoPAD = Field(list)
    lugarPAD = Field(list)
    tiempoPAD = Field(list)
    pass

class ExperienciaDocentePAD(Fact):
    experienciasDocentesPAD = Field(int)
    tipoEducacionPAD = Field(list)
    evaluacionesPAD = Field(list)
    materialDocentePAD = Field(list)
    proyectosDocentesPAD = Field(list)
    eventosDocentesPAD = Field(list)
    pass

class ExperienciaProfesionalPAD(Fact):
    experienciasProfPAD = Field(int)
    tipoInstitucionPAD = Field(list)
    laborPAD = Field(list)
    duracionPAD = Field(list)
    pass

class OtrosMeritosPAD(Fact):
    otrosMeritosAcademicosPAD = Field(list)
    otrosMeritosDocentesPAD = Field(list)
    otrosMeritosInvestigacionPAD = Field(list)
    otrosMeritosProfesionalesPAD = Field(list)
    becasInvestigacionPAD = Field(list)
    pass



#EVALUACION CIENCIAS EXPERIMENTALES PAD-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class EvaluacionPublicacionesACE(KnowledgeEngine):
    resultadoPublicacionesACE = 0
    @Rule(PublicacionesA(publicacionesA = P(lambda x: x == 0)))
    def no_publicaciones(self):
        resultado = 0
        self.resultadoPublicacionesACE = resultado
        print("resultado publicaciones = " + str(resultado))
    
    @Rule(PublicacionesA(publicacionesA = P(lambda x: x >= 6)))
    def max_publicacionesACE(self):
        publicacionesA = self.facts[1]['publicacionesA']
        tercilA = self.facts[2]['tercilA']
        factorA = self.facts[3]['factorA']
        numeroAutoresA = self.facts[4]['numeroAutoresA']
        continuaA = self.facts[5]['continuaA']
        resultado = 0
        if len(tercilA) >= 6:
            resultado = 35
        else:
            for i in tercilA:
                if i == "T1":
                    resultado += 2
                elif i == "T2":
                    resultado += 1
                elif i == "T3":
                    resultado += 0.5
                else:
                    continue
        
            for i in factorA:
                if i == "Alto":
                    resultado += 2
                elif i == "Medio":
                    resultado += 1
                else:
                    continue
        
            for i in numeroAutoresA:
                if (int(i) == 1):
                    resultado += 1
                elif ((int(i) == 2) or (int(i) == 3)):
                    resultado += 0.5
                else:
                    continue
        
            for i in continuaA:
                if i == "Si":
                    resultado += 1
                else:
                    continue
            resultado = round(resultado)
        self.resultadoPublicacionesACE = resultado
        print("resultado publicaciones = " + str(resultado))

    @Rule(PublicacionesA(publicacionesA = P(lambda x: 0 < x < 6)))
    def publicacionesACE(self):
        resultado = 0
        publicacionesA = self.facts[1]['publicacionesA']
        tercilA = self.facts[2]['tercilA']
        factorA = self.facts[3]['factorA']
        numeroAutoresA = self.facts[4]['numeroAutoresA']
        continuaA = self.facts[5]['continuaA']

        for i in tercilA:
            if i == "T1":
                resultado += 2
            elif i == "T2":
                resultado += 1
            elif i == "T3":
                resultado += 0.5
            else:
                continue
        
        for i in factorA:
            if i == "Alto":
                resultado += 2
            elif i == "Medio":
                resultado += 1
            else:
                continue
        
        for i in numeroAutoresA:
            if (int(i) == 1):
                resultado += 1
            elif ((int(i) == 2) or (int(i) == 3)):
                resultado += 0.5
            else:
                continue
        
        for i in continuaA:
            if i == "Si":
                resultado += 1
            else:
                continue

        resultado = round(resultado)
        self.resultadoPublicacionesACE = resultado
        print("resultado publicaciones = " + str(resultado))

class EvaluacionLibrosACE(KnowledgeEngine):
    resultadoLibrosACE = 0
    @Rule(LibrosA(librosA = P(lambda x: x == 0)))
    def no_librosACE(self):
        resultado = 0
        self.resultadoLibrosACE = resultado
        print("Resultado libros = 0")
    
    @Rule(LibrosA(librosA = P(lambda x: x > 0)))
    def librosACE(self):
        librosA = self.facts[1]['librosA']
        isbnA = self.facts[2]['isbnA']
        citasA = self.facts[3]['citasA']
        tercilCitasA = self.facts[4]['tercilCitasA']
        traduccionesA = self.facts[5]['traduccionesA']
        resultado = 0
        
        for i in isbnA:
            if i == "Si":
                resultado += 1
            elif i == "No":
                resultado += 0.5
        
        if resultado > 3:
            resultado = 3
        
        for i in citasA:
            if i == "Si":
                resultado += 0.5
            else: 
                continue
        
        if resultado > 4:
            resultado = 4

        for i in tercilCitasA:
            if ((i == "T1") or (i == "T2")):
                resultado += 1
            else:
                resultado += 0.25

        if resultado > 6:
            resultado = 6

        for i in traduccionesA:
            if i == "Si":
                resultado += 0.5
            else: 
                continue


        resultado = round(resultado)
        if resultado > 7:
            resultado = 7

        
        self.resultadoLibrosACE = resultado
        print('resultado libros = ' + str(resultado))

class EvaluacionProyectosACE(KnowledgeEngine):
    resultadoProyectosACE = 0
    @Rule(ProyectosA(proyectosA = P(lambda x: x == 0)))
    def no_proyectosACE(self):
        resultado = 0
        self.resultadoProyectosACE = resultado
        print("resultado = " + str(resultado))
    
    @Rule(ProyectosA(proyectosA = P(lambda x: x > 0)))
    def proyectosACE(self):
        proyectosA = self.facts[1]['proyectosA']
        tipoParticipacionA = self.facts[2]['tipoParticipacionA']
        organismoA = self.facts[3]['organismoA']
        gradoResponsabilidadA = self.facts[4]['gradoResponsabilidadA']
        evaluadorExternoA = self.facts[5]['evaluadorExternoA']
        resultado = 0

        for i in organismoA:
            if i == "Union Europea":
                resultado += 1
            elif i == "Nacional":
                resultado += 0.75
            elif i == "Comunidad Autonoma":
                resultado += 0.5

        if resultado > 2:
            resultado = 2

        for i in evaluadorExternoA:
            if i == "Si":
                resultado += 0.5
            else:
                continue
        
        if resultado > 3:
            resultado = 3
        
        for i in tipoParticipacionA:
            if ((i == "Jefe de proyecto") or (i == "Director")):
                resultado += 0.5
            elif (i == "Empleado"):
                resultado += 0.25
            else:
                continue
        
        if resultado > 4:
            resultado = 4

        for i in gradoResponsabilidadA:
            if i == "Alta":
                resultado += 0.5
            elif i == "Media":
                resultado += 0.25
            else:
                continue
        
        resultado = round(resultado)
        if resultado > 5:
            resultado = 5

        self.resultadoProyectosACE = resultado
        print("resultado Proyectos = " + str(resultado))

class EvaluacionEventosACE(KnowledgeEngine):
    resultadoEventosACE = 0
    @Rule(EventosA(eventosA = P(lambda x: x == 0)))
    def no_eventosACE(self):
        resultado = 0
        self.resultadoEventosACE = resultado
        print("resultado eventos = 0")
    
    @Rule(EventosA(eventosA = P(lambda x: x > 0)))
    def eventos(self):
        eventosA = self.facts[1]['eventosA']
        procesoAdmisionA = self.facts[2]['procesoAdmisionA']
        caracterA = self.facts[3]['caracterA']
        participacionA = self.facts[4]['participacionA']
        resultado = 0
        
        
        for i in procesoAdmisionA:
            if i == "Si":
                resultado += 1
            else:
                resultado += 0.5

        if resultado > 3:
            resultado = 3

        for i in caracterA:
            if i == "Internacional":
                resultado += 1
            elif i == "Nacional":
                resultado += 0.5
            else:
                continue
        if resultado > 6:
            resultado = 6
            
        for i in participacionA:
            if i == "Ponencia invitada":
                resultado += 1
            elif((i == "Ponencia") or (i == "Comunicacion oral") or (i == "Póster") or (i == "Participación en la organización") or (i == "Participación en el comité científico")):
                resultado += 0.5
            else:
                continue
        
        resultado = round(resultado)
        if resultado > 9:
            resultado = 9

        self.resultadoEventosACE = resultado
        print("resultado eventos = " + str(resultado))


#EVALUACION CIENCIAS DE LA SALUD PAD--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class EvaluacionPublicacionesACS(KnowledgeEngine):
    resultadoPublicacionesACS = 0
    @Rule(PublicacionesA(publicacionesA = P(lambda x: x == 0)))
    def no_publicaciones(self):
        resultado = 0
        self.resultadoPublicacionesACS = resultado
        print("resultado publicaciones = " + str(resultado))

    @Rule(PublicacionesA(publicacionesA = P(lambda x: 0 < x)))
    def publicacionesACS(self):
        resultado = 0
        publicacionesA = self.facts[1]['publicacionesA']
        tercilA = self.facts[2]['tercilA']
        factorA = self.facts[3]['factorA']
        numeroAutoresA = self.facts[4]['numeroAutoresA']
        continuaA = self.facts[5]['continuaA']

        cuentaTercil = 0
        for i in tercilA:
            if ((i == "T1") or (i == "T2")):
                cuentaTercil += 1
            else:
                continue
        
        if cuentaTercil >= 2:
            resultado = 35
        
        else:    
            for i in tercilA:
                if ((i == "T1") or (i == "T2")):
                    resultado += 15
                elif(i == "T3"):
                    resultado += 8
                else:
                    resultado += 2
            if resultado > 25:
                resultado = 25
            
            for i in factorA:
                if i == "Alto":
                    resultado += 3
                elif i == "Medio":
                    resultado += 2
                else:
                    continue
            
            if resultado > 28:
                resultado = 28
            
            for i in numeroAutoresA:
                if (int(i) == 1):
                    resultado += 2
                elif ((int(i) == 2) or (int(i) == 3)):
                    resultado += 1
                else:
                    continue
            if resultado > 30:
                resultado = 30
            
            for i in continuaA:
                if i == "Si":
                    resultado += 2
                else:
                    continue
            if resultado > 32:
                resultado = 32

        resultado = round(resultado)
        self.resultadoPublicacionesACS = resultado
        print("resultado publicaciones = " + str(resultado))

class EvaluacionLibrosACS(KnowledgeEngine):
    resultadoLibrosACS = 0
    @Rule(LibrosA(librosA = P(lambda x: x == 0)))
    def no_librosACS(self):
        resultado = 0
        self.resultadoLibrosACS = resultado
        print("Resultado libros = 0")
    
    @Rule(LibrosA(librosA = P(lambda x: x > 0)))
    def librosACS(self):
        librosA = self.facts[1]['librosA']
        isbnA = self.facts[2]['isbnA']
        citasA = self.facts[3]['citasA']
        tercilCitasA = self.facts[4]['tercilCitasA']
        traduccionesA = self.facts[5]['traduccionesA']
        resultado = 0
        
        for i in isbnA:
            if i == "Si":
                resultado += 1
            elif i == "No":
                resultado += 0.5
        
        if resultado > 3:
            resultado = 3
        
        for i in citasA:
            if i == "Si":
                resultado += 0.5
            else: 
                continue
        
        if resultado > 4:
            resultado = 4

        for i in tercilCitasA:
            if ((i == "T1") or (i == "T2")):
                resultado += 1
            else:
                resultado += 0.25

        if resultado > 6:
            resultado = 6

        for i in traduccionesA:
            if i == "Si":
                resultado += 0.5
            else: 
                continue


        resultado = round(resultado)
        if resultado > 7:
            resultado = 7

        
        self.resultadoLibrosACS = resultado
        print('resultado libros = ' + str(resultado))

class EvaluacionProyectosACS(KnowledgeEngine):
    resultadoProyectosACS = 0
    @Rule(ProyectosA(proyectosA = P(lambda x: x == 0)))
    def no_proyectosACS(self):
        resultado = 0
        self.resultadoProyectosACS = resultado
        print("resultado = " + str(resultado))
    
    @Rule(ProyectosA(proyectosA = P(lambda x: x > 0)))
    def proyectosACS(self):
        proyectosA = self.facts[1]['proyectosA']
        tipoParticipacionA = self.facts[2]['tipoParticipacionA']
        organismoA = self.facts[3]['organismoA']
        gradoResponsabilidadA = self.facts[4]['gradoResponsabilidadA']
        evaluadorExternoA = self.facts[5]['evaluadorExternoA']
        resultado = 0

        for i in organismoA:
            if i == "Union Europea":
                resultado += 1
            elif i == "Nacional":
                resultado += 0.75
            elif i == "Comunidad Autonoma":
                resultado += 0.5

        if resultado > 2:
            resultado = 2

        for i in evaluadorExternoA:
            if i == "Si":
                resultado += 0.5
            else:
                continue
        
        if resultado > 3:
            resultado = 3
        
        for i in tipoParticipacionA:
            if ((i == "Jefe de proyecto") or (i == "Director")):
                resultado += 0.5
            elif (i == "Empleado"):
                resultado += 0.25
            else:
                continue
        
        if resultado > 4:
            resultado = 4

        for i in gradoResponsabilidadA:
            if i == "Alta":
                resultado += 0.5
            elif i == "Media":
                resultado += 0.25
            else:
                continue
        
        resultado = round(resultado)
        if resultado > 5:
            resultado = 5

        self.resultadoProyectosACS = resultado
        print("resultado Proyectos = " + str(resultado))

class EvaluacionEventosACS(KnowledgeEngine):
    resultadoEventosACS = 0
    @Rule(EventosA(eventosA = P(lambda x: x == 0)))
    def no_eventosACS(self):
        resultado = 0
        self.resultadoEventosACS = resultado
        print("resultado = 0")
    
    @Rule(EventosA(eventosA = P(lambda x: x > 0)))
    def eventos(self):
        eventosA = self.facts[1]['eventosA']
        procesoAdmisionA = self.facts[2]['procesoAdmisionA']
        caracterA = self.facts[3]['caracterA']
        participacionA = self.facts[4]['participacionA']
        resultado = 0
        
        
        for i in procesoAdmisionA:
            if i == "Si":
                resultado += 1
            else:
                resultado += 0.5

        if resultado > 3:
            resultado = 3

        for i in caracterA:
            if i == "Internacional":
                resultado += 1
            elif i == "Nacional":
                resultado += 0.5
            else:
                continue
        if resultado > 6:
            resultado = 6
            
        for i in participacionA:
            if i == "Ponencia invitada":
                resultado += 1
            elif((i == "Ponencia") or (i == "Comunicacion oral") or (i == "Póster") or (i == "Participación en la organización") or (i == "Participación en el comité científico")):
                resultado += 0.5
            else:
                continue
        
        resultado = round(resultado)
        if resultado > 9:
            resultado = 9

        self.resultadoEventosACS = resultado
        print("resultado eventos = " + str(resultado))


#EVALUACION ENSEÑANZAS TECNICAS PAD---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class EvaluacionPublicacionesAET(KnowledgeEngine):
    resultadoPublicacionesAET = 0
    @Rule(PublicacionesA(publicacionesA = P(lambda x: x == 0)))
    def no_publicaciones(self):
        resultado = 0
        self.resultadoPublicacionesAET = resultado
        print("resultado publicaciones = " + str(resultado))
    
    @Rule(PublicacionesA(publicacionesA = P(lambda x: x >= 4)))
    def max_publicacionesAET(self):
        resultado = 0
        publicacionesA = self.facts[1]['publicacionesA']
        tercilA = self.facts[2]['tercilA']
        factorA = self.facts[3]['factorA']
        numeroAutoresA = self.facts[4]['numeroAutoresA']
        continuaA = self.facts[5]['continuaA']
        if len(tercilA) >= 4:
            resultado = 35
        else:
            for i in tercilA:
                if ((i == "T1") or (i == "T2")):
                    resultado += 5
                elif(i == "T3"):
                    resultado += 3
                else:
                    resultado += 2
        
            if resultado > 15:
                resultado = 15
            
            for i in factorA:
                if i == "Alto":
                    resultado += 2
                elif i == "Medio":
                    resultado += 1.5
                else:
                    continue
            
            if resultado > 21:
                resultado = 21
            
            for i in numeroAutoresA:
                if (int(i) == 1):
                    resultado += 1
                elif ((int(i) == 2) or (int(i) == 3)):
                    resultado += 0.5
                else:
                    continue
            if resultado > 24:
                resultado = 24
            
            for i in continuaA:
                if i == "Si":
                    resultado += 1
                else:
                    continue
            if resultado > 27:
                resultado = 27

            resultado = round(resultado)

        self.resultadoPublicacionesAET = resultado
        print("resultado publicaciones = " + str(resultado))

    @Rule(PublicacionesA(publicacionesA = P(lambda x: 0 < x < 4)))
    def publicacionesAET(self):
        resultado = 0
        publicacionesA = self.facts[1]['publicacionesA']
        tercilA = self.facts[2]['tercilA']
        factorA = self.facts[3]['factorA']
        numeroAutoresA = self.facts[4]['numeroAutoresA']
        continuaA = self.facts[5]['continuaA']
        
            
        for i in tercilA:
            if ((i == "T1") or (i == "T2")):
                resultado += 5
            elif(i == "T3"):
                resultado += 3
            else:
                resultado += 2
        
        if resultado > 15:
           resultado = 15
            
        for i in factorA:
            if i == "Alto":
                resultado += 2
            elif i == "Medio":
                resultado += 1.5
            else:
                continue
            
        if resultado > 21:
            resultado = 21
            
        for i in numeroAutoresA:
            if (int(i) == 1):
                resultado += 1
            elif ((int(i) == 2) or (int(i) == 3)):
                resultado += 0.5
            else:
                continue
        if resultado > 24:
            resultado = 24
            
        for i in continuaA:
            if i == "Si":
                resultado += 1
            else:
                continue
        if resultado > 27:
            resultado = 27

        resultado = round(resultado)
        self.resultadoPublicacionesAET = resultado
        print("resultado publicaciones = " + str(resultado))

class EvaluacionLibrosAET(KnowledgeEngine):
    resultadoLibrosAET = 0
    @Rule(LibrosA(librosA = P(lambda x: x == 0)))
    def no_librosAET(self):
        resultado = 0
        self.resultadoLibrosAET = resultado
        print("resultado libros = " + str(resultado))
    
    @Rule(LibrosA(librosA = P(lambda x: x > 0)))
    def librosAET(self):
        resultado = 0
        librosA = self.facts[1]['librosA']
        isbnA = self.facts[2]['isbnA']
        citasA = self.facts[3]['citasA']
        tercilCitasA = self.facts[4]['tercilCitasA']
        traduccionesA = self.facts[5]['traduccionesA']

        for i in isbnA:
            if i == "Si":
                resultado += 1
            elif i == "No":
                resultado += 0.5

        if resultado > 1:
            resultado = 1

        for i in citasA:
            if i == "Si":
                resultado += 1
            else:
                continue
        
        if resultado > 2:
            resultado = 2
        
        for i in tercilCitasA:
            if i == "T1":
                resultado += 0.5
            else:
                continue

        if resultado > 2.5:
            resultado = 2.5
            
        for i in traduccionesA:
            if i == "Si":
                resultado += 0.5
        
        resultado = round(resultado)
        if resultado > 3:
            resultado = 3
        
        self.resultadoLibrosAET = resultado
        print("resultado libros = " + str(resultado))

class EvaluacionProyectosAET(KnowledgeEngine):
    resultadoProyectosAET = 0
    @Rule(ProyectosA(proyectosA = P(lambda x: x == 0)))
    def no_proyectosAET(self):
        resultado = 0
        self.resultadoProyectosAET = resultado
        print("resultado = " + str(resultado))
    
    @Rule(ProyectosA(proyectosA = P(lambda x: x > 0)))
    def proyectosAET(self):
        proyectosA = self.facts[1]['proyectosA']
        tipoParticipacionA = self.facts[2]['tipoParticipacionA']
        organismoA = self.facts[3]['organismoA']
        gradoResponsabilidadA = self.facts[4]['gradoResponsabilidadA']
        evaluadorExternoA = self.facts[5]['evaluadorExternoA']
        resultado = 0

        for i in organismoA:
            if i == "Union Europea":
                resultado += 1.25
            elif i == "Nacional":
                resultado += 1
            elif i == "Comunidad Autonoma":
                resultado += 0.75

        if resultado > 4:
            resultado = 4

        for i in evaluadorExternoA:
            if i == "Si":
                resultado += 0.5
            else:
                continue
        
        if resultado > 6:
            resultado = 6
        
        for i in tipoParticipacionA:
            if ((i == "Jefe de proyecto") or (i == "Director")):
                resultado += 0.5
            elif (i == "Empleado"):
                resultado += 0.25
            else:
                continue
        
        if resultado > 7:
            resultado = 7

        for i in gradoResponsabilidadA:
            if i == "Alta":
                resultado += 0.5
            elif i == "Media":
                resultado += 0.25
            else:
                continue
        
        resultado = round(resultado)
        if resultado > 9:
            resultado = 9

        self.resultadoProyectosAET = resultado
        print("resultado Proyectos = " + str(resultado))

class EvaluacionEventosAET(KnowledgeEngine):
    resultadoEventosAET = 0
    @Rule(EventosA(eventosA = P(lambda x: x == 0)))
    def no_eventosAET(self):
        resultado = 0
        self.resultadoEventosAET = resultado
        print("resultado = 0")
    
    @Rule(EventosA(eventosA = P(lambda x: x > 0)))
    def eventos(self):
        eventosA = self.facts[1]['eventosA']
        procesoAdmisionA = self.facts[2]['procesoAdmisionA']
        caracterA = self.facts[3]['caracterA']
        participacionA = self.facts[4]['participacionA']
        resultado = 0
        
        
        for i in procesoAdmisionA:
            if i == "Si":
                resultado += 1
            else:
                resultado += 0.5

        if resultado > 3:
            resultado = 3

        for i in caracterA:
            if i == "Internacional":
                resultado += 1
            elif i == "Nacional":
                resultado += 0.5
            else:
                continue
        if resultado > 6:
            resultado = 6
            
        for i in participacionA:
            if i == "Ponencia invitada":
                resultado += 1
            elif((i == "Ponencia") or (i == "Comunicacion oral") or (i == "Póster") or (i == "Participación en la organización") or (i == "Participación en el comité científico")):
                resultado += 0.5
            else:
                continue
        
        resultado = round(resultado)
        if resultado > 9:
            resultado = 9

        self.resultadoEventosAET = resultado
        print("resultado eventos = " + str(resultado))



#EVALUACION CIENCIAS SOCIALES Y JURIDICAS PAD-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class EvaluacionPublicacionesASJ(KnowledgeEngine):
    resultadoPublicacionesASJ = 0
    @Rule(PublicacionesA(publicacionesA = P(lambda x: x == 0)))
    def no_publicaciones(self):
        resultado = 0
        self.resultadoPublicacionesASJ = resultado
        print("resultado publicaciones = " + str(resultado))
    
    @Rule(PublicacionesA(publicacionesA = P(lambda x: x >= 3)))
    def max_publicacionesASJ(self):
        resultado = 0
        publicacionesA = self.facts[1]['publicacionesA']
        tercilA = self.facts[2]['tercilA']
        factorA = self.facts[3]['factorA']
        numeroAutoresA = self.facts[4]['numeroAutoresA']
        continuaA = self.facts[5]['continuaA']
        
        if len(tercilA) >= 3:
            resultado = 30
        else:
            for i in tercilA:
                if ((i == "T1") or (i == "T2")):
                    resultado += 7.5
                elif(i == "T3"):
                    resultado += 6
                else:
                    resultado += 3
            
            for i in factorA:
                if i == "Alto":
                    resultado += 3
                elif i == "Medio":
                    resultado += 2
                else:
                    continue
            
            
            for i in numeroAutoresA:
                if (int(i) == 1):
                    resultado += 1.5
                elif ((int(i) == 2) or (int(i) == 3)):
                    resultado += 0.75
                else:
                    continue
            
            for i in continuaA:
                if i == "Si":
                    resultado += 1.5
                else:
                    continue
        
            resultado = round(resultado)
            if resultado > 27:
                resultado = 27

        self.resultadoPublicacionesASJ = resultado
        print("resultado publicaciones = " + str(resultado))

    @Rule(PublicacionesA(publicacionesA = P(lambda x: 0 < x < 3)))
    def publicacionesASJ(self):
        resultado = 0
        publicacionesA = self.facts[1]['publicacionesA']
        tercilA = self.facts[2]['tercilA']
        factorA = self.facts[3]['factorA']
        numeroAutoresA = self.facts[4]['numeroAutoresA']
        continuaA = self.facts[5]['continuaA']
        
            
        for i in tercilA:
            if ((i == "T1") or (i == "T2")):
                resultado += 7.5
            elif(i == "T3"):
                resultado += 6
            else:
                resultado += 3
            
        for i in factorA:
            if i == "Alto":
                resultado += 3
            elif i == "Medio":
                resultado += 2
            else:
                continue
            
            
        for i in numeroAutoresA:
            if (int(i) == 1):
                resultado += 1.5
            elif ((int(i) == 2) or (int(i) == 3)):
                resultado += 0.75
            else:
                continue
            
        for i in continuaA:
            if i == "Si":
                resultado += 1.5
            else:
                continue
        
        resultado = round(resultado)
        if resultado > 27:
            resultado = 27

        self.resultadoPublicacionesASJ = resultado
        print("resultado publicaciones = " + str(resultado))

class EvaluacionLibrosASJ(KnowledgeEngine):
    resultadoLibrosASJ = 0
    @Rule(LibrosA(librosA = P(lambda x: x == 0)))
    def no_librosASJ(self):
        resultado = 0
        self.resultadoLibrosASJ = resultado
        print("resultado libros = " + str(resultado))
    
    @Rule(LibrosA(librosA = P(lambda x: x > 0)))
    def librosASJ(self):
        resultado = 0
        librosA = self.facts[1]['librosA']
        isbnA = self.facts[2]['isbnA']
        citasA = self.facts[3]['citasA']
        tercilCitasA = self.facts[4]['tercilCitasA']
        traduccionesA = self.facts[5]['traduccionesA']

        for i in isbnA:
            if i == "Si":
                resultado += 1
            elif i == "No":
                resultado += 0.75

        if resultado > 4:
            resultado = 4

        for i in citasA:
            if i == "Si":
                resultado += 1
            else:
                continue
        
        if resultado > 8:
            resultado = 8
        
        for i in tercilCitasA:
            if i == "T1":
                resultado += 0.5
            else:
                continue

        if resultado > 10:
            resultado = 10   

        for i in traduccionesA:
            if i == "Si":
                resultado += 0.5
        
        resultado = round(resultado)
        if resultado > 12:
            resultado = 12
        
        self.resultadoLibrosASJ = resultado
        print("resultado libros = " + str(resultado))

class EvaluacionProyectosASJ(KnowledgeEngine):
    resultadoProyectosASJ = 0
    @Rule(ProyectosA(proyectosA = P(lambda x: x == 0)))
    def no_proyectosASJ(self):
        resultado = 0
        self.resultadoProyectosASJ = resultado
        print("resultado = " + str(resultado))
    
    @Rule(ProyectosA(proyectosA = P(lambda x: x > 0)))
    def proyectosASJ(self):
        proyectosA = self.facts[1]['proyectosA']
        tipoParticipacionA = self.facts[2]['tipoParticipacionA']
        organismoA = self.facts[3]['organismoA']
        gradoResponsabilidadA = self.facts[4]['gradoResponsabilidadA']
        evaluadorExternoA = self.facts[5]['evaluadorExternoA']
        resultado = 0

        for i in organismoA:
            if i == "Union Europea":
                resultado += 1
            elif i == "Nacional":
                resultado += 0.75
            elif i == "Comunidad Autonoma":
                resultado += 0.5

        if resultado > 2:
            resultado = 2

        for i in evaluadorExternoA:
            if i == "Si":
                resultado += 0.5
            else:
                continue
        
        if resultado > 3:
            resultado = 3
        
        for i in tipoParticipacionA:
            if ((i == "Jefe de proyecto") or (i == "Director")):
                resultado += 0.5
            elif (i == "Empleado"):
                resultado += 0.25
            else:
                continue
        
        if resultado > 4:
            resultado = 4

        for i in gradoResponsabilidadA:
            if i == "Alta":
                resultado += 0.5
            elif i == "Media":
                resultado += 0.25
            else:
                continue
        
        resultado = round(resultado)
        if resultado > 5:
            resultado = 5

        self.resultadoProyectosASJ = resultado
        print("resultado Proyectos = " + str(resultado))

class EvaluacionEventosASJ(KnowledgeEngine):
    resultadoEventosASJ = 0
    @Rule(EventosA(eventosA = P(lambda x: x == 0)))
    def no_eventosASJ(self):
        resultado = 0
        self.resultadoEventosASJ = resultado
        print("resultado = 0")
    
    @Rule(EventosA(eventosA = P(lambda x: x > 0)))
    def eventos(self):
        eventosA = self.facts[1]['eventosA']
        procesoAdmisionA = self.facts[2]['procesoAdmisionA']
        caracterA = self.facts[3]['caracterA']
        participacionA = self.facts[4]['participacionA']
        resultado = 0
        
        
        for i in procesoAdmisionA:
            if i == "Si":
                resultado += 1
            else:
                resultado += 0.5

        if resultado > 3:
            resultado = 3

        for i in caracterA:
            if i == "Internacional":
                resultado += 1
            elif i == "Nacional":
                resultado += 0.5
            else:
                continue
        if resultado > 6:
            resultado = 6
            
        for i in participacionA:
            if i == "Ponencia invitada":
                resultado += 1
            elif((i == "Ponencia") or (i == "Comunicacion oral") or (i == "Póster") or (i == "Participación en la organización") or (i == "Participación en el comité científico")):
                resultado += 0.5
            else:
                continue
        
        resultado = round(resultado)
        if resultado > 9:
            resultado = 9

        self.resultadoEventosASJ = resultado
        print("resultado eventos = " + str(resultado))


#EVALUACION HUMANIDADES PAD-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class EvaluacionPublicacionesAH(KnowledgeEngine):
    resultadoPublicacionesAH = 0
    @Rule(PublicacionesA(publicacionesA = P(lambda x: x == 0)))
    def no_publicaciones(self):
        resultado = 0
        self.resultadoPublicacionesAH = resultado
        print("resultado publicaciones = " + str(resultado))
    
    @Rule(PublicacionesA(publicacionesA = P(lambda x: x >= 5)))
    def max_publicacionesAH(self):
        resultado = 0
        publicacionesA = self.facts[1]['publicacionesA']
        tercilA = self.facts[2]['tercilA']
        factorA = self.facts[3]['factorA']
        numeroAutoresA = self.facts[4]['numeroAutoresA']
        continuaA = self.facts[5]['continuaA']

        if len(tercilA) >= 5:
            resultado = 26
        else:
            for i in tercilA:
                if ((i == "T1") or (i == "T2")):
                    resultado += 2
                elif(i == "T3"):
                    resultado += 1
                else:
                    resultado += 0.5
            
            for i in factorA:
                if i == "Alto":
                    resultado += 2
                elif i == "Medio":
                    resultado += 1
                else:
                    continue
            
            
            for i in numeroAutoresA:
                if (int(i) == 1):
                    resultado += 1
                elif ((int(i) == 2) or (int(i) == 3)):
                    resultado += 0.5
                else:
                    continue
            
            for i in continuaA:
                if i == "Si":
                    resultado += 1
                else:
                    continue
        
            resultado = round(resultado)
            if resultado > 24:
                resultado = 24
        self.resultadoPublicacionesAH = resultado
        print("resultado publicaciones = " + str(resultado))

    @Rule(PublicacionesA(publicacionesA = P(lambda x: 0 < x < 5)))
    def publicacionesAH(self):
        resultado = 0
        publicacionesA = self.facts[1]['publicacionesA']
        tercilA = self.facts[2]['tercilA']
        factorA = self.facts[3]['factorA']
        numeroAutoresA = self.facts[4]['numeroAutoresA']
        continuaA = self.facts[5]['continuaA']
        
            
        for i in tercilA:
            if ((i == "T1") or (i == "T2")):
                resultado += 2
            elif(i == "T3"):
                resultado += 1
            else:
                resultado += 0.5
            
        for i in factorA:
            if i == "Alto":
                resultado += 2
            elif i == "Medio":
                resultado += 1
            else:
                continue
            
            
        for i in numeroAutoresA:
            if (int(i) == 1):
                resultado += 1
            elif ((int(i) == 2) or (int(i) == 3)):
                resultado += 0.5
            else:
                continue
            
        for i in continuaA:
            if i == "Si":
                resultado += 1
            else:
                continue
        
        resultado = round(resultado)
        if resultado > 24:
            resultado = 24

        self.resultadoPublicacionesAH = resultado
        print("resultado publicaciones = " + str(resultado))

class EvaluacionLibrosAH(KnowledgeEngine):
    resultadoLibrosAH = 0
    @Rule(LibrosA(librosA = P(lambda x: x == 0)))
    def no_librosAH(self):
        resultado = 0
        self.resultadoLibrosAH = resultado
        print("resultado libros = " + str(resultado))
    
    @Rule(LibrosA(librosA = P(lambda x: x > 0)))
    def librosAH(self):
        resultado = 0
        librosA = self.facts[1]['librosA']
        isbnA = self.facts[2]['isbnA']
        citasA = self.facts[3]['citasA']
        tercilCitasA = self.facts[4]['tercilCitasA']
        traduccionesA = self.facts[5]['traduccionesA']

        for i in isbnA:
            if i == "Si":
                resultado += 1
            elif i == "No":
                resultado += 0.75

        if resultado > 4:
            resultado = 4

        for i in citasA:
            if i == "Si":
                resultado += 1
            else:
                continue
        
        if resultado > 8:
            resultado = 8
        
        for i in tercilCitasA:
            if i == "T1":
                resultado += 1
            elif i == "T2":
                resultado += 0.75
            else:    
                continue

        if resultado > 12:
            resultado = 12   

        for i in traduccionesA:
            if i == "Si":
                resultado += 1
        
        resultado = round(resultado)
        if resultado > 16:
            resultado = 16
        
        self.resultadoLibrosAH = resultado
        print("resultado libros = " + str(resultado))

class EvaluacionProyectosAH(KnowledgeEngine):
    resultadoProyectosAH = 0
    @Rule(ProyectosA(proyectosA = P(lambda x: x == 0)))
    def no_proyectosAH(self):
        resultado = 0
        self.resultadoProyectosAH = resultado
        print("resultado = " + str(resultado))
    
    @Rule(ProyectosA(proyectosA = P(lambda x: x > 0)))
    def proyectosAH(self):
        proyectosA = self.facts[1]['proyectosA']
        tipoParticipacionA = self.facts[2]['tipoParticipacionA']
        organismoA = self.facts[3]['organismoA']
        gradoResponsabilidadA = self.facts[4]['gradoResponsabilidadA']
        evaluadorExternoA = self.facts[5]['evaluadorExternoA']
        resultado = 0

        for i in organismoA:
            if i == "Union Europea":
                resultado += 1
            elif i == "Nacional":
                resultado += 0.75
            elif i == "Comunidad Autonoma":
                resultado += 0.5

        if resultado > 2:
            resultado = 2

        for i in evaluadorExternoA:
            if i == "Si":
                resultado += 0.5
            else:
                continue
        
        if resultado > 3:
            resultado = 3
        
        for i in tipoParticipacionA:
            if ((i == "Jefe de proyecto") or (i == "Director")):
                resultado += 0.5
            elif (i == "Empleado"):
                resultado += 0.25
            else:
                continue
        
        if resultado > 4:
            resultado = 4

        for i in gradoResponsabilidadA:
            if i == "Alta":
                resultado += 0.5
            elif i == "Media":
                resultado += 0.25
            else:
                continue
        
        resultado = round(resultado)
        if resultado > 5:
            resultado = 5

        self.resultadoProyectosAH = resultado
        print("resultado Proyectos = " + str(resultado))

class EvaluacionEventosAH(KnowledgeEngine):
    resultadoEventosAH = 0
    @Rule(EventosA(eventosA = P(lambda x: x == 0)))
    def no_eventosAH(self):
        resultado = 0
        self.resultadoEventosAH = resultado
        print("resultado = 0")
    
    @Rule(EventosA(eventosA = P(lambda x: x > 0)))
    def eventos(self):
        eventosA = self.facts[1]['eventosA']
        procesoAdmisionA = self.facts[2]['procesoAdmisionA']
        caracterA = self.facts[3]['caracterA']
        participacionA = self.facts[4]['participacionA']
        resultado = 0
        
        
        for i in procesoAdmisionA:
            if i == "Si":
                resultado += 1
            else:
                resultado += 0.5

        if resultado > 3:
            resultado = 3

        for i in caracterA:
            if i == "Internacional":
                resultado += 1
            elif i == "Nacional":
                resultado += 0.5
            else:
                continue
        if resultado > 6:
            resultado = 6
            
        for i in participacionA:
            if i == "Ponencia invitada":
                resultado += 1
            elif((i == "Ponencia") or (i == "Comunicacion oral") or (i == "Póster") or (i == "Participación en la organización") or (i == "Participación en el comité científico")):
                resultado += 0.5
            else:
                continue
        
        resultado = round(resultado)
        if resultado > 9:
            resultado = 9

        self.resultadoEventosAH = resultado
        print("resultado eventos = " + str(resultado))

#EVALUACION COMUN PAD-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class EvaluacionOtrosMeritosInvPAD(KnowledgeEngine):
    resultadoOtrosMeritosInvPAD = 0
    @Rule()
    def otros_meritos_inv_pad(self):
        resultado = 0
        otrosMeritosInvPAD = self.facts[1]['otrosMeritosInvPAD']
        if otrosMeritosInvPAD == 1:
            resultado = 2
        elif otrosMeritosInvPAD == 2:
            resultado = 4
        else:
            resultado = 0
        self.resultadoOtrosMeritosInvPAD = resultado
        print("resultado otros meritos investigacion = " + str(resultado))

class EvaluacionFormacionPAD(KnowledgeEngine):
    resultadoFormacionPAD = 0
    @Rule()
    def formacionPAD(self):
        estudiosPAD = self.facts[1]['estudiosPAD']
        calificacionPAD = self.facts[2]['calificacionPAD']
        doctoradoEuropeoPAD = self.facts[3]['doctoradoEuropeoPAD']
        mencionCalidadPAD = self.facts[4]['mencionCalidadPAD']
        becasPAD = self.facts[5]['becasPAD']
        resultado = 0

        if estudiosPAD == 1:
            resultado = int(calificacionPAD[0]) * 0.6
            if doctoradoEuropeoPAD[0] == "Si":
                resultado += 1
            if mencionCalidadPAD[0] == "Si":
                resultado += 1
            if ((becasPAD[0] == "Predoctoral") or (becasPAD[0] == "Postdoctoral")):
                resultado += 0.5
            elif ((becasPAD[0] == "Predoctoral y Postdoctoral")):
                resultado += 1
        
        elif estudiosPAD > 1:
            suma = 0
            for i in calificacionPAD:
                suma += int(i)
            media = round(suma/estudiosPAD)
            resultado = media * 0.6
            for i in doctoradoEuropeoPAD:
                if i == "Si":
                    resultado += 0.5
            for i in mencionCalidadPAD:
                if i == "Si":
                    resultado += 0.5
            for i in becasPAD:
                if ((i == "Predoctoral") or (i == "Postdoctoral")):
                    resultado += 0.5
                elif(i == "Predoctoral y Postdoctoral"):
                    resultado += 0.75
        else:
            resultado = 0
        
        resultado = round(resultado)
        if resultado > 12:
            resultado = 12
        self.resultadoFormacionPAD = resultado
        print("resultado Formacion = " + str(resultado))

class EvaluacionEstanciasPAD(KnowledgeEngine):
    resultadoEstanciasPAD = 0
    @Rule(EstanciasPAD(estanciasPAD = P(lambda x: x == 0)))
    def no_estanciasPAD(self):
        resultado = 0
        self.resultadoEstanciasPAD = resultado
        print("resultado Estancias = " + str(resultado))

    @Rule(EstanciasPAD(estanciasPAD = P(lambda x: x > 0)))
    def estanciasPAD(self):
        resultado = 0
        estanciasPAD = self.facts[1]['estanciasPAD'] 
        tipoPAD = self.facts[2]['tipoPAD']
        lugarPAD = self.facts[3]['lugarPAD']
        tiempoPAD = self.facts[4]['tiempoPAD']

        for i in lugarPAD:
            if i == "Internacional":
                resultado += 2
            elif i == "Nacional":
                resultado += 1.5
            else:
                continue
        
        if resultado > 5:
            resultado = 5

        for i in tipoPAD:
            if i == "Predoctoral":
                resultado += 1
            elif i == "Postdoctoral":
                resultado += 1
            elif i == "Predoctoral y postdoctoral":
                resultado += 2
            else:
                continue

        if resultado > 9:
            resultado = 9

        for i in tiempoPAD:
            if int(i) < 1:
                continue
            elif (1 < (int(i)) < 3):
                resultado += 0.5
            else:
                resultado  += 1
        
        resultado = round(resultado)
        if resultado > 12:
            resultado = 12
        
        self.resultadoEstanciasPAD = resultado
        print("resultado estancias = " + str(resultado))

class EvaluacionExpDocPAD(KnowledgeEngine):
    resultadoExpDocPAD = 0
    @Rule(ExperienciaDocentePAD(experienciasDocentesPAD = P(lambda x: x == 0)))
    def no_experienciaDocPAD(self):
        resultado = 0
        self.resultadoExpDocPAD = resultado
        print("resultado experiencia docente = " + str(resultado))

    @Rule(ExperienciaDocentePAD(experienciasDocentesPAD = P(lambda x: x > 0)))
    def experienciaDocPAD(self):
        resultado = 0
        experienciasDocentesPAD = self.facts[1]['experienciasDocentesPAD']
        tipoEducacionPAD = self.facts[2]['tipoEducacionPAD']
        evaluacionesPAD = self.facts[3]['evaluacionesPAD']
        materialDocentePAD = self.facts[4]['materialDocentePAD']
        proyectosDocentesPAD = self.facts[5]['proyectosDocentesPAD']
        eventosDocentesPAD = self.facts[6]['eventosDocentesPAD']

        if experienciasDocentesPAD == 1:
            resultado = 0.2 * int(evaluacionesPAD[0])
            if tipoEducacionPAD[0] == "Doctorado":
                resultado += 2
            elif tipoEducacionPAD[0] == "Master":
                resultado += 1.5
            elif tipoEducacionPAD[0] == "Grado":
                resultado += 1
            else:
                resultado = resultado
            
            if materialDocentePAD[0] == "Si":
                resultado += 1
            if proyectosDocentesPAD[0] == "Si":
                resultado += 1
            if eventosDocentesPAD[0] == "Si":
                resultado += 1
            
            resultado = round(resultado)
            if resultado > 7:
                resultado = 7
        else:
            suma = 0
            for i in evaluacionesPAD:
                suma += int(i)
            media = 0
            media = round(suma/experienciasDocentesPAD)
            resultado = media * 0.3
            
            for i in tipoEducacionPAD:
                if i == "Doctorado":
                    resultado += 1.5
                elif i == "Master":
                    resultado += 1
                elif i == "Grado":
                    resultado += 0.5
                else:
                    continue
        
            if resultado > 6:
                resultado = 6

            for i in materialDocentePAD:
                if i == "Si":
                    resultado += 0.5
                else:
                    continue
        
            if resultado > 7:
                resultado = 7

            for i in proyectosDocentesPAD:
                if i == "Si":
                    resultado += 0.5
                else:
                    continue
        
            if resultado > 8:
                resultado = 8

            for i in eventosDocentesPAD:
                if i == "Si":
                    resultado += 0.5
                else:
                    continue
            
            resultado = round(resultado)
            if resultado > 9:
                resultado = 9
        
        self.resultadoExpDocPAD = resultado
        print("resultado experiencia docente = " + str(resultado))

class EvaluacionExpProfPAD(KnowledgeEngine):
    resultadoExpProfPAD = 0
    @Rule(ExperienciaProfesionalPAD(experienciasProfPAD = P(lambda x: x == 0)))
    def no_experienciasProfPAD(self):
        resultado = 0
        self.resultadoExpProfPAD = resultado
        print("resultado experiencia profesional = " + str(resultado))
    
    @Rule(ExperienciaProfesionalPAD(experienciasProfPAD = P(lambda x: x > 0)))
    def experienciasProfPAD(self):
        resultado = 0
        experienciasProfPAD = self.facts[1]['experienciasProfPAD']
        tipoInstitucionPAD = self.facts[2]['tipoInstitucionPAD']
        laborPAD = self.facts[3]['laborPAD']
        duracionPAD = self.facts[4]['duracionPAD']
        
        if experienciasProfPAD == 1:
            if (int(duracionPAD[0]) >= 24):
                resultado += 2
            elif (int(duracionPAD[0]) > 36):
                resultado += 3
            else:
                resultado += 1
            
            if tipoInstitucionPAD[0] == "Institucion Docente":
                resultado += 1
            elif ((tipoInstitucionPAD[0] == "Empresa") or (tipoInstitucionPAD[0] == "Otro")):
                resultado += 0.5

            if laborPAD[0] == "Si":
                resultado += 1
            else:
                resultado += 0.5
            
            resultado = round(resultado)
            if resultado > 5:
                resultado = 5
        else:

            for i in tipoInstitucionPAD:
                if i == "Institucion Docente":
                    resultado += 1
                elif i == "Empresa":
                    resultado += 0.75
                elif i == "Otro":
                    resultado += 0.5
                
            if resultado > 2:
                resultado = 2
        
            for i in laborPAD:
                if i == "Si":
                    resultado += 1.5
                else:
                    resultado += 0.5
            
            if resultado > 4:
                resultado = 4

            for i in duracionPAD:
                if (int(i) >= 12):
                    resultado += 1
               

            resultado = round(resultado)
            if resultado > 5:
                resultado = 5
        
        self.resultadoExpProfPAD = resultado
        print("resultado experiencia profesional = " + str(resultado))

class EvaluacionOtrosMeritosPAD(KnowledgeEngine):
    resultadoOtrosMeritosPAD = 0
    @Rule()
    def evaluacion_otros_meritosPAD(self):
        resultado = 0
        otrosMeritosAcademicosPAD = self.facts[1]['otrosMeritosAcademicosPAD']
        otrosMeritosDocentesPAD = self.facts[2]['otrosMeritosDocentesPAD']
        otrosMeritosInvestigacionPAD = self.facts[3]['otrosMeritosInvestigacionPAD']
        otrosMeritosProfesionalesPAD = self.facts[4]['otrosMeritosProfesionalesPAD']
        becasInvestigacionPAD = self.facts[5]['becasInvestigacionPAD']

        for i in otrosMeritosAcademicosPAD:
            if i == "Si":
                resultado += 0.5
        for i in otrosMeritosDocentesPAD:
            if i == "Si":
                resultado += 0.5
        for i in otrosMeritosInvestigacionPAD:
            if i == "Si":
                resultado += 0.5
        for i in otrosMeritosProfesionalesPAD:
            if i == "Si":
                resultado += 0.5
        for i in becasInvestigacionPAD:
            if i == "Beca de iniciación a la investigación":
                resultado += 1.5
            if i == "Beca de colaboración a la investigación":
                resultado += 1.5

        resultado = round(resultado)
        self.resultadoOtrosMeritosPAD = resultado
        print("resultado otros meritos = " + str(resultado))

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
@app.route("/evaluacion-pad", methods = ["GET","POST"])
def evaluacion_pad():
    if "nombre" in session:
        resultado = 0
        if request.method == "POST":
            req = request.form
            especialidad = req["especialidad"]

            dataPublicacionesA = [req["publicacion1"],req["publicacion2"],req["publicacion3"],req["publicacion4"],req["publicacion5"],req["publicacion6"],req["publicacion7"],req["publicacion8"],req["publicacion9"]]
            dataTercilA = [req["tercil1"],req["tercil2"],req["tercil3"],req["tercil4"],req["tercil5"],req["tercil6"],req["tercil7"],req["tercil8"],req["tercil9"]]
            dataFactorA = [req["factor1"],req["factor2"],req["factor3"],req["factor4"],req["factor5"],req["factor6"],req["factor7"],req["factor8"],req["factor9"]]
            dataAutoresA = [req["numeroAutores1"],req["numeroAutores2"],req["numeroAutores3"],req["numeroAutores4"],req["numeroAutores5"],req["numeroAutores6"],req["numeroAutores7"],req["numeroAutores8"],req["numeroAutores9"]]
            dataContinuaA = [req["continua1"],req["continua2"],req["continua3"],req["continua4"],req["continua5"],req["continua6"],req["continua7"],req["continua8"],req["continua9"]]

            publicacionesA = int(len([i for i in dataPublicacionesA if i]))
            tercilA = [i for i in dataTercilA if i]
            factorA = [i for i in dataFactorA if i]
            numeroAutoresA = [i for i in dataAutoresA if i]
            continuaA = [i for i in dataContinuaA if i]

            dataLibrosA = [req["libro1"],req["libro2"],req["libro3"],req["libro4"],req["libro5"],req["libro6"]]
            dataIsbnA = [req["isbn1"],req["isbn2"],req["isbn3"],req["isbn4"],req["isbn5"],req["isbn6"]]
            dataCitasA = [req["citas1"],req["citas2"],req["citas3"],req["citas4"],req["citas5"],req["citas6"]]
            dataTercilCitasA = [req["tercilCitas1"],req["tercilCitas2"],req["tercilCitas3"],req["tercilCitas4"],req["tercilCitas5"],req["tercilCitas6"]]
            dataTraduccionesA = [req["traducciones1"],req["traducciones2"],req["traducciones3"],req["traducciones4"],req["traducciones5"],req["traducciones6"]]
            
            librosA = int(len([i for i in dataLibrosA if i]))
            isbnA = [i for i in dataIsbnA if i]
            citasA = [i for i in dataCitasA if i]
            tercilCitasA = [i for i in dataTercilCitasA if i]
            traduccionesA = [i for i in dataTraduccionesA if i]

            dataProyectosA = [req["proyecto1"],req["proyecto2"],req["proyecto3"],req["proyecto4"],req["proyecto5"],req["proyecto6"]]
            dataTipoParticipacionA = [req["tipoParticipacion1"],req["tipoParticipacion2"],req["tipoParticipacion3"],req["tipoParticipacion4"],req["tipoParticipacion5"],req["tipoParticipacion6"]]
            dataOrganismoA = [req["organismo1"],req["organismo2"],req["organismo3"],req["organismo4"],req["organismo5"],req["organismo6"]]
            dataGradoResponsabilidadA = [req["gradoResp1"],req["gradoResp2"],req["gradoResp3"],req["gradoResp4"],req["gradoResp5"],req["gradoResp6"]]
            dataEvaluadorExternoA = [req["evExt1"],req["evExt2"],req["evExt3"],req["evExt4"],req["evExt5"],req["evExt6"]]

            proyectosA = int(len([i for i in dataProyectosA if i]))
            tipoParticipacionA = [i for i in dataTipoParticipacionA if i]
            organismoA = [i for i in dataOrganismoA if i]
            gradoResponsabilidadA = [i for i in dataGradoResponsabilidadA if i]
            evaluadorExternoA = [i for i in dataEvaluadorExternoA if i]

            dataEventosA = [req["evento1"], req["evento2"], req["evento3"]]
            dataProcesoAdmisionA = [req["procesoAdmision1"], req["procesoAdmision2"], req["procesoAdmision3"]]
            dataCaracterA = [req["caracter1"], req["caracter2"], req["caracter3"]]
            dataParticipacionA = [req["participacion1"], req["participacion2"], req["participacion3"]]

            eventosA = int(len([i for i in dataEventosA if i]))
            procesoAdmisionA = [i for i in dataProcesoAdmisionA if i]
            caracterA = [i for i in dataCaracterA if i]
            participacionA = [i for i in dataParticipacionA if i]

            dataOtrosMeritosInvPAD = [req["otrosMeritosInvPAD"]]
            otrosMeritosInvPAD = int(dataOtrosMeritosInvPAD[0])

            dataEstudiosPAD = [req["estudios1"], req["estudios2"], req["estudios3"], req["estudios4"]]
            dataCalificacionPAD = [req["calif1"],req["calif2"],req["calif3"],req["calif4"]] 
            dataDoctoradoEuropeoPAD = [req["DoctoradoE1"],req["DoctoradoE2"],req["DoctoradoE3"],req["DoctoradoE4"]]
            dataMencionCalidadPAD = [req["MencionC1"],req["MencionC2"],req["MencionC3"],req["MencionC4"]]
            dataBecasPAD = [req["becas1"],req["becas2"],req["becas3"],req["becas4"]]

            estudiosPAD = int(len([i for i in dataEstudiosPAD if i]))
            calificacionPAD = [i for i in dataCalificacionPAD if i]
            doctoradoEuropeoPAD = [i for i in dataDoctoradoEuropeoPAD if i]
            mencionCalidadPAD = [i for i in dataMencionCalidadPAD if i]
            becasPAD = [i for i in dataBecasPAD if i]

            dataEstanciasPAD = [req["estancias1"], req["estancias2"], req["estancias3"], req["estancias4"]]
            dataTipoPAD = [req["tipo1"], req["tipo2"], req["tipo3"], req["tipo4"]]
            dataLugarPAD = [req["lugar1"], req["lugar2"], req["lugar3"], req["lugar4"]]
            dataTiempoPAD = [req["tiempo1"], req["tiempo2"], req["tiempo3"], req["tiempo4"]]

            estanciasPAD = int(len([i for i in dataEstanciasPAD if i]))
            tipoPAD = [i for i in dataTipoPAD if i]
            lugarPAD = [i for i in dataLugarPAD if i]
            tiempoPAD = [i for i in dataTiempoPAD if i]


            dataExperienciasDocentesPAD = [req["expDocPAD1"],req["expDocPAD2"],req["expDocPAD3"],req["expDocPAD4"],req["expDocPAD5"],req["expDocPAD6"]]
            dataTipoEducacionPAD = [req["tipoEDPAD1"],req["tipoEDPAD2"],req["tipoEDPAD3"],req["tipoEDPAD4"],req["tipoEDPAD5"],req["tipoEDPAD6"]]
            dataEvaluacionesPAD = [req["evaPAD1"],req["evaPAD2"],req["evaPAD3"],req["evaPAD4"],req["evaPAD5"],req["evaPAD6"]]
            dataMaterialDocentePAD = [req["matDocPAD1"],req["matDocPAD2"],req["matDocPAD3"],req["matDocPAD4"],req["matDocPAD5"],req["matDocPAD6"]]
            dataProyectosDocentesPAD = [req["proDocPAD1"],req["proDocPAD2"],req["proDocPAD3"],req["proDocPAD4"],req["proDocPAD5"],req["proDocPAD6"]]
            dataEventosDocentesPAD = [req["evDocPAD1"],req["evDocPAD2"],req["evDocPAD3"],req["evDocPAD4"],req["evDocPAD5"],req["evDocPAD6"]]

            experienciasDocentesPAD = int(len([i for i in dataExperienciasDocentesPAD if i]))
            tipoEducacionPAD = [i for i in dataTipoEducacionPAD if i]
            evaluacionesPAD = [i for i in dataEvaluacionesPAD if i]
            materialDocentePAD = [i for i in dataMaterialDocentePAD if i]
            proyectosDocentesPAD = [i for i in dataProyectosDocentesPAD if i]
            eventosDocentesPAD = [i for i in dataEventosDocentesPAD if i]

            dataExperienciasProfPAD = [req["expProfPAD1"], req["expProfPAD2"], req["expProfPAD3"], req["expProfPAD4"]]
            dataTipoInstitucionPAD = [req["tipoInst1"], req["tipoInst2"], req["tipoInst3"], req["tipoInst4"]]
            dataLaborPAD = [req["laborPAD1"], req["laborPAD2"], req["laborPAD3"], req["laborPAD4"]]
            dataDuracionPAD = [req["duracionPAD1"], req["duracionPAD2"], req["duracionPAD3"], req["duracionPAD4"]]

            experienciasProfPAD = int(len([i for i in dataExperienciasProfPAD if i]))
            tipoInstitucionPAD = [i for i in dataTipoInstitucionPAD if i]
            laborPAD = [i for i in dataLaborPAD if i]
            duracionPAD = [i for i in dataDuracionPAD if i]

            dataOtrosMeritosAcademicosPAD = [req["otrosMA"]]
            dataOtrosMeritosDocentesPAD = [req["otrosMD"]]
            dataOtrosMeritosInvestigacionPAD = [req["otrosMI"]]
            dataOtrosMeritosProfesionalesPAD = [req["otrosMP"]]
            dataBecasInvestigacionPAD = [req["becINV1"], req["becINV2"]]

            otrosMeritosAcademicosPAD = [i for i in dataOtrosMeritosAcademicosPAD if i]
            otrosMeritosDocentesPAD = [i for i in dataOtrosMeritosDocentesPAD if i]
            otrosMeritosInvestigacionPAD = [i for i in dataOtrosMeritosInvestigacionPAD if i]
            otrosMeritosProfesionalesPAD = [i for i in dataOtrosMeritosProfesionalesPAD if i]
            becasInvestigacionPAD = [i for i in dataBecasInvestigacionPAD if i]


            if especialidad == "no especialidad seleccionada":
                flash("Recuerde seleccionar una especialidad para poder continuar")
                return redirect(request.url)

            if especialidad == "Ciencias Experimentales":
                enginePublicacionesACE = EvaluacionPublicacionesACE()
                enginePublicacionesACE.reset()
                enginePublicacionesACE.declare(PublicacionesA(publicacionesA = publicacionesA), PublicacionesA(tercilA = tercilA), PublicacionesA(factorA = factorA), PublicacionesA(numeroAutoresA = numeroAutoresA), PublicacionesA(continuaA = continuaA))
                enginePublicacionesACE.run()

                engineLibrosACE = EvaluacionLibrosACE()
                engineLibrosACE.reset()
                engineLibrosACE.declare(LibrosA(librosA = librosA), LibrosA(isbnA = isbnA), LibrosA(citasA = citasA), LibrosA(tercilCitasA = tercilCitasA), LibrosA(traduccionesA = traduccionesA))
                engineLibrosACE.run()

                engineProyectosACE = EvaluacionProyectosACE()
                engineProyectosACE.reset()
                engineProyectosACE.declare(ProyectosA(proyectosA = proyectosA), ProyectosA(tipoParticipacionA = tipoParticipacionA), ProyectosA(organismoA = organismoA), ProyectosA(gradoResponsabilidadA = gradoResponsabilidadA), ProyectosA(evaluadorExternoA = evaluadorExternoA))
                engineProyectosACE.run()

                engineEventosACE = EvaluacionEventosACE()
                engineEventosACE.reset()
                engineEventosACE.declare(EventosA(eventosA = eventosA), EventosA(procesoAdmisionA = procesoAdmisionA), EventosA(caracterA = caracterA), EventosA(participacionA = participacionA))
                engineEventosACE.run()

                engineOtrosMeritosInvPAD = EvaluacionOtrosMeritosInvPAD()
                engineOtrosMeritosInvPAD.reset()
                engineOtrosMeritosInvPAD.declare(OtrosMeritosInvPAD(otrosMeritosInvPAD = otrosMeritosInvPAD))
                engineOtrosMeritosInvPAD.run()

                engineFormacionPAD = EvaluacionFormacionPAD()
                engineFormacionPAD.reset()
                engineFormacionPAD.declare(FormacionPAD(estudiosPAD = estudiosPAD), FormacionPAD(calificacionPAD = calificacionPAD), FormacionPAD(doctoradoEuropeoPAD = doctoradoEuropeoPAD), FormacionPAD(mencionCalidadPAD = mencionCalidadPAD), FormacionPAD(becasPAD = becasPAD))
                engineFormacionPAD.run()

                engineEstanciasPAD = EvaluacionEstanciasPAD()
                engineEstanciasPAD.reset()
                engineEstanciasPAD.declare(EstanciasPAD(estanciasPAD = estanciasPAD), EstanciasPAD(tipoPAD = tipoPAD), EstanciasPAD(lugarPAD = lugarPAD), EstanciasPAD(tiempoPAD = tiempoPAD))
                engineEstanciasPAD.run()

                engineExpDocPAD = EvaluacionExpDocPAD()
                engineExpDocPAD.reset()
                engineExpDocPAD.declare(ExperienciaDocentePAD(experienciasDocentesPAD = experienciasDocentesPAD), ExperienciaDocentePAD(tipoEducacionPAD = tipoEducacionPAD), ExperienciaDocentePAD(evaluacionesPAD = evaluacionesPAD), ExperienciaDocentePAD(materialDocentePAD = materialDocentePAD), ExperienciaDocentePAD(proyectosDocentesPAD = proyectosDocentesPAD), ExperienciaDocentePAD(eventosDocentesPAD = eventosDocentesPAD))
                engineExpDocPAD.run()

                engineExpProfPAD = EvaluacionExpProfPAD()
                engineExpProfPAD.reset()
                engineExpProfPAD.declare(ExperienciaProfesionalPAD(experienciasProfPAD = experienciasProfPAD), ExperienciaProfesionalPAD(tipoInstitucionPAD = tipoInstitucionPAD), ExperienciaProfesionalPAD(laborPAD = laborPAD), ExperienciaProfesionalPAD(duracionPAD = duracionPAD))
                engineExpProfPAD.run()

                engineOtrosMeritosPAD = EvaluacionOtrosMeritosPAD()
                engineOtrosMeritosPAD.reset()
                engineOtrosMeritosPAD.declare(OtrosMeritosPAD(otrosMeritosAcademicosPAD = otrosMeritosAcademicosPAD), OtrosMeritosPAD(otrosMeritosDocentesPAD = otrosMeritosDocentesPAD), OtrosMeritosPAD(otrosMeritosInvestigacionPAD = otrosMeritosInvestigacionPAD), OtrosMeritosPAD(otrosMeritosProfesionalesPAD = otrosMeritosProfesionalesPAD), OtrosMeritosPAD(becasInvestigacionPAD = becasInvestigacionPAD))
                engineOtrosMeritosPAD.run()

                
                resultado = enginePublicacionesACE.resultadoPublicacionesACE + engineLibrosACE.resultadoLibrosACE + engineProyectosACE.resultadoProyectosACE + engineEventosACE.resultadoEventosACE + engineOtrosMeritosInvPAD.resultadoOtrosMeritosInvPAD + engineFormacionPAD.resultadoFormacionPAD + engineEstanciasPAD.resultadoEstanciasPAD + engineExpDocPAD.resultadoExpDocPAD + engineExpProfPAD.resultadoExpProfPAD + engineOtrosMeritosPAD.resultadoOtrosMeritosPAD
                
                cur = mysql.get_db().cursor()
        
                sQuery = "SELECT email, resultado, especialidad FROM resultadospad WHERE email = %s"

                cur.execute(sQuery, [session.get('email')])

                resultadoG = cur.fetchall()
    
                cur.close()
                
                if len(resultadoG) < 3 :

                    cur = mysql.get_db().cursor()
        
                    cur.execute('INSERT INTO resultadospad (email, resultado, especialidad) VALUES ( %s, %s, %s)', (session.get('email'), resultado, especialidad))

                    mysql.get_db().commit()
                
                else:

                    cur = mysql.get_db().cursor()

                    sQuery2 = "DELETE FROM resultadospad WHERE email = %s LIMIT 1"
                    
                    cur.execute(sQuery2, [session.get('email')])

                    cur.execute('INSERT INTO resultadospad (email, resultado, especialidad) VALUES ( %s, %s, %s)', (session.get('email'), resultado, especialidad))

                    mysql.get_db().commit()


                return redirect(url_for('resultados_pad', especialidad = especialidad, resultado = resultado))
            
            if especialidad == "Ciencias de la Salud":
                enginePublicacionesACS = EvaluacionPublicacionesACS()
                enginePublicacionesACS.reset()
                enginePublicacionesACS.declare(PublicacionesA(publicacionesA = publicacionesA), PublicacionesA(tercilA = tercilA), PublicacionesA(factorA = factorA), PublicacionesA(numeroAutoresA = numeroAutoresA), PublicacionesA(continuaA = continuaA))
                enginePublicacionesACS.run()

                engineLibrosACS = EvaluacionLibrosACS()
                engineLibrosACS.reset()
                engineLibrosACS.declare(LibrosA(librosA = librosA), LibrosA(isbnA = isbnA), LibrosA(citasA = citasA), LibrosA(tercilCitasA = tercilCitasA), LibrosA(traduccionesA = traduccionesA))
                engineLibrosACS.run()

                engineProyectosACS = EvaluacionProyectosACS()
                engineProyectosACS.reset()
                engineProyectosACS.declare(ProyectosA(proyectosA = proyectosA), ProyectosA(tipoParticipacionA = tipoParticipacionA), ProyectosA(organismoA = organismoA), ProyectosA(gradoResponsabilidadA = gradoResponsabilidadA), ProyectosA(evaluadorExternoA = evaluadorExternoA))
                engineProyectosACS.run()

                engineEventosACS = EvaluacionEventosACS()
                engineEventosACS.reset()
                engineEventosACS.declare(EventosA(eventosA = eventosA), EventosA(procesoAdmisionA = procesoAdmisionA), EventosA(caracterA = caracterA), EventosA(participacionA = participacionA))
                engineEventosACS.run()

                engineOtrosMeritosInvPAD = EvaluacionOtrosMeritosInvPAD()
                engineOtrosMeritosInvPAD.reset()
                engineOtrosMeritosInvPAD.declare(OtrosMeritosInvPAD(otrosMeritosInvPAD = otrosMeritosInvPAD))
                engineOtrosMeritosInvPAD.run()

                engineFormacionPAD = EvaluacionFormacionPAD()
                engineFormacionPAD.reset()
                engineFormacionPAD.declare(FormacionPAD(estudiosPAD = estudiosPAD), FormacionPAD(calificacionPAD = calificacionPAD), FormacionPAD(doctoradoEuropeoPAD = doctoradoEuropeoPAD), FormacionPAD(mencionCalidadPAD = mencionCalidadPAD), FormacionPAD(becasPAD = becasPAD))
                engineFormacionPAD.run()

                engineEstanciasPAD = EvaluacionEstanciasPAD()
                engineEstanciasPAD.reset()
                engineEstanciasPAD.declare(EstanciasPAD(estanciasPAD = estanciasPAD), EstanciasPAD(tipoPAD = tipoPAD), EstanciasPAD(lugarPAD = lugarPAD), EstanciasPAD(tiempoPAD = tiempoPAD))
                engineEstanciasPAD.run()

                engineExpDocPAD = EvaluacionExpDocPAD()
                engineExpDocPAD.reset()
                engineExpDocPAD.declare(ExperienciaDocentePAD(experienciasDocentesPAD = experienciasDocentesPAD), ExperienciaDocentePAD(tipoEducacionPAD = tipoEducacionPAD), ExperienciaDocentePAD(evaluacionesPAD = evaluacionesPAD), ExperienciaDocentePAD(materialDocentePAD = materialDocentePAD), ExperienciaDocentePAD(proyectosDocentesPAD = proyectosDocentesPAD), ExperienciaDocentePAD(eventosDocentesPAD = eventosDocentesPAD))
                engineExpDocPAD.run()

                engineExpProfPAD = EvaluacionExpProfPAD()
                engineExpProfPAD.reset()
                engineExpProfPAD.declare(ExperienciaProfesionalPAD(experienciasProfPAD = experienciasProfPAD), ExperienciaProfesionalPAD(tipoInstitucionPAD = tipoInstitucionPAD), ExperienciaProfesionalPAD(laborPAD = laborPAD), ExperienciaProfesionalPAD(duracionPAD = duracionPAD))
                engineExpProfPAD.run()

                engineOtrosMeritosPAD = EvaluacionOtrosMeritosPAD()
                engineOtrosMeritosPAD.reset()
                engineOtrosMeritosPAD.declare(OtrosMeritosPAD(otrosMeritosAcademicosPAD = otrosMeritosAcademicosPAD), OtrosMeritosPAD(otrosMeritosDocentesPAD = otrosMeritosDocentesPAD), OtrosMeritosPAD(otrosMeritosInvestigacionPAD = otrosMeritosInvestigacionPAD), OtrosMeritosPAD(otrosMeritosProfesionalesPAD = otrosMeritosProfesionalesPAD), OtrosMeritosPAD(becasInvestigacionPAD = becasInvestigacionPAD))
                engineOtrosMeritosPAD.run()

                resultado = enginePublicacionesACS.resultadoPublicacionesACS + engineLibrosACS.resultadoLibrosACS + engineProyectosACS.resultadoProyectosACS + engineEventosACS.resultadoEventosACS + engineOtrosMeritosInvPAD.resultadoOtrosMeritosInvPAD + engineFormacionPAD.resultadoFormacionPAD + engineEstanciasPAD.resultadoEstanciasPAD + engineExpDocPAD.resultadoExpDocPAD + engineExpProfPAD.resultadoExpProfPAD + engineOtrosMeritosPAD.resultadoOtrosMeritosPAD
                
                cur = mysql.get_db().cursor()
        
                sQuery = "SELECT email, resultado, especialidad FROM resultadospad WHERE email = %s"

                cur.execute(sQuery, [session.get('email')])

                resultadoG = cur.fetchall()
    
                cur.close()
                
                if len(resultadoG) < 3 :

                    cur = mysql.get_db().cursor()
        
                    cur.execute('INSERT INTO resultadospad (email, resultado, especialidad) VALUES ( %s, %s, %s)', (session.get('email'), resultado, especialidad))

                    mysql.get_db().commit()
                
                else:

                    cur = mysql.get_db().cursor()

                    sQuery2 = "DELETE FROM resultadospad WHERE email = %s LIMIT 1"
                    
                    cur.execute(sQuery2, [session.get('email')])

                    cur.execute('INSERT INTO resultadospad (email, resultado, especialidad) VALUES ( %s, %s, %s)', (session.get('email'), resultado, especialidad))

                    mysql.get_db().commit()


                return redirect(url_for('resultados_pad', especialidad = especialidad, resultado = resultado))
            
            if especialidad == "Enseñanzas Técnicas":
                enginePublicacionesAET = EvaluacionPublicacionesAET()
                enginePublicacionesAET.reset()
                enginePublicacionesAET.declare(PublicacionesA(publicacionesA = publicacionesA), PublicacionesA(tercilA = tercilA), PublicacionesA(factorA = factorA), PublicacionesA(numeroAutoresA = numeroAutoresA), PublicacionesA(continuaA = continuaA))
                enginePublicacionesAET.run()

                engineLibrosAET = EvaluacionLibrosAET()
                engineLibrosAET.reset()
                engineLibrosAET.declare(LibrosA(librosA = librosA), LibrosA(isbnA = isbnA), LibrosA(citasA = citasA), LibrosA(tercilCitasA = tercilCitasA), LibrosA(traduccionesA = traduccionesA))
                engineLibrosAET.run()

                engineProyectosAET = EvaluacionProyectosAET()
                engineProyectosAET.reset()
                engineProyectosAET.declare(ProyectosA(proyectosA = proyectosA), ProyectosA(tipoParticipacionA = tipoParticipacionA), ProyectosA(organismoA = organismoA), ProyectosA(gradoResponsabilidadA = gradoResponsabilidadA), ProyectosA(evaluadorExternoA = evaluadorExternoA))
                engineProyectosAET.run()

                engineEventosAET = EvaluacionEventosAET()
                engineEventosAET.reset()
                engineEventosAET.declare(EventosA(eventosA = eventosA), EventosA(procesoAdmisionA = procesoAdmisionA), EventosA(caracterA = caracterA), EventosA(participacionA = participacionA))
                engineEventosAET.run()

                engineOtrosMeritosInvPAD = EvaluacionOtrosMeritosInvPAD()
                engineOtrosMeritosInvPAD.reset()
                engineOtrosMeritosInvPAD.declare(OtrosMeritosInvPAD(otrosMeritosInvPAD = otrosMeritosInvPAD))
                engineOtrosMeritosInvPAD.run()

                engineFormacionPAD = EvaluacionFormacionPAD()
                engineFormacionPAD.reset()
                engineFormacionPAD.declare(FormacionPAD(estudiosPAD = estudiosPAD), FormacionPAD(calificacionPAD = calificacionPAD), FormacionPAD(doctoradoEuropeoPAD = doctoradoEuropeoPAD), FormacionPAD(mencionCalidadPAD = mencionCalidadPAD), FormacionPAD(becasPAD = becasPAD))
                engineFormacionPAD.run()

                engineEstanciasPAD = EvaluacionEstanciasPAD()
                engineEstanciasPAD.reset()
                engineEstanciasPAD.declare(EstanciasPAD(estanciasPAD = estanciasPAD), EstanciasPAD(tipoPAD = tipoPAD), EstanciasPAD(lugarPAD = lugarPAD), EstanciasPAD(tiempoPAD = tiempoPAD))
                engineEstanciasPAD.run()

                engineExpDocPAD = EvaluacionExpDocPAD()
                engineExpDocPAD.reset()
                engineExpDocPAD.declare(ExperienciaDocentePAD(experienciasDocentesPAD = experienciasDocentesPAD), ExperienciaDocentePAD(tipoEducacionPAD = tipoEducacionPAD), ExperienciaDocentePAD(evaluacionesPAD = evaluacionesPAD), ExperienciaDocentePAD(materialDocentePAD = materialDocentePAD), ExperienciaDocentePAD(proyectosDocentesPAD = proyectosDocentesPAD), ExperienciaDocentePAD(eventosDocentesPAD = eventosDocentesPAD))
                engineExpDocPAD.run()

                engineExpProfPAD = EvaluacionExpProfPAD()
                engineExpProfPAD.reset()
                engineExpProfPAD.declare(ExperienciaProfesionalPAD(experienciasProfPAD = experienciasProfPAD), ExperienciaProfesionalPAD(tipoInstitucionPAD = tipoInstitucionPAD), ExperienciaProfesionalPAD(laborPAD = laborPAD), ExperienciaProfesionalPAD(duracionPAD = duracionPAD))
                engineExpProfPAD.run()

                engineOtrosMeritosPAD = EvaluacionOtrosMeritosPAD()
                engineOtrosMeritosPAD.reset()
                engineOtrosMeritosPAD.declare(OtrosMeritosPAD(otrosMeritosAcademicosPAD = otrosMeritosAcademicosPAD), OtrosMeritosPAD(otrosMeritosDocentesPAD = otrosMeritosDocentesPAD), OtrosMeritosPAD(otrosMeritosInvestigacionPAD = otrosMeritosInvestigacionPAD), OtrosMeritosPAD(otrosMeritosProfesionalesPAD = otrosMeritosProfesionalesPAD), OtrosMeritosPAD(becasInvestigacionPAD = becasInvestigacionPAD))
                engineOtrosMeritosPAD.run()


                resultado = enginePublicacionesAET.resultadoPublicacionesAET + engineLibrosAET.resultadoLibrosAET + engineProyectosAET.resultadoProyectosAET + engineEventosAET.resultadoEventosAET + engineOtrosMeritosInvPAD.resultadoOtrosMeritosInvPAD + engineFormacionPAD.resultadoFormacionPAD + engineEstanciasPAD.resultadoEstanciasPAD + engineExpDocPAD.resultadoExpDocPAD + engineExpProfPAD.resultadoExpProfPAD + engineOtrosMeritosPAD.resultadoOtrosMeritosPAD
                cur = mysql.get_db().cursor()
        
                sQuery = "SELECT email, resultado, especialidad FROM resultadospad WHERE email = %s"

                cur.execute(sQuery, [session.get('email')])

                resultadoG = cur.fetchall()
    
                cur.close()
                
                if len(resultadoG) < 3 :

                    cur = mysql.get_db().cursor()
        
                    cur.execute('INSERT INTO resultadospad (email, resultado, especialidad) VALUES ( %s, %s, %s)', (session.get('email'), resultado, especialidad))

                    mysql.get_db().commit()
                
                else:

                    cur = mysql.get_db().cursor()

                    sQuery2 = "DELETE FROM resultadospad WHERE email = %s LIMIT 1"
                    
                    cur.execute(sQuery2, [session.get('email')])

                    cur.execute('INSERT INTO resultadospad (email, resultado, especialidad) VALUES ( %s, %s, %s)', (session.get('email'), resultado, especialidad))

                    mysql.get_db().commit()


                return redirect(url_for('resultados_pad', especialidad = especialidad, resultado = resultado))

            if especialidad == "Ciencias Sociales y Jurídicas":
                enginePublicacionesASJ = EvaluacionPublicacionesASJ()
                enginePublicacionesASJ.reset()
                enginePublicacionesASJ.declare(PublicacionesA(publicacionesA = publicacionesA), PublicacionesA(tercilA = tercilA), PublicacionesA(factorA = factorA), PublicacionesA(numeroAutoresA = numeroAutoresA), PublicacionesA(continuaA = continuaA))
                enginePublicacionesASJ.run()

                engineLibrosASJ = EvaluacionLibrosASJ()
                engineLibrosASJ.reset()
                engineLibrosASJ.declare(LibrosA(librosA = librosA), LibrosA(isbnA = isbnA), LibrosA(citasA = citasA), LibrosA(tercilCitasA = tercilCitasA), LibrosA(traduccionesA = traduccionesA))
                engineLibrosASJ.run()

                engineProyectosASJ = EvaluacionProyectosASJ()
                engineProyectosASJ.reset()
                engineProyectosASJ.declare(ProyectosA(proyectosA = proyectosA), ProyectosA(tipoParticipacionA = tipoParticipacionA), ProyectosA(organismoA = organismoA), ProyectosA(gradoResponsabilidadA = gradoResponsabilidadA), ProyectosA(evaluadorExternoA = evaluadorExternoA))
                engineProyectosASJ.run()

                engineEventosASJ = EvaluacionEventosASJ()
                engineEventosASJ.reset()
                engineEventosASJ.declare(EventosA(eventosA = eventosA), EventosA(procesoAdmisionA = procesoAdmisionA), EventosA(caracterA = caracterA), EventosA(participacionA = participacionA))
                engineEventosASJ.run()

                engineOtrosMeritosInvPAD = EvaluacionOtrosMeritosInvPAD()
                engineOtrosMeritosInvPAD.reset()
                engineOtrosMeritosInvPAD.declare(OtrosMeritosInvPAD(otrosMeritosInvPAD = otrosMeritosInvPAD))
                engineOtrosMeritosInvPAD.run()

                engineFormacionPAD = EvaluacionFormacionPAD()
                engineFormacionPAD.reset()
                engineFormacionPAD.declare(FormacionPAD(estudiosPAD = estudiosPAD), FormacionPAD(calificacionPAD = calificacionPAD), FormacionPAD(doctoradoEuropeoPAD = doctoradoEuropeoPAD), FormacionPAD(mencionCalidadPAD = mencionCalidadPAD), FormacionPAD(becasPAD = becasPAD))
                engineFormacionPAD.run()

                engineEstanciasPAD = EvaluacionEstanciasPAD()
                engineEstanciasPAD.reset()
                engineEstanciasPAD.declare(EstanciasPAD(estanciasPAD = estanciasPAD), EstanciasPAD(tipoPAD = tipoPAD), EstanciasPAD(lugarPAD = lugarPAD), EstanciasPAD(tiempoPAD = tiempoPAD))
                engineEstanciasPAD.run()

                engineExpDocPAD = EvaluacionExpDocPAD()
                engineExpDocPAD.reset()
                engineExpDocPAD.declare(ExperienciaDocentePAD(experienciasDocentesPAD = experienciasDocentesPAD), ExperienciaDocentePAD(tipoEducacionPAD = tipoEducacionPAD), ExperienciaDocentePAD(evaluacionesPAD = evaluacionesPAD), ExperienciaDocentePAD(materialDocentePAD = materialDocentePAD), ExperienciaDocentePAD(proyectosDocentesPAD = proyectosDocentesPAD), ExperienciaDocentePAD(eventosDocentesPAD = eventosDocentesPAD))
                engineExpDocPAD.run()

                engineExpProfPAD = EvaluacionExpProfPAD()
                engineExpProfPAD.reset()
                engineExpProfPAD.declare(ExperienciaProfesionalPAD(experienciasProfPAD = experienciasProfPAD), ExperienciaProfesionalPAD(tipoInstitucionPAD = tipoInstitucionPAD), ExperienciaProfesionalPAD(laborPAD = laborPAD), ExperienciaProfesionalPAD(duracionPAD = duracionPAD))
                engineExpProfPAD.run()

                engineOtrosMeritosPAD = EvaluacionOtrosMeritosPAD()
                engineOtrosMeritosPAD.reset()
                engineOtrosMeritosPAD.declare(OtrosMeritosPAD(otrosMeritosAcademicosPAD = otrosMeritosAcademicosPAD), OtrosMeritosPAD(otrosMeritosDocentesPAD = otrosMeritosDocentesPAD), OtrosMeritosPAD(otrosMeritosInvestigacionPAD = otrosMeritosInvestigacionPAD), OtrosMeritosPAD(otrosMeritosProfesionalesPAD = otrosMeritosProfesionalesPAD), OtrosMeritosPAD(becasInvestigacionPAD = becasInvestigacionPAD))
                engineOtrosMeritosPAD.run()

                resultado = enginePublicacionesASJ.resultadoPublicacionesASJ + engineLibrosASJ.resultadoLibrosASJ + engineProyectosASJ.resultadoProyectosASJ + engineEventosASJ.resultadoEventosASJ + engineOtrosMeritosInvPAD.resultadoOtrosMeritosInvPAD + engineFormacionPAD.resultadoFormacionPAD + engineEstanciasPAD.resultadoEstanciasPAD + engineExpDocPAD.resultadoExpDocPAD + engineExpProfPAD.resultadoExpProfPAD + engineOtrosMeritosPAD.resultadoOtrosMeritosPAD
                
                cur = mysql.get_db().cursor()
        
                sQuery = "SELECT email, resultado, especialidad FROM resultadospad WHERE email = %s"

                cur.execute(sQuery, [session.get('email')])

                resultadoG = cur.fetchall()
    
                cur.close()
                
                if len(resultadoG) < 3 :

                    cur = mysql.get_db().cursor()
        
                    cur.execute('INSERT INTO resultadospad (email, resultado, especialidad) VALUES ( %s, %s, %s)', (session.get('email'), resultado, especialidad))

                    mysql.get_db().commit()
                
                else:

                    cur = mysql.get_db().cursor()

                    sQuery2 = "DELETE FROM resultadospad WHERE email = %s LIMIT 1"
                    
                    cur.execute(sQuery2, [session.get('email')])

                    cur.execute('INSERT INTO resultadospad (email, resultado, especialidad) VALUES ( %s, %s, %s)', (session.get('email'), resultado, especialidad))

                    mysql.get_db().commit()


                return redirect(url_for('resultados_pad', especialidad = especialidad, resultado = resultado))

            if especialidad == "Humanidades":
                enginePublicacionesAH = EvaluacionPublicacionesAH()
                enginePublicacionesAH.reset()
                enginePublicacionesAH.declare(PublicacionesA(publicacionesA = publicacionesA), PublicacionesA(tercilA = tercilA), PublicacionesA(factorA = factorA), PublicacionesA(numeroAutoresA = numeroAutoresA), PublicacionesA(continuaA = continuaA))
                enginePublicacionesAH.run()

                engineLibrosAH = EvaluacionLibrosAH()
                engineLibrosAH.reset()
                engineLibrosAH.declare(LibrosA(librosA = librosA), LibrosA(isbnA = isbnA), LibrosA(citasA = citasA), LibrosA(tercilCitasA = tercilCitasA), LibrosA(traduccionesA = traduccionesA))
                engineLibrosAH.run()

                engineProyectosAH = EvaluacionProyectosAH()
                engineProyectosAH.reset()
                engineProyectosAH.declare(ProyectosA(proyectosA = proyectosA), ProyectosA(tipoParticipacionA = tipoParticipacionA), ProyectosA(organismoA = organismoA), ProyectosA(gradoResponsabilidadA = gradoResponsabilidadA), ProyectosA(evaluadorExternoA = evaluadorExternoA))
                engineProyectosAH.run()

                engineEventosAH = EvaluacionEventosAH()
                engineEventosAH.reset()
                engineEventosAH.declare(EventosA(eventosA = eventosA), EventosA(procesoAdmisionA = procesoAdmisionA), EventosA(caracterA = caracterA), EventosA(participacionA = participacionA))
                engineEventosAH.run()

                engineOtrosMeritosInvPAD = EvaluacionOtrosMeritosInvPAD()
                engineOtrosMeritosInvPAD.reset()
                engineOtrosMeritosInvPAD.declare(OtrosMeritosInvPAD(otrosMeritosInvPAD = otrosMeritosInvPAD))
                engineOtrosMeritosInvPAD.run()

                engineFormacionPAD = EvaluacionFormacionPAD()
                engineFormacionPAD.reset()
                engineFormacionPAD.declare(FormacionPAD(estudiosPAD = estudiosPAD), FormacionPAD(calificacionPAD = calificacionPAD), FormacionPAD(doctoradoEuropeoPAD = doctoradoEuropeoPAD), FormacionPAD(mencionCalidadPAD = mencionCalidadPAD), FormacionPAD(becasPAD = becasPAD))
                engineFormacionPAD.run()

                engineEstanciasPAD = EvaluacionEstanciasPAD()
                engineEstanciasPAD.reset()
                engineEstanciasPAD.declare(EstanciasPAD(estanciasPAD = estanciasPAD), EstanciasPAD(tipoPAD = tipoPAD), EstanciasPAD(lugarPAD = lugarPAD), EstanciasPAD(tiempoPAD = tiempoPAD))
                engineEstanciasPAD.run()

                engineExpDocPAD = EvaluacionExpDocPAD()
                engineExpDocPAD.reset()
                engineExpDocPAD.declare(ExperienciaDocentePAD(experienciasDocentesPAD = experienciasDocentesPAD), ExperienciaDocentePAD(tipoEducacionPAD = tipoEducacionPAD), ExperienciaDocentePAD(evaluacionesPAD = evaluacionesPAD), ExperienciaDocentePAD(materialDocentePAD = materialDocentePAD), ExperienciaDocentePAD(proyectosDocentesPAD = proyectosDocentesPAD), ExperienciaDocentePAD(eventosDocentesPAD = eventosDocentesPAD))
                engineExpDocPAD.run()

                engineExpProfPAD = EvaluacionExpProfPAD()
                engineExpProfPAD.reset()
                engineExpProfPAD.declare(ExperienciaProfesionalPAD(experienciasProfPAD = experienciasProfPAD), ExperienciaProfesionalPAD(tipoInstitucionPAD = tipoInstitucionPAD), ExperienciaProfesionalPAD(laborPAD = laborPAD), ExperienciaProfesionalPAD(duracionPAD = duracionPAD))
                engineExpProfPAD.run()

                engineOtrosMeritosPAD = EvaluacionOtrosMeritosPAD()
                engineOtrosMeritosPAD.reset()
                engineOtrosMeritosPAD.declare(OtrosMeritosPAD(otrosMeritosAcademicosPAD = otrosMeritosAcademicosPAD), OtrosMeritosPAD(otrosMeritosDocentesPAD = otrosMeritosDocentesPAD), OtrosMeritosPAD(otrosMeritosInvestigacionPAD = otrosMeritosInvestigacionPAD), OtrosMeritosPAD(otrosMeritosProfesionalesPAD = otrosMeritosProfesionalesPAD), OtrosMeritosPAD(becasInvestigacionPAD = becasInvestigacionPAD))
                engineOtrosMeritosPAD.run()

                resultado = enginePublicacionesAH.resultadoPublicacionesAH + engineLibrosAH.resultadoLibrosAH + engineProyectosAH.resultadoProyectosAH + engineEventosAH.resultadoEventosAH + engineOtrosMeritosInvPAD.resultadoOtrosMeritosInvPAD + engineFormacionPAD.resultadoFormacionPAD + engineEstanciasPAD.resultadoEstanciasPAD + engineExpDocPAD.resultadoExpDocPAD + engineExpProfPAD.resultadoExpProfPAD + engineOtrosMeritosPAD.resultadoOtrosMeritosPAD
                cur = mysql.get_db().cursor()
        
                sQuery = "SELECT email, resultado, especialidad FROM resultadospad WHERE email = %s"

                cur.execute(sQuery, [session.get('email')])

                resultadoG = cur.fetchall()
    
                cur.close()
                
                if len(resultadoG) < 3 :

                    cur = mysql.get_db().cursor()
        
                    cur.execute('INSERT INTO resultadospad (email, resultado, especialidad) VALUES ( %s, %s, %s)', (session.get('email'), resultado, especialidad))

                    mysql.get_db().commit()
                
                else:

                    cur = mysql.get_db().cursor()

                    sQuery2 = "DELETE FROM resultadospad WHERE email = %s LIMIT 1"
                    
                    cur.execute(sQuery2, [session.get('email')])

                    cur.execute('INSERT INTO resultadospad (email, resultado, especialidad) VALUES ( %s, %s, %s)', (session.get('email'), resultado, especialidad))

                    mysql.get_db().commit()

                return redirect(url_for('resultados_pad', especialidad = especialidad, resultado = resultado))
        else:
            return render_template('usuario/form-pad.html')
    else:
        return render_template('public/ingresar.html')



@app.route("/informacion-pcd")
def info_pcd():
    if 'nombre' in session:
        return render_template('usuario/informacion-pcd.html')
    else:
        return render_template('public/index.html')

@app.route("/informacion-pup")
def info_pup():
    if 'nombre' in session:
        return render_template('usuario/informacion-pup.html')
    else:
        return render_template('public/index.html')

@app.route("/informacion-pad")
def info_pad():
    if 'nombre' in session:
        return render_template('usuario/informacion-pad.html')
    else:
        return render_template('public/index.html')



@app.route("/resultados-pcd/<especialidad>/<resultado>/<resultadoParcial>")
def resultados_pcd(especialidad, resultado, resultadoParcial):
    if 'nombre' in session:
        return render_template('usuario/resultados-pcd.html', especialidad = especialidad, resultado = int(resultado), resultadoParcial = int(resultadoParcial))
    else:
        return render_template('public/index.html')

@app.route("/resultados-pup/<especialidad>/<resultado>/<resultadoParcial>")
def resultados_pup(especialidad, resultado, resultadoParcial):
    if 'nombre' in session:
        return render_template('usuario/resultados-pup.html', especialidad = especialidad, resultado = int(resultado), resultadoParcial = int(resultadoParcial))
    else:
        return render_template('public/index.html')

@app.route("/resultados-pad/<especialidad>/<resultado>")
def resultados_pad(especialidad, resultado):
    if 'nombre' in session:
        return render_template('usuario/resultados-pad.html', especialidad = especialidad, resultado = int(resultado))
    else:
        return render_template('public/index.html')




@app.route("/mis-resultados")
def mis_resultados():
    if 'nombre' in session:
        return render_template('usuario/mis-resultados-select.html')
    else:
        return render_template('public/ingresar.html')

@app.route("/mis-resultados/pcd")
def mis_resultados_pcd():
    if 'nombre' in session:
        
        cur = mysql.get_db().cursor()
        sQuery = "SELECT email, resultado, resultadoparcial, especialidad FROM resultadospcd WHERE email = %s LIMIT 3"
        cur.execute(sQuery, [session.get('email')])
        resultadoQuery = cur.fetchall()
        cur.close()
        
        vacio = [None, None, None, None]


        if len(resultadoQuery) == 0:
            return render_template('usuario/mis-resultados-sin-resultado.html')
        elif len(resultadoQuery) == 1:    
            return render_template('usuario/mis-resultados-pcd.html', resultado = resultadoQuery[0], resultado2 = vacio, resultado3 = vacio)
        elif len(resultadoQuery) == 2:
            return render_template('usuario/mis-resultados-pcd.html', resultado = resultadoQuery[1], resultado2 = resultadoQuery[0], resultado3 = vacio)
        elif len(resultadoQuery) == 3:
            return render_template('usuario/mis-resultados-pcd.html', resultado = resultadoQuery[2], resultado2 = resultadoQuery[1], resultado3 = resultadoQuery[0])
    else:
        return render_template('public/ingresar.html')

@app.route("/mis-resultados/pup")
def mis_resultados_pup():
    if 'nombre' in session:
        
        cur = mysql.get_db().cursor()
        sQuery = "SELECT email, resultado, resultadoparcial, especialidad FROM resultadospup WHERE email = %s"
        cur.execute(sQuery, [session.get('email')])
        resultadoQuery = cur.fetchall()
        cur.close()
        
        vacio = [None, None, None, None]


        if len(resultadoQuery) == 0:
            return render_template('usuario/mis-resultados-sin-resultado.html')
        elif len(resultadoQuery) == 1:    
            return render_template('usuario/mis-resultados-pup.html', resultado = resultadoQuery[0], resultado2 = vacio, resultado3 = vacio)
        elif len(resultadoQuery) == 2:
            return render_template('usuario/mis-resultados-pup.html', resultado = resultadoQuery[1], resultado2 = resultadoQuery[0], resultado3 = vacio)
        elif len(resultadoQuery) == 3:
            return render_template('usuario/mis-resultados-pup.html', resultado = resultadoQuery[2], resultado2 = resultadoQuery[1], resultado3 = resultadoQuery[0])
    else:
        return render_template('public/ingresar.html')

@app.route("/mis-resultados/pad")
def mis_resultados_pad():
    if 'nombre' in session:
        
        cur = mysql.get_db().cursor()
        sQuery = "SELECT email, resultado, especialidad FROM resultadospad WHERE email = %s"
        cur.execute(sQuery, [session.get('email')])
        resultadoQuery = cur.fetchall()
        cur.close()
        
        vacio = [None, None, None]


        if len(resultadoQuery) == 0:
            return render_template('usuario/mis-resultados-sin-resultado.html')
        elif len(resultadoQuery) == 1:    
            return render_template('usuario/mis-resultados-pad.html', resultado = resultadoQuery[0], resultado2 = vacio, resultado3 = vacio)
        elif len(resultadoQuery) == 2:
            return render_template('usuario/mis-resultados-pad.html', resultado = resultadoQuery[1], resultado2 = resultadoQuery[0], resultado3 = vacio)
        elif len(resultadoQuery) == 3:
            return render_template('usuario/mis-resultados-pad.html', resultado = resultadoQuery[2], resultado2 = resultadoQuery[1], resultado3 = resultadoQuery[0])
    else:
        return render_template('public/ingresar.html')





@app.route("/compara-resultados/")
def compara_resultados():
    if 'email' in session:  
        return render_template('usuario/compara-resultado-select.html')
    else:
        return render_template('public/ingresar.html')

@app.route("/compara-resultados/pcd")
def compara_resultados_pcd():
    if 'email' in session:  
        return render_template('usuario/compara-resultado-select-pcd.html')
    else:
        return render_template('public/ingresar.html')

@app.route("/compara-resultados/pup")
def compara_resultados_pup():
    if 'email' in session:  
        return render_template('usuario/compara-resultado-select-pup.html')
    else:
        return render_template('public/ingresar.html')

@app.route("/compara-resultados/pad")
def compara_resultados_pad():
    if 'email' in session:  
        return render_template('usuario/compara-resultado-select-pad.html')
    else:
        return render_template('public/ingresar.html')

@app.route("/compara-resultados/pcd/<int:especialidad>")
def compara_resultados_pcd_especialidad(especialidad):
    if 'email' in session:
        especialidadIndicada = str
    
        
        if especialidad == 1:
            especialidadIndicada = "Ciencias Experimentales"
        elif especialidad == 2:
            especialidadIndicada = "Ciencias de la Salud"
        elif especialidad == 3:
            especialidadIndicada = "Enseñanzas Técnicas"
        elif especialidad == 4:
            especialidadIndicada = "Ciencias Sociales y Jurídicas"
        elif especialidad == 5:
            especialidadIndicada = "Humanidades"
        else:
            return render_template('usuario/compara-resultado-select-pcd.html')

        cur = mysql.get_db().cursor()
        sQuery = "SELECT resultado FROM resultadospcd WHERE especialidad = %s"
        cur.execute(sQuery, [especialidadIndicada])
        resultadoQuery = cur.fetchall()
        cur.close()
        
        if resultadoQuery == ():
            flash("Aún no se ha realizado ninguna evaluación de esta especialidad, puede escoger otra.")
            return render_template('usuario/compara-resultado-select-pcd.html')

        else:

            media = int
            sumaTotal = 0
            resultados = list()
                
            for i in resultadoQuery:
                resultados.append(i[0])
            print(resultados)
                
            for i in resultados:
                sumaTotal += int(i)
            print(sumaTotal)

            media = round(sumaTotal/(len(resultados)))
            print(media)

            curUsuario = mysql.get_db().cursor()
            sQueryUsuario = "SELECT email, resultado, resultadoparcial, especialidad FROM resultadospcd WHERE email = %s AND especialidad = %s"
            curUsuario.execute(sQueryUsuario, [session.get('email'), especialidadIndicada])
            resultadoQueryUsuario = curUsuario.fetchone()
            curUsuario.close()
            print(resultadoQueryUsuario)
            
            if resultadoQueryUsuario == None:
                return render_template('usuario/compara-resultado-sin-resultado.html', media = media, especialidad = especialidadIndicada)
            else:
                resultadoEvaluacion = resultadoQueryUsuario[1]
                return render_template('usuario/compara-resultado-resultado.html', media = media, resultadoEvaluacion = resultadoEvaluacion, especialidad = especialidadIndicada)
    else:
        return render_template('public/ingresar.html')

@app.route("/compara-resultados/pup/<int:especialidad>")
def compara_resultados_pup_especialidad(especialidad):
    if 'email' in session:
        especialidadIndicada = str
    
        
        if especialidad == 1:
            especialidadIndicada = "Ciencias Experimentales"
        elif especialidad == 2:
            especialidadIndicada = "Ciencias de la Salud"
        elif especialidad == 3:
            especialidadIndicada = "Enseñanzas Técnicas"
        elif especialidad == 4:
            especialidadIndicada = "Ciencias Sociales y Jurídicas"
        elif especialidad == 5:
            especialidadIndicada = "Humanidades"
        else:
            return render_template('usuario/compara-resultado-select-pup.html')

        cur = mysql.get_db().cursor()
        sQuery = "SELECT resultado FROM resultadospup WHERE especialidad = %s"
        cur.execute(sQuery, [especialidadIndicada])
        resultadoQuery = cur.fetchall()
        cur.close()
        
        if resultadoQuery == ():
            flash("Aún no se ha realizado ninguna evaluación de esta especialidad, puede escoger otra.")
            return render_template('usuario/compara-resultado-select-pup.html')

        else:

            media = int
            sumaTotal = 0
            resultados = list()
                
            for i in resultadoQuery:
                resultados.append(i[0])
            print(resultados)
                
            for i in resultados:
                sumaTotal += int(i)
            print(sumaTotal)

            media = round(sumaTotal/(len(resultados)))
            print(media)

            curUsuario = mysql.get_db().cursor()
            sQueryUsuario = "SELECT email, resultado, resultadoparcial, especialidad FROM resultadospup WHERE email = %s AND especialidad = %s"
            curUsuario.execute(sQueryUsuario, [session.get('email'), especialidadIndicada])
            resultadoQueryUsuario = curUsuario.fetchone()
            curUsuario.close()
            print(resultadoQueryUsuario)
            
            if resultadoQueryUsuario == None:
                return render_template('usuario/compara-resultado-sin-resultado.html', media = media, especialidad = especialidadIndicada)
            else:
                resultadoEvaluacion = resultadoQueryUsuario[1]
                return render_template('usuario/compara-resultado-resultado.html', media = media, resultadoEvaluacion = resultadoEvaluacion, especialidad = especialidadIndicada)
    else:
        return render_template('public/ingresar.html')

@app.route("/compara-resultados/pad/<int:especialidad>")
def compara_resultados_pad_especialidad(especialidad):
    if 'email' in session:
        especialidadIndicada = str
    
        
        if especialidad == 1:
            especialidadIndicada = "Ciencias Experimentales"
        elif especialidad == 2:
            especialidadIndicada = "Ciencias de la Salud"
        elif especialidad == 3:
            especialidadIndicada = "Enseñanzas Técnicas"
        elif especialidad == 4:
            especialidadIndicada = "Ciencias Sociales y Jurídicas"
        elif especialidad == 5:
            especialidadIndicada = "Humanidades"
        else:
            return render_template('usuario/compara-resultado-select-pcd-pup.html')

        cur = mysql.get_db().cursor()
        sQuery = "SELECT resultado FROM resultadospad WHERE especialidad = %s"
        cur.execute(sQuery, [especialidadIndicada])
        resultadoQuery = cur.fetchall()
        cur.close()
        
        if resultadoQuery == ():
            flash("Aún no se ha realizado ninguna evaluación de esta especialidad, puede escoger otra.")
            return render_template('usuario/compara-resultado-select-pad.html')

        else:

            media = int
            sumaTotal = 0
            resultados = list()
                
            for i in resultadoQuery:
                resultados.append(i[0])
            print(resultados)
                
            for i in resultados:
                sumaTotal += int(i)
            print(sumaTotal)

            media = round(sumaTotal/(len(resultados)))
            print(media)

            curUsuario = mysql.get_db().cursor()
            sQueryUsuario = "SELECT email, resultado, especialidad FROM resultadospad WHERE email = %s AND especialidad = %s"
            curUsuario.execute(sQueryUsuario, [session.get('email'), especialidadIndicada])
            resultadoQueryUsuario = curUsuario.fetchone()
            curUsuario.close()
            print(resultadoQueryUsuario)
            
            if resultadoQueryUsuario == None:
                return render_template('usuario/compara-resultado-sin-resultado.html', media = media, especialidad = especialidadIndicada)
            else:
                resultadoEvaluacion = resultadoQueryUsuario[1]
                return render_template('usuario/compara-resultado-resultado.html', media = media, resultadoEvaluacion = resultadoEvaluacion, especialidad = especialidadIndicada)
    else:
        return render_template('public/ingresar.html')









